<?php
    $host="localhost";
    $user="root";
    $password="123456";
    $db="magang";
    $kon = mysqli_connect("localhost","root","","magang");
    if (!$kon){
        die("Koneksi gagal:".mysqli_connect_error());
    }
?>