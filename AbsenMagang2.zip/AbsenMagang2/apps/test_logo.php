<?php
    $base_path = dirname(__FILE__);
    $logo_file = 'bandarmasih.png'; // Ganti dengan nama logo Anda
    $logo_path = $base_path . '/pengaturan/logo/' . $logo_file;
    
    echo "Base Path: " . $base_path . "<br>";
    echo "Logo Path: " . $logo_path . "<br>";
    echo "File Exists: " . (file_exists($logo_path) ? 'YES ✓' : 'NO ✗') . "<br>";
    echo "Is Readable: " . (is_readable($logo_path) ? 'YES ✓' : 'NO ✗') . "<br>";
    echo "File Size: " . filesize($logo_path) . " bytes<br>";
    
    // List files di logo directory
    $logo_dir = $base_path . '/pengaturan/logo/';
    echo "<br>Files in logo directory:<br>";
    if (is_dir($logo_dir)) {
        $files = scandir($logo_dir);
        foreach ($files as $file) {
            if ($file != '.' && $file != '..') {
                echo "- " . $file . "<br>";
            }
        }
    }
?>