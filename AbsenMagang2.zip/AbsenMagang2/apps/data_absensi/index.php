<?php
// Aktifkan error reporting untuk debugging (hapus di produksi)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Mulai session jika belum
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Pengecekan akses: Case-insensitive
if (strtolower($_SESSION["level"] ?? '') !== 'admin') {
    echo '<br><div class="alert alert-danger">Tidak Memiliki Hak Akses</div>';
    exit;
}
?>

<div class="row">
    <ol class="breadcrumb">
        <li><a href="index.php?page=beranda">
                <i class="fa fa-home"></i>
            </a></li>
        <li class="active">Data Absensi</li>
    </ol>
</div><!--/.row-->

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Data Absensi
                <span class="pull-right clickable panel-toggle panel-button-tab-left"><i class="fa fa-toggle-up"></i></span>
            </div>
            <div class="panel-body">
                <div class="row">
                    <form action="#" method="GET">
                        <input type="hidden" name="page" value="data_absensi"/>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Nama Mahasiswa :</label>
                                <input type="text" name="nama" id="nama" class="form-control" value="" placeholder="Cari Mahasiswa" required>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Tanggal Awal :</label>
                                <input type="date" name="tanggal_awal" id="tanggal_awal" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Tanggal Akhir :</label>
                                <input type="date" name="tanggal_akhir" id="tanggal_akhir" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <br>
                                <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> Cari</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><!--/.row-->

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-body">
                <?php
                // Validasi untuk menampilkan pesan pemberitahuan saat user update pengaturan aplikasi                
                if (isset($_GET['mulai'])) {
                    if ($_GET['mulai'] === 'berhasil') {
                        echo '<div class="alert alert-success"><strong>Berhasil!</strong> Data Absensi Berhasil Ditambah</div>';
                    } elseif ($_GET['mulai'] === 'gagal') {
                        echo '<div class="alert alert-warning"><strong>Maaf!</strong> Data Absensi Sudah Ada</div>';
                    }
                }
                ?>

                <div class="form-group">
                    <button type="button" class="btn btn-success" id="tambah_absensi"><i class="fa fa-plus"></i> Absensi</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Universitas</th>
                                <th>Status</th>
                                <th>Waktu</th>
                                <th>Hari</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        include 'config/database.php';
                        include 'config/function.php';

                        // Validasi input GET
                        $nama = trim($_GET["nama"] ?? '');
                        $tanggal_awal = $_GET["tanggal_awal"] ?? '';
                        $tanggal_akhir = $_GET["tanggal_akhir"] ?? '';

                        $errors = [];
                        if (!empty($nama) && !preg_match('/^[a-zA-Z\s]+$/', $nama)) {
                            $errors[] = 'Nama hanya boleh berisi huruf dan spasi.';
                        }
                        if (!empty($tanggal_awal) && !strtotime($tanggal_awal)) {
                            $errors[] = 'Tanggal awal tidak valid.';
                        }
                        if (!empty($tanggal_akhir) && !strtotime($tanggal_akhir)) {
                            $errors[] = 'Tanggal akhir tidak valid.';
                        }
                        if (!empty($tanggal_awal) && !empty($tanggal_akhir) && strtotime($tanggal_awal) > strtotime($tanggal_akhir)) {
                            $errors[] = 'Tanggal awal harus sebelum atau sama dengan tanggal akhir.';
                        }

                        if (!empty($errors)) {
                            echo '<div class="alert alert-danger">' . implode('<br>', $errors) . '</div>';
                            exit;
                        }

                        // Tentukan query
                        if (!empty($nama) && !empty($tanggal_awal) && !empty($tanggal_akhir)) {
                            $sql = PencarianAbsensi($nama, $tanggal_awal, $tanggal_akhir);
                        } else {
                            $sql = AbsensiOtomatis(''); // Pastikan ini memiliki LIMIT di function.php
                        }

                        $hasil = mysqli_query($kon, $sql);
                        if (!$hasil) {
                            die('<div class="alert alert-danger">Error query: ' . mysqli_error($kon) . '</div>');
                        }

                        $no = 0;
                        // Menampilkan data dengan perulangan while
                        while ($data = mysqli_fetch_array($hasil)):
                            $no++;
                        ?>
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo htmlspecialchars($data['nama']); ?></td>
                            <td><?php echo htmlspecialchars($data['universitas']); ?></td>
                            <td><?php echo htmlspecialchars($data['status']); ?></td>
                            <td><?php echo htmlspecialchars($data['waktu']); ?></td>
                            <td>
                                <?php
                                $hari = $data["hari"];
                                echo htmlspecialchars(MendapatkanHari($hari));
                                ?>
                            </td>
                            <td>
                                <?php
                                $tgl = date("d", strtotime($data['tanggal']));
                                $bulan = date("m", strtotime($data['tanggal']));
                                $tahun = date("Y", strtotime($data['tanggal']));
                                echo htmlspecialchars($tgl . ' ' . MendapatkanBulan($bulan) . ' ' . $tahun);
                                ?>
                            </td>
                            <td>
                                <button id_mahasiswa="<?php echo htmlspecialchars($data['id_mahasiswa']); ?>" id_absensi="<?php echo htmlspecialchars($data['id_absensi']); ?>" class="absensi btn btn-success btn-circle"><i class="fa fa-clock-o"></i> Absensi</button>
                                <button id_mahasiswa="<?php echo htmlspecialchars($data['id_mahasiswa']); ?>" class="cetak btn btn-primary btn-circle"><i class="fa fa-print"></i> Cetak</button>
                            </td>
                        </tr>
                        <!-- bagian akhir (penutup) while -->
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div><!--/.row-->

<!-- Modal -->
<div class="modal fade" id="modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="judul"></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div id="tampil_data"></div>  
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Menambahkan absensi oleh admin
    $('#tambah_absensi').on('click', function() {
        $.ajax({
            url: 'apps/data_absensi/tambah.php',
            method: 'post',
            success: function(data) {
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML = 'Tambah Absensi';
            },
            error: function(xhr, status, error) {
                alert('Error loading modal: ' + error);
            }
        });
        // Membuka modal
        $('#modal').modal('show');
    });
</script>

<script>
    // Mengubah absensi oleh admin
    $('.absensi').on('click', function() {
        var id_mahasiswa = $(this).attr("id_mahasiswa");
        var id_absensi = $(this).attr("id_absensi");
        $.ajax({
            url: 'apps/data_absensi/absensi.php',
            method: 'POST',
            data: {id_mahasiswa: id_mahasiswa, id_absensi: id_absensi},
            success: function(data) {
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML = 'Mulai Absensi';
            },
            error: function(xhr, status, error) {
                alert('Error loading modal: ' + error);
            }
        });
        // Membuka modal
        $('#modal').modal('show');
    });
</script>

<script>
    // Cetak Absensi
    $('.cetak').on('click', function() {
        var id_mahasiswa = $(this).attr("id_mahasiswa");
        $.ajax({
            url: 'apps/data_absensi/cetak.php',
            method: 'POST',
            data: {id_mahasiswa: id_mahasiswa},
            success: function(data) {
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML = 'Cetak Absensi';
            },
            error: function(xhr, status, error) {
                alert('Error loading modal: ' + error);
            }
        });
        // Membuka modal
        $('#modal').modal('show');
    });
</script>