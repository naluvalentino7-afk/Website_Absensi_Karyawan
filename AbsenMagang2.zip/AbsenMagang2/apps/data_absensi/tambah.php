<?php
    session_start();
    // Memastikan hanya admin yang bisa mengakses
    if ($_SESSION['level'] != 'Admin' && $_SESSION['level'] != 'admin') {
        header("Location: ../../index.php?page=beranda");
        exit();
    }

    include '../../config/database.php';
    
    function input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    if (isset($_POST['simpan_absensi'])) {
        $id_mahasiswa = input($_POST["id_mahasiswa"]);
        $tanggal = input($_POST["tanggal"]);
        $waktu = input($_POST["waktu"]);
        $status = input($_POST["status"]);
        $alasan = input($_POST["alasan"]);
        
        // Validasi: Jika status adalah "Pilih" (default), jangan lanjutkan
        if ($status == "Pilih" || empty($status)) {
            echo "<script>alert('Silakan pilih status absensi yang valid!'); window.history.back();</script>";
            exit();
        }

        // Cek apakah data absensi sudah ada untuk mahasiswa dan tanggal tersebut
        $query_cek = "SELECT * FROM tbl_absensi WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal'";
        $result_cek = mysqli_query($kon, $query_cek);
    
        if (mysqli_num_rows($result_cek) > 0) {
            // Jika sudah ada, update status jika berbeda
            $sql_update = "UPDATE tbl_absensi SET status = '$status', waktu = '$waktu' WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal'";
            $update_absensi = mysqli_query($kon, $sql_update);
        } else {
            // Jika belum ada, insert baru
            $sql_insert = "INSERT INTO tbl_absensi (id_mahasiswa, status, waktu, tanggal) VALUES ('$id_mahasiswa', '$status', '$waktu', '$tanggal')";
            $simpan_absensi = mysqli_query($kon, $sql_insert);
        }
            
        // Jika status izin dan belum ada alasan, insert alasan
        if ($status == "2") {
            $query_cek_alasan = "SELECT * FROM tbl_alasan WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal'";
            $result_cek_alasan = mysqli_query($kon, $query_cek_alasan);
            if (mysqli_num_rows($result_cek_alasan) == 0) {
                $sql_alasan = "INSERT INTO tbl_alasan (id_mahasiswa, alasan, tanggal) VALUES ('$id_mahasiswa', '$alasan', '$tanggal')";
                $simpan_izin = mysqli_query($kon, $sql_alasan);
            }
        }

        // Validasi dan redirect
        if (($simpan_absensi ?? false) || ($update_absensi ?? false) || ($simpan_izin ?? false)) {
            header("Location:../../index.php?page=data_absensi&mulai=berhasil");
        } else {
            header("Location:../../index.php?page=data_absensi&mulai=gagal");
        }
    }
?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Tambah Data Absensi</h1>
    </div>
</div><!--/.row-->

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">Form Tambah Absensi</div>
            <div class="panel-body">
                <form action="apps/data_absensi/tambah.php" method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Nama Mahasiswa :</label>
                                <select class="form-control" id="id_mahasiswa" name="id_mahasiswa" required>
                                    <option value="">Pilih Mahasiswa</option>
                                    <?php 
                                        $query = "SELECT id_mahasiswa, nama FROM tbl_mahasiswa WHERE mulai_magang <= CURDATE() AND akhir_magang >= CURDATE();";
                                        $result = mysqli_query($kon, $query);
                                        if (!$result) {
                                            echo "<option disabled>Error: " . mysqli_error($kon) . "</option>";
                                        } elseif (mysqli_num_rows($result) == 0) {
                                            echo "<option disabled>Tidak ada mahasiswa aktif magang saat ini.</option>";
                                        } else {
                                            while ($data = mysqli_fetch_assoc($result)) {
                                                echo "<option value='" . $data['id_mahasiswa'] . "'>" . $data['nama'] . "</option>";
                                            }
                                        }
                                    ?>
                                </select>
                                <small class="text-muted">Pastikan data mahasiswa memiliki tanggal magang yang valid.</small>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Status :</label>
                                <select class="form-control" id="status" name="status" required>
                                    <option value="">Pilih Status</option>
                                    <option value="1">Hadir</option>
                                    <option value="2">Izin</option>
                                    <option value="3">Tidak Hadir</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Tanggal Absensi :</label>
                                <input type="date" name="tanggal" id="tanggal" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Waktu Absensi :</label>
                                <input type="time" name="waktu" id="waktu" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-12" id="text_alasan" style="display:none;">
                            <div class="form-group">
                                <label>Alasan :</label>
                                <input type="text" name="alasan" id="alasan" class="form-control" placeholder="Masukkan Alasan Kenapa Izin">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <br>
                                <button type="submit" name="simpan_absensi" id="simpan_absensi" class="btn btn-success"><i class="fa fa-plus"></i> Simpan</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><!--/.row-->

<script>
  $(document).ready(function() {
    $("#status").change(function() {
      // Menampilkan input teks jika opsi "izin" dipilih
      if ($(this).val() == "2") {
        $("#text_alasan").show();
        $("#alasan").attr("required", true);
      } else {
        $("#text_alasan").hide();
        $("#alasan").attr("required", false);
      }
    });
  });
</script>