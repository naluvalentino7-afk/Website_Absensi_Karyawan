<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 1. KONEKSI DATABASE
include(__DIR__ . '/../../config/database.php');

// --- Query Mahasiswa untuk Dropdown ---
$q_mhs = mysqli_query($kon, "SELECT * FROM tbl_mahasiswa ORDER BY nama");
?>

<style>
    /* Style khusus untuk tampilan cetak */
    @media print {
        /* Sembunyikan tombol, navbar, sidebar, dan footer saat diprint */
        .no-print, .main-header, .main-sidebar, .main-footer, .breadcrumb, .btn {
            display: none !important;
        }
        
        /* Atur agar area surat memenuhi kertas A4 */
        .content-wrapper { margin: 0 !important; padding: 0 !important; }
        .surat-container {
            border: none !important;
            box-shadow: none !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        body { background-color: #fff !important; }
    }

    /* Style untuk tampilan Preview di layar */
    .surat-container {
        background: #fff;
        width: 210mm; /* Lebar A4 */
        min-height: 297mm; /* Tinggi A4 */
        padding: 2cm;
        margin: 10px auto;
        border: 1px solid #ddd;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
        color: #000;
        font-family: "Times New Roman", Times, serif;
        line-height: 1.6;
    }
    
    .kop-surat {
        text-align: center;
        border-bottom: 3px double #000;
        padding-bottom: 10px;
        margin-bottom: 20px;
    }
    
    .isi-surat {
        margin-top: 30px;
        font-size: 12pt;
    }

    .tabel-data {
        margin: 20px 0 20px 30px;
    }

    .tabel-data td {
        padding: 5px;
        vertical-align: top;
    }
</style>

<!-- ========================================================== -->
<!-- BAGIAN TAMPILAN (HTML) -->
<!-- ========================================================== -->

<?php if (isset($_POST['buat_surat'])): ?>
    <?php
    $id_mahasiswa = intval($_POST['id_mahasiswa']);
    
    // Ambil Data Mahasiswa
    $q_m = mysqli_query($kon, "SELECT * FROM tbl_mahasiswa WHERE id_mahasiswa='$id_mahasiswa'");
    $mhs = mysqli_fetch_array($q_m);

    // Ambil Data Instansi
    $q_s = mysqli_query($kon, "SELECT * FROM tbl_site LIMIT 1");
    $site = mysqli_fetch_array($q_s);

    // Penanganan Data Kosong
    $nama_kota = $site['nama_kota'] ?? 'Banjarmasin';
    $nama_instansi = $site['nama_instansi'] ?? 'NAMA INSTANSI ANDA';
    $alamat_instansi = $site['alamat'] ?? 'Alamat belum diatur di sistem.';
    ?>

    <div class="no-print" style="margin-bottom: 20px;">
        <button onclick="window.print()" class="btn btn-primary btn-lg">
            <i class="fa fa-print"></i> CETAK SEKARANG
        </button>
        <a href="index.php?page=laporan_selesai_magang" class="btn btn-default btn-lg">Kembali</a>
    </div>

    <!-- AREA SURAT YANG AKAN DIPRINT -->
    <div class="surat-container">
        <!-- KOP SURAT -->
        <div class="kop-surat">
            <h2 style="margin: 0;"><?= strtoupper($nama_instansi) ?></h2>
            <p style="margin: 0; font-size: 11pt;"><?= $alamat_instansi ?></p>
        </div>

        <!-- JUDUL SURAT -->
        <div style="text-align: center; margin-top: 20px;">
            <h3 style="text-decoration: underline; margin-bottom: 0;">SURAT KETERANGAN SELESAI MAGANG</h3>
            <p>Nomor: <?= date("Y") ?>/SKM/<?= $mhs['id_mahasiswa'] ?></p>
        </div>

        <!-- ISI SURAT -->
        <div class="isi-surat">
            <p>Yang bertanda tangan di bawah ini menerangkan bahwa:</p>
            
            <table class="tabel-data">
                <tr><td width="150">Nama</td><td width="20">:</td><td><b><?= strtoupper($mhs['nama']) ?></b></td></tr>
                <tr><td>NIM</td><td>:</td><td><?= $mhs['nim'] ?></td></tr>
                <tr><td>Universitas/Sekolah</td><td>:</td><td><?= $mhs['universitas'] ?? '-' ?></td></tr>
                <tr><td>Jurusan</td><td>:</td><td><?= $mhs['jurusan'] ?? '-' ?></td></tr>
            </table>

            <p style="text-align: justify;">
                Telah melaksanakan dan <b>MENYELESAIKAN</b> seluruh rangkaian kegiatan magang di <b><?= $nama_instansi ?></b> 
                terhitung mulai tanggal <b><?= date("d-m-Y", strtotime($mhs['mulai_magang'])) ?></b> 
                sampai dengan <b><?= date("d-m-Y", strtotime($mhs['akhir_magang'])) ?></b>.
            </p>
            
            <p style="text-align: justify;">
                Selama mengikuti program magang, yang bersangkutan telah menunjukkan dedikasi, disiplin, dan etika kerja yang baik serta telah memenuhi seluruh tugas yang diberikan oleh instansi.
            </p>

            <p>Demikian surat keterangan ini diberikan agar dapat dipergunakan sebagaimana mestinya.</p>
        </div>

        <!-- TANDA TANGAN -->
        <div style="float: right; text-align: center; margin-top: 50px; width: 300px;">
            <p style="margin: 0;"><?= $nama_kota ?>, <?= date("d F Y") ?></p>
            <p style="margin: 0;">Kepala Bagian SDM,</p>
            <br><br><br><br>
            <p style="margin: 0;"><b><u>Drs. H. Kepala Instansi</u></b></p>
            <p style="margin: 0; font-size: 10pt;">NIP. 19700101 199001 1 001</p>
        </div>
        <div style="clear: both;"></div>
    </div>

<?php else: ?>
    <!-- FORM AWAL PILIH MAHASISWA -->
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title"><i class="fa fa-print"></i> Cetak Surat Selesai Magang</h3>
        </div>
        <div class="box-body">
            <form method="post">
                <div class="form-group">
                    <label>Pilih Mahasiswa</label>
                    <select name="id_mahasiswa" class="form-control" required>
                        <option value="">-- Pilih Mahasiswa --</option>
                        <?php while($row = mysqli_fetch_array($q_mhs)): ?>
                            <option value="<?= $row['id_mahasiswa'] ?>"><?= $row['nama'] ?> (<?= $row['nim'] ?>)</option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <button type="submit" name="buat_surat" class="btn btn-primary">
                    <i class="fa fa-eye"></i> Buat Preview & Cetak
                </button>
            </form>
        </div>
    </div>
<?php endif; ?>