<?php
session_start();

// Akses hanya admin
if (
    !isset($_SESSION["kode_pengguna"]) ||
    (!isset($_SESSION["level"]) || ($_SESSION["level"] != "Admin" && $_SESSION["level"] != "admin"))
) {
    die("Akses ditolak!");
}

// Validasi input
if (
    !isset($_POST['id_mahasiswa']) ||
    !is_numeric($_POST['id_mahasiswa']) ||
    $_POST['id_mahasiswa'] < 1
) {
    die("Parameter id_mahasiswa tidak dikirim atau tidak valid.");
}

include __DIR__ . '/../../config/database.php';

// Pastikan fpdf ada
$fpdf_path = realpath(__DIR__ . '/../../fpdf.php');
if (!$fpdf_path) {
    die("fpdf.php tidak ditemukan pada path: " . __DIR__ . '/../../fpdf.php');
}
require $fpdf_path;

$id_mahasiswa = intval($_POST['id_mahasiswa']);

// Ambil data mahasiswa (prepared)
$stmt = $kon->prepare("SELECT * FROM tbl_mahasiswa WHERE id_mahasiswa = ? LIMIT 1");
$stmt->bind_param("i", $id_mahasiswa);
$stmt->execute();
$res = $stmt->get_result();
$mhs = $res->fetch_assoc();
$stmt->close();

if (!$mhs) {
    die("Data mahasiswa tidak ditemukan.");
}

// Ambil data site/instansi
$q = mysqli_query($kon, "SELECT * FROM tbl_site LIMIT 1");
$row = mysqli_fetch_array($q);
if (!$row) {
    die("Data instansi tidak ditemukan.");
}

// Tentukan nilai surat
$penanda = "Kepala Bagian SDM";
$nama_penanda = "Drs. H. Kepala Instansi";
$universitas = !empty($mhs['universitas']) ? $mhs['universitas'] : 'Universitas ...';
$jurusan = !empty($mhs['jurusan']) ? $mhs['jurusan'] : '-';
$mulai = !empty($mhs['mulai_magang']) ? $mhs['mulai_magang'] : '[Tanggal Mulai]';
$selesai = !empty($mhs['akhir_magang']) ? $mhs['akhir_magang'] : '[Tanggal Selesai]';
$nama_kota = !empty($row['nama_kota']) ? $row['nama_kota'] : '[Kota]';
$tgl_surat = date("d-m-Y");
$logo = !empty($row['logo']) ? $row['logo'] : null;

// Tandai mahasiswa sebagai selesai dan simpan tanggal_selesai
// Jika ada akhir_magang valid pakai itu, jika tidak pakai tanggal hari ini
$tanggal_selesai_to_store = null;
if (!empty($mhs['akhir_magang']) && $mhs['akhir_magang'] != '0000-00-00') {
    $tanggal_selesai_to_store = $mhs['akhir_magang'];
} else {
    $tanggal_selesai_to_store = date('Y-m-d');
}

$upd = $kon->prepare("UPDATE tbl_mahasiswa SET selesai_magang = 1, tanggal_selesai = ? WHERE id_mahasiswa = ?");
$upd->bind_param("si", $tanggal_selesai_to_store, $id_mahasiswa);
$upd->execute();
$upd->close();

// Buat PDF
$pdf = new FPDF();
$pdf->AddPage();

// Logo (jika ada)
if ($logo && file_exists(__DIR__ . '/../../apps/pengaturan/logo/' . $logo)) {
    $pdf->Image(__DIR__ . '/../../apps/pengaturan/logo/' . $logo, 10, 10, 20, 20);
}
$pdf->SetFont('Arial', 'B', 13);
$pdf->Cell(0, 10, strtoupper($row['nama_instansi']), 0, 1, 'C');
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(0, 6, $row['alamat'], 0, 1, 'C');
$pdf->Line(10, 32, 200, 32);
$pdf->Ln(7);

$pdf->SetFont('Arial', 'BU', 12);
$pdf->Cell(0, 9, 'SURAT KETERANGAN SELESAI MAGANG', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 5, 'Nomor: .../.../SKM/' . date("Y"), 0, 1, 'C');
$pdf->Ln(7);

$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(0, 6,
    "Yang bertanda tangan di bawah ini:\n" .
    "Nama Instansi    : " . $row['nama_instansi'] .
    "\nAlamat           : " . $row['alamat'] .
    "\nJabatan          : $penanda\n", 0);
$pdf->Ln(2);
$pdf->MultiCell(0, 6,
    "Dengan ini menerangkan bahwa:\n" .
    "Nama             : " . $mhs['nama'] .
    "\nNIM              : " . $mhs['nim'] .
    "\nUniversitas      : $universitas" .
    "\nJurusan          : $jurusan\n", 0);
$pdf->Ln(1);
$pdf->MultiCell(0, 6,
    "Telah melaksanakan dan MENYELESAIKAN seluruh rangkaian kegiatan magang di " . $row['nama_instansi'] . " pada:\n" .
    "Waktu Pelaksanaan: $mulai s/d $selesai\n" .
    "Lokasi           : " . $row['alamat'] . "\n", 0);
$pdf->MultiCell(0, 6, "Selama mengikuti program magang, yang bersangkutan telah menunjukkan disiplin, tanggung jawab, dan etika kerja yang baik serta telah memenuhi seluruh ketentuan dan tugas yang diberikan.", 0);

$pdf->Ln(8);
$pdf->Cell(0, 6, "$nama_kota, $tgl_surat", 0, 1, 'R');
$pdf->Cell(0, 6, "$penanda", 0, 1, 'R');
$pdf->Ln(15);
$pdf->Cell(0, 6, $nama_penanda, 0, 1, 'R');

$pdf->Output("Surat_Keterangan_Selesai_Magang.pdf", 'I');
exit;
?>