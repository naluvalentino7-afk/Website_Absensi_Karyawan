<?php
session_start();

// Validasi akses hanya admin
if (!isset($_SESSION['level']) || ($_SESSION['level'] != 'Admin' && $_SESSION['level'] != 'admin')) {
    die('Akses Ditolak - Hanya Admin');
}

// Gunakan path relatif yang tepat (naik 1 tingkat ke root folder proyek)
$base_path = dirname(__FILE__);

require_once($base_path . '/../source/plugin/fpdf/fpdf.php');
include_once($base_path . '/../config/database.php');
include_once($base_path . '/../config/function.php');

// Cek koneksi database
if (!isset($kon)) {
    die('Database connection error');
}

$pdf = new FPDF('P', 'mm', 'Letter');

// Ambil data instansi
$query = mysqli_query($kon, "SELECT * FROM tbl_site LIMIT 1");
$row   = $query ? mysqli_fetch_array($query) : [];

$pembimbing    = isset($row['pembimbing']) ? $row['pembimbing'] : '';
$nama_instansi = isset($row['nama_instansi']) ? $row['nama_instansi'] : 'INSTANSI MAGANG';
$alamat        = isset($row['alamat']) ? $row['alamat'] : '';
$no_telp       = isset($row['no_telp']) ? $row['no_telp'] : '';
$website       = isset($row['website']) ? $row['website'] : '';
$logo          = isset($row['logo']) ? $row['logo'] : '';

$pdf->AddPage();

// === LOGO & HEADER ===
$logo_path = $base_path . '/pengaturan/logo/' . $logo;
if (!empty($logo) && file_exists($logo_path)) {
    $pdf->Image($logo_path, 15, 5, 20, 20);
}

$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,7,strtoupper($nama_instansi),0,1,'C');
$pdf->SetFont('Arial','',9);
$pdf->Cell(0,5,$alamat . (!empty($no_telp) ? ', Telp: '.$no_telp : ''),0,1,'C');
$pdf->Cell(0,5,$website,0,1,'C');

// === GARIS PEMBATAS ===
$pdf->SetLineWidth(0.8);
$pdf->Line(10,31,206,31);
$pdf->SetLineWidth(0.2);
$pdf->Line(10,32,206,32);

// === JUDUL LAPORAN ===
$pdf->SetFont('Arial','B',13);
$pdf->Cell(0,6,'',0,1,'C');
$pdf->Cell(0,7,'REPORT KETERLAMBATAN MAHASISWA',0,1,'C');
$pdf->SetFont('Arial','',9);
$pdf->Cell(0,5,'Tanggal Cetak: '.date('d-m-Y H:i:s'),0,1,'C');
$pdf->Ln(4);

// === TABLE HEADER ===
$pdf->SetFont('Arial','B',9);
$pdf->Cell(10,7,'No',1,0,'C');
$pdf->Cell(55,7,'Nama Mahasiswa',1,0,'C');
$pdf->Cell(35,7,'Tanggal',1,0,'C');
$pdf->Cell(35,7,'Waktu / Jam',1,0,'C');
$pdf->Cell(61,7,'Status',1,1,'C');
$pdf->SetFont('Arial','',9);

// === QUERY DATA KETERLAMBATAN (Aman dari JOIN error) ===
$sql = "SELECT a.*, m.nama 
        FROM tbl_absensi a 
        LEFT JOIN tbl_mahasiswa m ON a.kode_mahasiswa = m.kode_mahasiswa 
        WHERE a.status = 'Terlambat' OR a.keterangan LIKE '%Terlambat%' OR a.terlambat = '1' OR a.terlambat > 0
        ORDER BY a.tanggal DESC";
$hasil = mysqli_query($kon, $sql);

// Fallback jika struktur DB menggunakan id_mahasiswa
if (!$hasil) {
    $sql = "SELECT a.*, m.nama 
            FROM tbl_absensi a 
            LEFT JOIN tbl_mahasiswa m ON a.id_mahasiswa = m.id_mahasiswa 
            ORDER BY a.id_absensi DESC";
    $hasil = mysqli_query($kon, $sql);
}

$no = 1;
$total_terlambat = 0;

if ($hasil && mysqli_num_rows($hasil) > 0) {
    while ($data = mysqli_fetch_array($hasil)) {
        $nama_mhs  = !empty($data['nama']) ? $data['nama'] : (isset($data['kode_mahasiswa']) ? $data['kode_mahasiswa'] : '-');
        $tgl_absen = isset($data['tanggal']) ? $data['tanggal'] : '-';
        
        $waktu = '-';
        if (isset($data['jam_masuk']) && !empty($data['jam_masuk'])) {
            $waktu = $data['jam_masuk'];
        } elseif (isset($data['waktu']) && !empty($data['waktu'])) {
            $waktu = date('H:i', strtotime($data['waktu']));
        }

        $pdf->Cell(10,6,$no,1,0,'C');
        $pdf->Cell(55,6,substr($nama_mhs, 0, 28),1,0,'L');
        $pdf->Cell(35,6,$tgl_absen,1,0,'C');
        $pdf->Cell(35,6,$waktu,1,0,'C');
        $pdf->Cell(61,6,'Hadir (Terlambat)',1,1,'C');
        
        $no++;
        $total_terlambat++;
    }
} else {
    $pdf->Cell(196,6,'Tidak ada data keterlambatan',1,1,'C');
}

// === TOTAL KETERLAMBATAN ===
$pdf->SetFont('Arial','B',9);
$pdf->Cell(135,6,'TOTAL KETERLAMBATAN: ',1,0,'R');
$pdf->Cell(61,6,$total_terlambat.' Orang',1,1,'C');

// === TTD PEMBIMBING ===
$pdf->Ln(10);
$pdf->SetFont('Arial','',10);

$pdf->Cell(120,5,'',0,0);
$pdf->Cell(76,5,'Banjarmasin, '.date('d F Y'),0,1,'C');

$pdf->Cell(120,5,'',0,0);
$pdf->Cell(76,5,'Pembimbing Magang,',0,1,'C');

$pdf->Ln(18);

$pdf->Cell(120,5,'',0,0);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(76,5,(!empty($pembimbing) ? $pembimbing : '(___________________)'),0,1,'C');

// === OUTPUT PDF ===
$namafile = 'Report-Keterlambatan-'.date('YmdHis').'.pdf';
$pdf->Output('I', $namafile); // Menggunakan 'I' agar langsung tampil preview di browser
?>