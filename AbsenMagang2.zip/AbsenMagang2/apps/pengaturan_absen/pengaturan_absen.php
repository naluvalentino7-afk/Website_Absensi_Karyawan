<?php
// Memastikan hanya admin yang bisa mengakses
if ($_SESSION['level'] != 'Admin' && $_SESSION['level'] != 'admin') {
    header("Location: ../../index.php?page=beranda");
    exit();
}

// Menghubungkan database
include '../../config/database.php';

// Proses update waktu absen
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_waktu'])) {
    $mulai_absen = mysqli_real_escape_string($kon, $_POST['mulai_absen']);
    $akhir_absen = mysqli_real_escape_string($kon, $_POST['akhir_absen']);
    
    $query_update = mysqli_query($kon, "UPDATE tbl_setting_absensi SET mulai_absen = '$mulai_absen', akhir_absen = '$akhir_absen' WHERE id = 1");
    if ($query_update) {
        echo "<script>alert('Waktu absen berhasil diupdate!');</script>";
    } else {
        echo "<script>alert('Gagal update waktu absen.');</script>";
    }
}

// Ambil data setting absen
$query = mysqli_query($kon, "SELECT * FROM tbl_setting_absensi LIMIT 1");
$setting = mysqli_fetch_array($query);
$mulai_absen = $setting['mulai_absen'];
$akhir_absen = $setting['akhir_absen'];

// Simulasi data admin (gunakan session admin)
$id_admin = $_SESSION['id_admin'] ?? 1; // Asumsi id_admin ada di session
$nama_admin = $_SESSION['nama_admin'];
?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Pengaturan Waktu Absen</h1>
    </div>
</div><!--/.row-->

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">Atur Waktu Absen</div>
            <div class="panel-body">
                <form method="post" action="">
                    <div class="form-group">
                        <label for="mulai_absen">Waktu Mulai Absen:</label>
                        <input type="time" class="form-control" id="mulai_absen" name="mulai_absen" value="<?php echo $mulai_absen; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="akhir_absen">Waktu Akhir Absen:</label>
                        <input type="time" class="form-control" id="akhir_absen" name="akhir_absen" value="<?php echo $akhir_absen; ?>" required>
                    </div>
                    <button type="submit" name="update_waktu" class="btn btn-primary">Update Waktu</button>
                </form>
            </div>
        </div>
    </div>
</div><!--/.row-->

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">Simulasi Absen (untuk Testing)</div>
            <div class="panel-body">
                <p><strong>Catatan:</strong> Tombol absen di bawah ini untuk simulasi. Absen hanya bisa dilakukan dalam rentang waktu yang diatur.</p>
                <table class="table">
                    <tbody>
                        <tr>
                            <td>Nama Admin</td>
                            <td>: <?php echo $nama_admin; ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal</td>
                            <td>: <?php echo date("d-m-Y"); ?></td>
                        </tr>
                        <tr>
                            <td>Waktu Masuk</td>
                            <td>: 
                                <?php
                                $tanggal_sekarang = date("Y-m-d");
                                $kueri = "SELECT waktu FROM tbl_absensi WHERE id_mahasiswa = '$id_admin' AND tanggal = '$tanggal_sekarang'"; // Gunakan id_admin sebagai id_mahasiswa untuk simulasi
                                $result = mysqli_query($kon, $kueri);
                                if (mysqli_num_rows($result) > 0) {
                                    $data = mysqli_fetch_assoc($result);
                                    echo $data['waktu'];
                                } else {
                                    echo "Belum Absensi";
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Status Masuk</td>
                            <td>: 
                                <?php
                                $kueri = "SELECT status FROM tbl_absensi WHERE id_mahasiswa = '$id_admin' AND tanggal = '$tanggal_sekarang'";
                                $result = mysqli_query($kon, $kueri);
                                if (mysqli_num_rows($result) > 0) {
                                    $data = mysqli_fetch_array($result);
                                    echo ($data['status'] == 1) ? "Hadir" : "Belum Absensi";
                                } else {
                                    echo "Belum Absensi";
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Waktu Keluar</td>
                            <td>: 
                                <?php
                                $kueri = "SELECT waktu_keluar FROM tbl_absensi WHERE id_mahasiswa = '$id_admin' AND tanggal = '$tanggal_sekarang'";
                                $result = mysqli_query($kon, $kueri);
                                if (mysqli_num_rows($result) > 0) {
                                    $data = mysqli_fetch_assoc($result);
                                    echo $data['waktu_keluar'] ? $data['waktu_keluar'] : "Belum Absensi Keluar";
                                } else {
                                    echo "Belum Absensi Keluar";
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Status Keluar</td>
                            <td>: 
                                <?php
                                $kueri = "SELECT status_keluar FROM tbl_absensi WHERE id_mahasiswa = '$id_admin' AND tanggal = '$tanggal_sekarang'";
                                $result = mysqli_query($kon, $kueri);
                                if (mysqli_num_rows($result) > 0) {
                                    $data = mysqli_fetch_array($result);
                                    if ($data['status_keluar'] == 1) {
                                        echo "Hadir";
                                    } elseif ($data['status_keluar'] == 2) {
                                        echo "Izin";
                                    } else {
                                        echo "Belum Absensi Keluar";
                                    }
                                } else {
                                    echo "Belum Absensi Keluar";
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <button id_mahasiswa="<?php echo $id_admin; ?>" id="tombol_absensi_masuk" class="mulai_absensi btn btn-success"><i class="fa fa-clock-o"></i> Absen Masuk</button>
                                <button id_mahasiswa="<?php echo $id_admin; ?>" id="tombol_absensi_keluar" class="absen_keluar btn btn-warning"><i class="fa fa-sign-out"></i> Absen Keluar</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><!--/.row-->

<!-- Modal untuk Absen -->
<div class="modal fade" id="modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="judul"></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div id="tampil_data"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Event untuk absen masuk
    $('.mulai_absensi').on('click', function() {
        var id_mahasiswa = $(this).attr("id_mahasiswa");
        console.log("ID Mahasiswa: " + id_mahasiswa); // Debug
        $.ajax({
            url: '../pengguna/mulai_absensi.php', // Path diperbaiki: dari apps/admin/ ke apps/pengguna/
            method: 'post',
            data: {id_mahasiswa: id_mahasiswa},
            success: function(data) {
                $('#tampil_data').html(data);
                document.getElementById("judul").innerHTML = 'Mulai Absensi Masuk';
            },
            error: function(xhr, status, error) {
                console.log("AJAX Error: " + error); // Debug
                alert("Gagal memuat data absen masuk.");
            }
        });
        $('#modal').modal('show');
    });

    // Event untuk absen keluar
    $('.absen_keluar').on('click', function() {
        var id_mahasiswa = $(this).attr("id_mahasiswa");
        console.log("ID Mahasiswa: " + id_mahasiswa); // Debug
        $.ajax({
            url: '../pengguna/absen_keluar.php', // Path diperbaiki: dari apps/admin/ ke apps/pengguna/
            method: 'post',
            data: {id_mahasiswa: id_mahasiswa},
            success: function(data) {
                $('#tampil_data').html(data);
                document.getElementById("judul").innerHTML = 'Absensi Keluar';
            },
            error: function(xhr, status, error) {
                console.log("AJAX Error: " + error); // Debug
                alert("Gagal memuat data absen keluar.");
            }
        });
        $('#modal').modal('show');
    });
</script>