

<!DOCTYPE html>
<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" href="apps/pengaturan/logo/1774092470_Untitled.png">
    <!-- Title Website -->
    <title>PT. Air Minum Bandarmasih ( PERSERODA )</title>
    <!-- Bootstrap -->
    <link href="template/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="template/css/font-awesome.min.css" rel="stylesheet">
    <!-- Date Picker 3 -->
    <link href="template/css/datepicker3.css" rel="stylesheet">
    <!-- Local CSS -->
    <link href="template/css/styles.css" rel="stylesheet">
    <!-- jQuery -->
    <link rel="stylesheet" href="assets/css/jquery-ui.css">
    <script src="template/js/jquery-2.2.3.min.js"></script>
    <script src="template/js/jquery-1.11.1.min.js"></script>
    <!-- Custom Font -->
    <link href="src/font/font.css" rel="stylesheet" type="text/css">
    <!-- Custom CSS -->
    <style>
        .no-js #loader { display: none;  }
        .js #loader { display: block; position: absolute; left: 100px; top: 0; }
        .se-pre-con {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background: url('loading.gif') center no-repeat #fff;
        }
    </style>
</head>

<body>
<nav class="navbar navbar-custom navbar-fixed-top bg-info" role="navigation">
    <div class="container-fluid"><!-- container-fluid -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span></button>
            <a class="navbar-brand" href="#">ABSENSI | KEGIATAN | PENILAIAN</a>
        </div>
    </div><!-- /.container-fluid -->
</nav>
<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <!-- Menampilkan info nama dan level admin di navbar -->
        <!-- Menampilkan info nama dan level admin di navbar -->

    <!-- Menampilkan info nama dan level mahasiswa di navbar -->
            <div class="profile-sidebar">
            <div class="profile-userpic">
                <img src="apps/mahasiswa/foto/2.png" class="img-responsive" alt="">
            </div>
            <div class="profile-usertitle">
            Navent                <div class="profile-usertitle-name">Mahasiswa</div>
                <div></div>
            </div>
            <div class="clear"></div>
        </div>
        <!-- Menampilkan info nama dan level mahasiswa di navbar -->

<!-- Side Bar Navigation -->
<div class="divider"></div>
    <!-- Menu Beranda -->
    <ul class="nav menu">
        <li><a href='index.php?page=beranda'><em class='fa fa-home'>&nbsp;</em>  Beranda</a></li>
    <!-- Menu Beranda -->
    <!-- Menu Admin -->
            <!-- Menu Admin -->

    <!-- Menu untuk semua (Admin & Mahasiswa) -->
            <li><a href="index.php?page=report_instansi" id="report_instansi"><em class="fa fa-building">&nbsp;</em> Laporan Instansi Pengirim</a></li>
        <li><a href="index.php?page=laporan_selesai_magang" id="laporan_selesai_magang"><em class="fa fa-file-text">&nbsp;</em> Surat Selesai Magang</a></li>
    
    <!-- Menu Mahasiswa -->
                            <li><a href="index.php?page=absen"><em class="fa fa-calendar-check-o">&nbsp;</em> Absensi</a></li>
                <li><a href="index.php?page=riwayat"><em class="fa fa-history">&nbsp;</em> Riwayat Absensi</a></li>
                <li><a href="index.php?page=kegiatan"><em class="fa fa-book">&nbsp;</em> Kegiatan Harian</a></li>
                <li><a href="index.php?page=profil"><em class="fa fa-user-circle-o">&nbsp;</em> Profil</a></li>    
                <li><a href="index.php?page=feedback"><em class="fa fa-comments">&nbsp;</em> Feedback</a></li>
                <!-- Menu Penilaian Kinerja untuk Mahasiswa -->
                <li><a href="index.php?page=lihat_penilaian" id="lihat_penilaian"><em class="fa fa-star">&nbsp;</em> Penilaian Kinerja</a></li>
                <!-- Menu Mahasiswa -->
    <!-- Menu Keluar -->    
        <li><a href="logout.php" id="keluar"><em class="fa fa-sign-out">&nbsp;</em> Keluar</a></li>
    </ul>
    <!-- Menu Keluar -->
</div>
<!-- Side Bar Navigation -->

<!-- Page Penghubung -->
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    
    <!-- Menampilkan pesan success/error jika ada -->
        
    <!-- BERANDA_CUSTOM_LOADED -->
<!-- pastikan path stylesheet sesuai project Anda -->
<link rel="stylesheet" href="/AbsenMagang2/apps/beranda/style.css">

<div class="row beranda-header">
    <div class="col-md-8">
        <h2>Selamat datang, navent!</h2>
        <p class="muted">Ringkasan absen magang Anda — cepat, rapi, dan informatif.</p>
    </div>
    <div class="col-md-4 text-right hidden-xs">
        <img src="apps/pengaturan/logo/1774092470_Untitled.png" alt="Logo" class="beranda-logo">
    </div>
</div>

<div class="row stats-row">
    <div class="col-sm-6 col-md-3">
        <div class="stat-card stat-blue">
            <div class="stat-icon"><i class="fa fa-users"></i></div>
            <div class="stat-info">
                <div class="stat-number">2</div>
                <div class="stat-label">Total Mahasiswa</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="stat-card stat-green">
            <div class="stat-icon"><i class="fa fa-book"></i></div>
            <div class="stat-info">
                <div class="stat-number">4</div>
                <div class="stat-label">Total Kegiatan</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="stat-card stat-orange">
            <div class="stat-icon"><i class="fa fa-calendar-check-o"></i></div>
            <div class="stat-info">
                <div class="stat-number">0</div>
                <div class="stat-label">Absen Hari Ini</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="stat-card stat-red">
            <div class="stat-icon"><i class="fa fa-clock-o"></i></div>
            <div class="stat-info">
                <div class="stat-number">0</div>
                <div class="stat-label">Terlambat Hari Ini</div>
            </div>
        </div>
    </div>
</div>

<div class="row dashboard-main">
    <div class="col-md-6">
        <div class="panel panel-default">
            <div class="panel-heading"><strong>Grafik Kehadiran (6 bulan terakhir)</strong></div>
            <div class="panel-body">
                <canvas id="attendanceChart" height="200"></canvas>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="panel panel-default">
            <div class="panel-heading"><strong>10 Riwayat Absensi Terakhir</strong></div>
            <div class="panel-body">
                <table id="recentAbsence" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr><th>No</th><th>Nama</th><th>Tanggal</th><th>Waktu</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                                            <tr>
                            <td>1</td>
                            <td>Navent</td>
                            <td>2026-07-18</td>
                            <td>02:47:22</td>
                            <td>
                                <span class='label label-success'>Hadir</span>                            </td>
                        </tr>
                                            <tr>
                            <td>2</td>
                            <td>Syirgi</td>
                            <td>2026-03-21</td>
                            <td>20:40:03</td>
                            <td>
                                <span class='label label-warning'>Hadir (Terlambat)</span>                            </td>
                        </tr>
                                            <tr>
                            <td>3</td>
                            <td>Syirgi</td>
                            <td>2026-03-16</td>
                            <td>20:38:22</td>
                            <td>
                                <span class='label label-warning'>Hadir (Terlambat)</span>                            </td>
                        </tr>
                                            <tr>
                            <td>4</td>
                            <td>Navent</td>
                            <td>2026-02-19</td>
                            <td>08:00:00</td>
                            <td>
                                <span class='label label-success'>Hadir</span>                            </td>
                        </tr>
                                            <tr>
                            <td>5</td>
                            <td>Syirgi</td>
                            <td>2026-02-19</td>
                            <td>07:04:04</td>
                            <td>
                                <span class='label label-success'>Hadir</span>                            </td>
                        </tr>
                                            <tr>
                            <td>6</td>
                            <td>Navent</td>
                            <td>2026-02-18</td>
                            <td>19:50:58</td>
                            <td>
                                <span class='label label-default'>Tidak Hadir</span>                            </td>
                        </tr>
                                            <tr>
                            <td>7</td>
                            <td>Syirgi</td>
                            <td>2026-02-18</td>
                            <td>19:41:56</td>
                            <td>
                                <span class='label label-warning'>Hadir (Terlambat)</span>                            </td>
                        </tr>
                                            <tr>
                            <td>8</td>
                            <td>Navent</td>
                            <td>2026-02-09</td>
                            <td>04:41:08</td>
                            <td>
                                <span class='label label-success'>Hadir</span>                            </td>
                        </tr>
                                            <tr>
                            <td>9</td>
                            <td>Syirgi</td>
                            <td>2026-02-08</td>
                            <td>08:00:00</td>
                            <td>
                                <span class='label label-success'>Hadir</span>                            </td>
                        </tr>
                                        </tbody>
                </table>
                <a href="index.php?page=riwayat" class="btn btn-primary btn-sm">Lihat Semua Riwayat</a>
            </div>
        </div>
    </div>
</div>

<!-- CDN: Chart.js dan DataTables (hapus jika sudah dimuat di layout utama) -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<script>
    // Data chart dari PHP
    const labels = ["2026-03","2026-07"];
    const dataValues = [2,1];

    const ctx = document.getElementById('attendanceChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Jumlah Absen',
                data: dataValues,
                borderColor: 'rgba(54,162,235,1)',
                backgroundColor: 'rgba(54,162,235,0.15)',
                fill: true,
                tension: 0.3,
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
        }
    });

    // DataTables init (memerlukan jQuery yang biasanya sudah dimuat oleh layout utama)
    if (window.jQuery) {
        $(document).ready(function(){
            $('#recentAbsence').DataTable({
                paging: true,
                searching: false,
                info: false,
                lengthChange: false,
                pageLength: 5,
                order: [[2, 'desc'], [3, 'desc']]
            });
        });
    }
</script><!-- Function Page Penghubung -->

    <!--/.row-->
</div>
<!--/.main-->

<!-- Java Script -->
<script src="template/js/bootstrap.min.js"></script>
<script src="template/js/chart.min.js"></script>
<script src="template/js/chart-data.js"></script>
<script src="template/js/easypiechart.js"></script>
<script src="template/js/easypiechart-data.js"></script>
<script src="template/js/bootstrap-datepicker.js"></script>
<script src="template/js/custom.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css">
<script src="/assets/chart/chart.js"></script>
<!-- Java Script -->

<script>
   // konfirmasi sebelum keluar aplikasi
   $('#keluar').on('click',function(){
        konfirmasi=confirm("Apakah Anda Yakin Ingin Keluar?")
        if (konfirmasi){
            return true;
        }else {
            return false;
        }
    });
</script>
</body>
</html>