<?php
// Menghubungkan database
include 'config/database.php';

$aksi = isset($_GET['aksi']) ? $_GET['aksi'] : 'list';
$id_penilaian = isset($_GET['id']) ? $_GET['id'] : null;

// ============================================
// AKSI: TAMBAH/EDIT PENILAIAN
// ============================================
if ($aksi == 'tambah' || $aksi == 'edit') {
    // Data untuk Edit
    $data_penilaian = null;
    $data_detail = [];

    if ($aksi == 'edit' && $id_penilaian) {
        $query_penilaian = mysqli_query($kon, "
            SELECT * FROM tbl_penilaian_kinerja WHERE id_penilaian = '$id_penilaian'
        ");
        $data_penilaian = mysqli_fetch_array($query_penilaian);
        
        // Ambil detail penilaian
        $query_detail = mysqli_query($kon, "
            SELECT * FROM tbl_detail_penilaian WHERE id_penilaian = '$id_penilaian'
        ");
        while ($row = mysqli_fetch_array($query_detail)) {
            $data_detail[$row['id_kriteria']] = $row;
        }
    }

    // Ambil daftar mahasiswa
    $query_mahasiswa = mysqli_query($kon, "SELECT id_mahasiswa, nama, nim FROM tbl_mahasiswa ORDER BY nama");

    // Ambil daftar pembimbing
    $query_pembimbing = mysqli_query($kon, "SELECT id_pembimbing, nama_pembimbing FROM tbl_pembimbing WHERE status = 'Aktif' ORDER BY nama_pembimbing");

    // Ambil kriteria penilaian
    $query_kriteria = mysqli_query($kon, "SELECT * FROM tbl_kriteria_penilaian ORDER BY id_kriteria");
    ?>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <em class="fa fa-star"></em>
                        <?php echo ($aksi == 'edit') ? 'Edit Penilaian Kinerja' : 'Tambah Penilaian Kinerja'; ?>
                    </h3>
                </div>
                <div class="panel-body">
                    <form method="POST" action="?page=penilaian_kinerja&aksi=proses&mode=<?php echo $aksi; ?>" class="form-horizontal">
                        
                        <?php if ($aksi == 'edit'): ?>
                        <input type="hidden" name="id_penilaian" value="<?php echo $id_penilaian; ?>">
                        <?php endif; ?>

                        <!-- Mahasiswa -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Mahasiswa <span style="color:red;">*</span></label>
                            <div class="col-sm-9">
                                <select name="id_mahasiswa" class="form-control" required <?php echo ($aksi == 'edit') ? 'disabled' : ''; ?>>
                                    <option value="">-- Pilih Mahasiswa --</option>
                                    <?php 
                                    while ($row = mysqli_fetch_array($query_mahasiswa)): 
                                        $selected = ($data_penilaian && $data_penilaian['id_mahasiswa'] == $row['id_mahasiswa']) ? 'selected' : '';
                                    ?>
                                    <option value="<?php echo $row['id_mahasiswa']; ?>" <?php echo $selected; ?>>
                                        <?php echo htmlspecialchars($row['nama'] . " (" . $row['nim'] . ")"); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                                <?php if ($aksi == 'edit'): ?>
                                <input type="hidden" name="id_mahasiswa" value="<?php echo $data_penilaian['id_mahasiswa']; ?>">
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Pembimbing -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Pembimbing <span style="color:red;">*</span></label>
                            <div class="col-sm-9">
                                <select name="id_pembimbing" class="form-control" required>
                                    <option value="">-- Pilih Pembimbing --</option>
                                    <?php 
                                    while ($row = mysqli_fetch_array($query_pembimbing)): 
                                        $selected = ($data_penilaian && $data_penilaian['id_pembimbing'] == $row['id_pembimbing']) ? 'selected' : '';
                                    ?>
                                    <option value="<?php echo $row['id_pembimbing']; ?>" <?php echo $selected; ?>>
                                        <?php echo htmlspecialchars($row['nama_pembimbing']); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>

                        <!-- Tanggal Penilaian -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Tanggal Penilaian <span style="color:red;">*</span></label>
                            <div class="col-sm-9">
                                <input type="date" name="tanggal_penilaian" class="form-control" required 
                                       value="<?php echo $data_penilaian ? $data_penilaian['tanggal_penilaian'] : date('Y-m-d'); ?>">
                            </div>
                        </div>

                        <!-- Periode Mulai -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Periode Mulai <span style="color:red;">*</span></label>
                            <div class="col-sm-9">
                                <input type="date" name="periode_mulai" class="form-control" required 
                                       value="<?php echo $data_penilaian ? $data_penilaian['periode_mulai'] : ''; ?>">
                            </div>
                        </div>

                        <!-- Periode Akhir -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Periode Akhir <span style="color:red;">*</span></label>
                            <div class="col-sm-9">
                                <input type="date" name="periode_akhir" class="form-control" required 
                                       value="<?php echo $data_penilaian ? $data_penilaian['periode_akhir'] : ''; ?>">
                            </div>
                        </div>

                        <hr>

                        <!-- Kriteria Penilaian -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label"><strong>Kriteria Penilaian</strong></label>
                        </div>

                        <?php 
                        while ($row = mysqli_fetch_array($query_kriteria)): 
                            $id_kriteria = $row['id_kriteria'];
                            $skor_sebelumnya = isset($data_detail[$id_kriteria]) ? $data_detail[$id_kriteria]['skor'] : 3;
                            $catatan_sebelumnya = isset($data_detail[$id_kriteria]) ? $data_detail[$id_kriteria]['catatan'] : '';
                        ?>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">
                                <strong><?php echo htmlspecialchars($row['nama_kriteria']); ?></strong>
                            </label>
                            <div class="col-sm-3">
                                <select name="skor[<?php echo $id_kriteria; ?>]" class="form-control" required>
                                    <option value="">-- Pilih Skor --</option>
                                    <option value="1" <?php echo ($skor_sebelumnya == 1) ? 'selected' : ''; ?>>1 - Sangat Kurang</option>
                                    <option value="2" <?php echo ($skor_sebelumnya == 2) ? 'selected' : ''; ?>>2 - Kurang</option>
                                    <option value="3" <?php echo ($skor_sebelumnya == 3) ? 'selected' : ''; ?>>3 - Cukup</option>
                                    <option value="4" <?php echo ($skor_sebelumnya == 4) ? 'selected' : ''; ?>>4 - Baik</option>
                                    <option value="5" <?php echo ($skor_sebelumnya == 5) ? 'selected' : ''; ?>>5 - Sangat Baik</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <textarea name="catatan[<?php echo $id_kriteria; ?>]" class="form-control" rows="2" placeholder="Catatan (opsional)"><?php echo htmlspecialchars($catatan_sebelumnya); ?></textarea>
                            </div>
                        </div>
                        <?php endwhile; ?>

                        <hr>

                        <!-- Catatan Umum -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Catatan Umum</label>
                            <div class="col-sm-9">
                                <textarea name="catatan_umum" class="form-control" rows="4" placeholder="Catatan tambahan dari pembimbing (opsional)"><?php echo $data_penilaian ? htmlspecialchars($data_penilaian['catatan_umum']) : ''; ?></textarea>
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Status <span style="color:red;">*</span></label>
                            <div class="col-sm-9">
                                <select name="status_penilaian" class="form-control" required>
                                    <option value="Draft" <?php echo ($data_penilaian && $data_penilaian['status_penilaian'] == 'Draft') ? 'selected' : ''; ?>>Draft</option>
                                    <option value="Selesai" <?php echo ($data_penilaian && $data_penilaian['status_penilaian'] == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                                </select>
                            </div>
                        </div>

                        <hr>

                        <!-- Button -->
                        <div class="form-group">
                            <div class="col-sm-9 col-sm-offset-3">
                                <button type="submit" class="btn btn-success">
                                    <em class="fa fa-save"></em> Simpan
                                </button>
                                <a href="index.php?page=penilaian_kinerja" class="btn btn-default">
                                    <em class="fa fa-times"></em> Batal
                                </a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    exit;
}

// ============================================
// AKSI: PROSES FORM (TAMBAH/EDIT)
// ============================================
if ($aksi == 'proses') {
    $mode = isset($_GET['mode']) ? $_GET['mode'] : 'tambah';
    
    if ($mode == 'tambah') {
        $id_mahasiswa = mysqli_real_escape_string($kon, $_POST['id_mahasiswa']);
        $id_pembimbing = mysqli_real_escape_string($kon, $_POST['id_pembimbing']);
        $tanggal_penilaian = mysqli_real_escape_string($kon, $_POST['tanggal_penilaian']);
        $periode_mulai = mysqli_real_escape_string($kon, $_POST['periode_mulai']);
        $periode_akhir = mysqli_real_escape_string($kon, $_POST['periode_akhir']);
        $catatan_umum = mysqli_real_escape_string($kon, $_POST['catatan_umum']);
        $status_penilaian = mysqli_real_escape_string($kon, $_POST['status_penilaian']);

        $query_insert = mysqli_query($kon, "
            INSERT INTO tbl_penilaian_kinerja 
            (id_mahasiswa, id_pembimbing, tanggal_penilaian, periode_mulai, periode_akhir, catatan_umum, status_penilaian)
            VALUES 
            ('$id_mahasiswa', '$id_pembimbing', '$tanggal_penilaian', '$periode_mulai', '$periode_akhir', '$catatan_umum', '$status_penilaian')
        ");

        if ($query_insert) {
            $id_penilaian = mysqli_insert_id($kon);

            foreach ($_POST['skor'] as $id_kriteria => $skor) {
                $id_kriteria = mysqli_real_escape_string($kon, $id_kriteria);
                $skor = mysqli_real_escape_string($kon, $skor);
                $catatan = isset($_POST['catatan'][$id_kriteria]) ? mysqli_real_escape_string($kon, $_POST['catatan'][$id_kriteria]) : '';

                mysqli_query($kon, "
                    INSERT INTO tbl_detail_penilaian 
                    (id_penilaian, id_kriteria, skor, catatan)
                    VALUES 
                    ('$id_penilaian', '$id_kriteria', '$skor', '$catatan')
                ");
            }

            $_SESSION['pesan'] = 'Penilaian berhasil ditambahkan!';
            $_SESSION['alert'] = 'success';
        } else {
            $_SESSION['pesan'] = 'Gagal menambahkan penilaian!';
            $_SESSION['alert'] = 'danger';
        }
    } 
    elseif ($mode == 'edit') {
        $id_penilaian = mysqli_real_escape_string($kon, $_POST['id_penilaian']);
        $id_pembimbing = mysqli_real_escape_string($kon, $_POST['id_pembimbing']);
        $tanggal_penilaian = mysqli_real_escape_string($kon, $_POST['tanggal_penilaian']);
        $periode_mulai = mysqli_real_escape_string($kon, $_POST['periode_mulai']);
        $periode_akhir = mysqli_real_escape_string($kon, $_POST['periode_akhir']);
        $catatan_umum = mysqli_real_escape_string($kon, $_POST['catatan_umum']);
        $status_penilaian = mysqli_real_escape_string($kon, $_POST['status_penilaian']);

        $query_update = mysqli_query($kon, "
            UPDATE tbl_penilaian_kinerja 
            SET id_pembimbing = '$id_pembimbing', 
                tanggal_penilaian = '$tanggal_penilaian', 
                periode_mulai = '$periode_mulai', 
                periode_akhir = '$periode_akhir', 
                catatan_umum = '$catatan_umum', 
                status_penilaian = '$status_penilaian'
            WHERE id_penilaian = '$id_penilaian'
        ");

        if ($query_update) {
            mysqli_query($kon, "DELETE FROM tbl_detail_penilaian WHERE id_penilaian = '$id_penilaian'");

            foreach ($_POST['skor'] as $id_kriteria => $skor) {
                $id_kriteria = mysqli_real_escape_string($kon, $id_kriteria);
                $skor = mysqli_real_escape_string($kon, $skor);
                $catatan = isset($_POST['catatan'][$id_kriteria]) ? mysqli_real_escape_string($kon, $_POST['catatan'][$id_kriteria]) : '';

                mysqli_query($kon, "
                    INSERT INTO tbl_detail_penilaian 
                    (id_penilaian, id_kriteria, skor, catatan)
                    VALUES 
                    ('$id_penilaian', '$id_kriteria', '$skor', '$catatan')
                ");
            }

            $_SESSION['pesan'] = 'Penilaian berhasil diperbarui!';
            $_SESSION['alert'] = 'success';
        } else {
            $_SESSION['pesan'] = 'Gagal memperbarui penilaian!';
            $_SESSION['alert'] = 'danger';
        }
    }

    header("Location: index.php?page=penilaian_kinerja");
    exit;
}

// ============================================
// AKSI: HAPUS PENILAIAN
// ============================================
if ($aksi == 'hapus' && $id_penilaian) {
    $id_penilaian = mysqli_real_escape_string($kon, $id_penilaian);

    mysqli_query($kon, "DELETE FROM tbl_detail_penilaian WHERE id_penilaian = '$id_penilaian'");
    $query_delete = mysqli_query($kon, "DELETE FROM tbl_penilaian_kinerja WHERE id_penilaian = '$id_penilaian'");

    if ($query_delete) {
        $_SESSION['pesan'] = 'Penilaian berhasil dihapus!';
        $_SESSION['alert'] = 'success';
    } else {
        $_SESSION['pesan'] = 'Gagal menghapus penilaian!';
        $_SESSION['alert'] = 'danger';
    }

    header("Location: index.php?page=penilaian_kinerja");
    exit;
}

// ============================================
// AKSI: LIHAT DETAIL
// ============================================
if ($aksi == 'lihat' && $id_penilaian) {
    $id_penilaian = mysqli_real_escape_string($kon, $id_penilaian);

    $query_penilaian = mysqli_query($kon, "
        SELECT 
            p.id_penilaian,
            p.id_mahasiswa,
            m.nama,
            m.nim,
            m.universitas,
            m.jurusan,
            pb.nama_pembimbing,
            pb.email,
            pb.no_telepon,
            p.tanggal_penilaian,
            p.periode_mulai,
            p.periode_akhir,
            p.catatan_umum,
            p.status_penilaian,
            p.created_at
        FROM tbl_penilaian_kinerja p
        INNER JOIN tbl_mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
        INNER JOIN tbl_pembimbing pb ON p.id_pembimbing = pb.id_pembimbing
        WHERE p.id_penilaian = '$id_penilaian'
    ");

    if (mysqli_num_rows($query_penilaian) == 0) {
        echo '<div class="alert alert-danger">Error: Data Penilaian tidak ditemukan!</div>';
        exit;
    }

    $data_penilaian = mysqli_fetch_array($query_penilaian);

    $query_detail = mysqli_query($kon, "
        SELECT 
            dp.id_detail,
            dp.skor,
            dp.catatan,
            kp.nama_kriteria,
            kp.deskripsi
        FROM tbl_detail_penilaian dp
        INNER JOIN tbl_kriteria_penilaian kp ON dp.id_kriteria = kp.id_kriteria
        WHERE dp.id_penilaian = '$id_penilaian'
        ORDER BY kp.id_kriteria
    ");

    $total_skor = 0;
    $jumlah_kriteria = 0;
    $detail_data = [];

    while ($row = mysqli_fetch_array($query_detail)) {
        $total_skor += $row['skor'];
        $jumlah_kriteria++;
        $detail_data[] = $row;
    }

    $rata_rata = ($jumlah_kriteria > 0) ? round($total_skor / $jumlah_kriteria, 2) : 0;
    ?>

    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <em class="fa fa-star"></em> Detail Laporan Penilaian Kinerja
                    </h3>
                </div>
                <div class="panel-body">
                    
                    <!-- Informasi Umum -->
                    <div class="row">
                        <div class="col-md-6">
                            <h4>Data Mahasiswa</h4>
                            <table class="table table-condensed">
                                <tr>
                                    <td><strong>Nama</strong></td>
                                    <td>: <?php echo htmlspecialchars($data_penilaian['nama']); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>NIM</strong></td>
                                    <td>: <?php echo htmlspecialchars($data_penilaian['nim']); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Universitas</strong></td>
                                    <td>: <?php echo htmlspecialchars($data_penilaian['universitas'] ?: '-'); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h4>Data Pembimbing</h4>
                            <table class="table table-condensed">
                                <tr>
                                    <td><strong>Nama</strong></td>
                                    <td>: <?php echo htmlspecialchars($data_penilaian['nama_pembimbing']); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Email</strong></td>
                                    <td>: <?php echo htmlspecialchars($data_penilaian['email'] ?: '-'); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Telepon</strong></td>
                                    <td>: <?php echo htmlspecialchars($data_penilaian['no_telepon'] ?: '-'); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <hr>

                    <!-- Periode -->
                    <p>
                        <strong>📅 Periode:</strong> 
                        <?php echo date('d-m-Y', strtotime($data_penilaian['periode_mulai'])); ?> 
                        s/d 
                        <?php echo date('d-m-Y', strtotime($data_penilaian['periode_akhir'])); ?>
                    </p>

                    <hr>

                    <!-- Detail Kriteria Penilaian -->
                    <h4>Hasil Penilaian</h4>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kriteria</th>
                                    <th>Deskripsi</th>
                                    <th>Skor</th>
                                    <th>Catatan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no = 1;
                                foreach ($detail_data as $row): 
                                    $skor_label = '';
                                    switch ($row['skor']) {
                                        case 1: $skor_label = '1 - Sangat Kurang'; break;
                                        case 2: $skor_label = '2 - Kurang'; break;
                                        case 3: $skor_label = '3 - Cukup'; break;
                                        case 4: $skor_label = '4 - Baik'; break;
                                        case 5: $skor_label = '5 - Sangat Baik'; break;
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><strong><?php echo htmlspecialchars($row['nama_kriteria']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                                    <td>
                                        <span class="label label-primary"><?php echo $skor_label; ?></span>
                                    </td>
                                    <td><?php echo htmlspecialchars($row['catatan']) ?: '-'; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Rata-rata Skor -->
                    <div class="alert alert-info">
                        <strong>Rata-rata Skor:</strong> 
                        <span style="font-size: 18px; font-weight: bold;"><?php echo $rata_rata; ?></span> / 5.00
                        
                        <?php
                        if ($rata_rata >= 4.5) {
                            echo ' ⭐⭐⭐⭐⭐ <strong>(Sangat Baik)</strong>';
                        } elseif ($rata_rata >= 3.5) {
                            echo ' ⭐⭐⭐⭐ <strong>(Baik)</strong>';
                        } elseif ($rata_rata >= 2.5) {
                            echo ' ⭐⭐⭐ <strong>(Cukup)</strong>';
                        } elseif ($rata_rata >= 1.5) {
                            echo ' ⭐⭐ <strong>(Kurang)</strong>';
                        } else {
                            echo ' ⭐ <strong>(Sangat Kurang)</strong>';
                        }
                        ?>
                    </div>

                    <hr>

                    <!-- Catatan Umum -->
                    <h4>Catatan Umum</h4>
                    <div class="well">
                        <?php echo nl2br(htmlspecialchars($data_penilaian['catatan_umum'])) ?: '<em>Tidak ada catatan</em>'; ?>
                    </div>

                    <hr>

                    <!-- Button -->
                    <div class="btn-group" role="group">
                        <a href="index.php?page=penilaian_kinerja" class="btn btn-default">
                            <em class="fa fa-arrow-left"></em> Kembali
                        </a>
                        <a href="index.php?page=penilaian_kinerja&aksi=cetak&id=<?php echo $id_penilaian; ?>" class="btn btn-primary" target="_blank">
                            <em class="fa fa-print"></em> Cetak / Print
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php
    exit;
}

// ============================================
// AKSI: CETAK LAPORAN
// ============================================
if ($aksi == 'cetak' && $id_penilaian) {
    $id_penilaian = mysqli_real_escape_string($kon, $id_penilaian);

    $query_penilaian = mysqli_query($kon, "
        SELECT 
            p.id_penilaian,
            p.id_mahasiswa,
            m.nama,
            m.nim,
            m.universitas,
            m.jurusan,
            pb.nama_pembimbing,
            pb.email,
            pb.no_telepon,
            p.tanggal_penilaian,
            p.periode_mulai,
            p.periode_akhir,
            p.catatan_umum,
            p.status_penilaian,
            p.created_at
        FROM tbl_penilaian_kinerja p
        INNER JOIN tbl_mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
        INNER JOIN tbl_pembimbing pb ON p.id_pembimbing = pb.id_pembimbing
        WHERE p.id_penilaian = '$id_penilaian'
    ");

    if (mysqli_num_rows($query_penilaian) == 0) {
        die('Error: Data Penilaian tidak ditemukan!');
    }

    $data_penilaian = mysqli_fetch_array($query_penilaian);

    $query_detail = mysqli_query($kon, "
        SELECT 
            dp.id_detail,
            dp.skor,
            dp.catatan,
            kp.nama_kriteria,
            kp.deskripsi
        FROM tbl_detail_penilaian dp
        INNER JOIN tbl_kriteria_penilaian kp ON dp.id_kriteria = kp.id_kriteria
        WHERE dp.id_penilaian = '$id_penilaian'
        ORDER BY kp.id_kriteria
    ");

    $total_skor = 0;
    $jumlah_kriteria = 0;
    $detail_data = [];

    while ($row = mysqli_fetch_array($query_detail)) {
        $total_skor += $row['skor'];
        $jumlah_kriteria++;
        $detail_data[] = $row;
    }

    $rata_rata = ($jumlah_kriteria > 0) ? round($total_skor / $jumlah_kriteria, 2) : 0;

    // Ambil data institusi
    $query_site = mysqli_query($kon, "SELECT nama_instansi FROM tbl_site LIMIT 1");
    $data_site = mysqli_fetch_array($query_site);
    $nama_instansi = $data_site['nama_instansi'] ?? 'INSTANSI';
    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Laporan Penilaian Kinerja - <?php echo htmlspecialchars($data_penilaian['nama']); ?></title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                font-family: 'Arial', sans-serif;
                line-height: 1.6;
                color: #333;
            }

            @media print {
                .no-print { display: none; }
            }

            .container {
                max-width: 900px;
                margin: 0 auto;
                padding: 40px;
            }

            .header {
                text-align: center;
                margin-bottom: 30px;
                border-bottom: 3px solid #333;
                padding-bottom: 20px;
            }

            .header h1 {
                font-size: 24px;
                margin-bottom: 5px;
                font-weight: bold;
            }

            .header p {
                font-size: 13px;
                color: #666;
                margin: 3px 0;
            }

            .info-box {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-bottom: 30px;
            }

            .info-section h3 {
                font-size: 14px;
                font-weight: bold;
                margin-bottom: 10px;
                background-color: #f0f0f0;
                padding: 8px;
                border-left: 4px solid #333;
            }

            .info-section table {
                width: 100%;
                font-size: 13px;
            }

            .info-section table tr td {
                padding: 6px;
                border-bottom: 1px solid #eee;
            }

            .info-section table tr td:first-child {
                font-weight: bold;
                width: 40%;
            }

            table.penilaian {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
                font-size: 12px;
            }

            table.penilaian thead {
                background-color: #333;
                color: white;
            }

            table.penilaian th {
                padding: 12px;
                text-align: left;
                font-weight: bold;
                border: 1px solid #333;
            }

            table.penilaian td {
                padding: 10px;
                border: 1px solid #ddd;
            }

            table.penilaian tbody tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            .skor-badge {
                display: inline-block;
                padding: 4px 8px;
                border-radius: 3px;
                font-weight: bold;
                font-size: 11px;
                color: white;
            }

            .skor-1 { background-color: #d9534f; }
            .skor-2 { background-color: #f0ad4e; }
            .skor-3 { background-color: #5bc0de; }
            .skor-4 { background-color: #5cb85c; }
            .skor-5 { background-color: #28a745; }

            .summary {
                background-color: #f0f8ff;
                border: 2px solid #5bc0de;
                border-radius: 5px;
                padding: 20px;
                margin-bottom: 20px;
                text-align: center;
            }

            .summary h3 {
                font-size: 14px;
                color: #666;
                margin-bottom: 10px;
            }

            .summary-score {
                font-size: 36px;
                font-weight: bold;
                color: #5bc0de;
                margin: 10px 0;
            }

            .summary-label {
                font-size: 16px;
                font-weight: bold;
                color: #333;
            }

            .stars {
                font-size: 24px;
                color: #ffc107;
                margin: 10px 0;
            }

            .catatan-box {
                background-color: #f9f9f9;
                border-left: 4px solid #5bc0de;
                padding: 15px;
                margin-bottom: 20px;
                font-size: 12px;
                line-height: 1.8;
            }

            .catatan-box h3 {
                font-size: 14px;
                font-weight: bold;
                margin-bottom: 10px;
            }

            .footer {
                margin-top: 40px;
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                font-size: 12px;
                text-align: center;
            }

            .footer-section {
                padding-top: 50px;
                border-top: 1px solid #ddd;
            }

            .footer-section p {
                margin: 5px 0;
            }

            .footer-signature {
                font-weight: bold;
                margin-top: 10px;
            }

            .print-btn {
                display: inline-block;
                margin-bottom: 20px;
                padding: 10px 20px;
                background-color: #333;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                font-size: 14px;
                text-decoration: none;
            }

            .print-btn:hover {
                background-color: #555;
            }

            .btn-group {
                margin-bottom: 20px;
                text-align: center;
            }

            .btn-group a, .btn-group button {
                display: inline-block;
                margin: 0 5px;
            }

            @media print {
                .btn-group {
                    display: none;
                }
                .container {
                    max-width: 100%;
                    padding: 0;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <!-- Tombol Print & Kembali -->
            <div class="btn-group no-print">
                <button class="print-btn" onclick="window.print()">
                    📄 Cetak / Print
                </button>
                <a href="index.php?page=penilaian_kinerja&aksi=lihat&id=<?php echo $id_penilaian; ?>" class="print-btn" style="background-color: #5bc0de; text-decoration: none;">
                    ← Kembali
                </a>
            </div>

            <!-- Header -->
            <div class="header">
                <h1>LAPORAN PENILAIAN KINERJA</h1>
                <p><?php echo htmlspecialchars($nama_instansi); ?></p>
                <p>Evaluasi Kinerja Mahasiswa Program Magang / Praktikan</p>
            </div>

            <!-- Data Mahasiswa & Pembimbing -->
            <div class="info-box">
                <div class="info-section">
                    <h3>📋 DATA MAHASISWA</h3>
                    <table>
                        <tr>
                            <td>Nama</td>
                            <td><?php echo htmlspecialchars($data_penilaian['nama']); ?></td>
                        </tr>
                        <tr>
                            <td>NIM</td>
                            <td><?php echo htmlspecialchars($data_penilaian['nim']); ?></td>
                        </tr>
                        <tr>
                            <td>Universitas</td>
                            <td><?php echo htmlspecialchars($data_penilaian['universitas'] ?: '-'); ?></td>
                        </tr>
                        <tr>
                            <td>Jurusan</td>
                            <td><?php echo htmlspecialchars($data_penilaian['jurusan'] ?: '-'); ?></td>
                        </tr>
                    </table>
                </div>

                <div class="info-section">
                    <h3>👤 DATA PEMBIMBING</h3>
                    <table>
                        <tr>
                            <td>Nama</td>
                            <td><?php echo htmlspecialchars($data_penilaian['nama_pembimbing']); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><?php echo htmlspecialchars($data_penilaian['email'] ?: '-'); ?></td>
                        </tr>
                        <tr>
                            <td>Telepon</td>
                            <td><?php echo htmlspecialchars($data_penilaian['no_telepon'] ?: '-'); ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Evaluasi</td>
                            <td><?php echo date('d-m-Y', strtotime($data_penilaian['tanggal_penilaian'])); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Periode Penilaian -->
            <div style="margin-bottom: 20px; font-size: 13px;">
                <strong>📅 Periode Penilaian:</strong> 
                <?php echo date('d-m-Y', strtotime($data_penilaian['periode_mulai'])); ?> 
                s/d 
                <?php echo date('d-m-Y', strtotime($data_penilaian['periode_akhir'])); ?>
                <br>
                <strong>📊 Status:</strong> 
                <?php
                $status = $data_penilaian['status_penilaian'];
                if ($status == 'Draft') {
                    echo 'Draft';
                } elseif ($status == 'Selesai') {
                    echo 'Selesai';
                } else {
                    echo 'Disetujui';
                }
                ?>
            </div>

            <!-- Tabel Penilaian -->
            <h3 style="margin-top: 20px; margin-bottom: 10px; font-size: 14px; background-color: #f0f0f0; padding: 8px; border-left: 4px solid #333;">
                📈 HASIL PENILAIAN KINERJA
            </h3>

            <table class="penilaian">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="20%">Kriteria</th>
                        <th width="35%">Deskripsi</th>
                        <th width="15%">Skor</th>
                        <th width="25%">Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    foreach ($detail_data as $row): 
                        $skor_label = '';
                        $skor_class = '';
                        switch ($row['skor']) {
                            case 1: 
                                $skor_label = '1 - Sangat Kurang'; 
                                $skor_class = 'skor-1';
                                break;
                            case 2: 
                                $skor_label = '2 - Kurang'; 
                                $skor_class = 'skor-2';
                                break;
                            case 3: 
                                $skor_label = '3 - Cukup'; 
                                $skor_class = 'skor-3';
                                break;
                            case 4: 
                                $skor_label = '4 - Baik'; 
                                $skor_class = 'skor-4';
                                break;
                            case 5: 
                                $skor_label = '5 - Sangat Baik'; 
                                $skor_class = 'skor-5';
                                break;
                        }
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><strong><?php echo htmlspecialchars($row['nama_kriteria']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                        <td>
                            <span class="skor-badge <?php echo $skor_class; ?>">
                                <?php echo $skor_label; ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($row['catatan']) ?: '-'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Summary Penilaian -->
            <div class="summary">
                <h3>RINGKASAN PENILAIAN KINERJA</h3>
                <div class="summary-score"><?php echo $rata_rata; ?></div>
                <p>dari 5.00</p>
                <div class="stars">
                    <?php
                    if ($rata_rata >= 4.5) {
                        echo '⭐⭐⭐⭐⭐';
                        $rating = 'SANGAT BAIK';
                    } elseif ($rata_rata >= 3.5) {
                        echo '⭐⭐⭐⭐';
                        $rating = 'BAIK';
                    } elseif ($rata_rata >= 2.5) {
                        echo '⭐⭐⭐';
                        $rating = 'CUKUP';
                    } elseif ($rata_rata >= 1.5) {
                        echo '⭐⭐';
                        $rating = 'KURANG';
                    } else {
                        echo '⭐';
                        $rating = 'SANGAT KURANG';
                    }
                    ?>
                </div>
                <div class="summary-label"><?php echo $rating; ?></div>
            </div>

            <!-- Catatan Umum -->
            <?php if (!empty($data_penilaian['catatan_umum'])): ?>
            <div class="catatan-box">
                <h3>💬 CATATAN UMUM DARI PEMBIMBING</h3>
                <p><?php echo nl2br(htmlspecialchars($data_penilaian['catatan_umum'])); ?></p>
            </div>
            <?php endif; ?>

            <!-- Footer & Tanda Tangan -->
            <div class="footer">
                <div class="footer-section">
                    <p><strong>Mengetahui,</strong></p>
                    <p>Pembimbing Lapangan</p>
                    <div class="footer-signature">
                        <?php echo htmlspecialchars($data_penilaian['nama_pembimbing']); ?>
                    </div>
                </div>
                <div class="footer-section">
                    <p><strong>Dicetak pada:</strong></p>
                    <p><?php echo date('d-m-Y H:i:s'); ?></p>
                    <p><em>Laporan ini dihasilkan secara otomatis oleh Sistem Penilaian Kinerja</em></p>
                </div>
            </div>
        </div>

        <script>
            if (new URLSearchParams(window.location.search).get('autoprint') === '1') {
                window.print();
            }
        </script>
    </body>
    </html>

<?php
    exit;
}

// ============================================
// AKSI: LIST (DEFAULT)
// ============================================

// Ambil data penilaian kinerja
$query = mysqli_query($kon, "
    SELECT 
        p.id_penilaian,
        p.id_mahasiswa,
        m.nama,
        m.nim,
        pb.nama_pembimbing,
        p.tanggal_penilaian,
        p.periode_mulai,
        p.periode_akhir,
        p.status_penilaian,
        p.created_at
    FROM tbl_penilaian_kinerja p
    INNER JOIN tbl_mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
    INNER JOIN tbl_pembimbing pb ON p.id_pembimbing = pb.id_pembimbing
    ORDER BY p.created_at DESC
");
?>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <em class="fa fa-star"></em> Laporan Penilaian Kinerja Mahasiswa
                </h3>
            </div>
            <div class="panel-body">
                <a href="index.php?page=penilaian_kinerja&aksi=tambah" class="btn btn-success btn-sm">
                    <em class="fa fa-plus"></em> Tambah Penilaian
                </a>
                <hr>
                
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="tabelPenilaian">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Mahasiswa (NIM)</th>
                                <th>Pembimbing</th>
                                <th>Tanggal Penilaian</th>
                                <th>Periode</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            // KODE BARU (Pengganti Baris 1087)
if ($query && mysqli_num_rows($query) > 0) {
                                while ($row = mysqli_fetch_array($query)): 
                                    $periode = date('d-m-Y', strtotime($row['periode_mulai'])) . ' s/d ' . date('d-m-Y', strtotime($row['periode_akhir']));
                            ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo htmlspecialchars($row['nama']) . " (" . htmlspecialchars($row['nim']) . ")"; ?></td>
                                <td><?php echo htmlspecialchars($row['nama_pembimbing']); ?></td>
                                <td><?php echo date('d-m-Y', strtotime($row['tanggal_penilaian'])); ?></td>
                                <td><?php echo $periode; ?></td>
                                <td>
                                   <?php 
$no = 1;

// Perbaikan di baris ini: Cek dulu apakah $query tidak false
if ($query && mysqli_num_rows($query) > 0) {
    while ($row = mysqli_fetch_array($query)): 
        $periode = date('d-m-Y', strtotime($row['periode_mulai'])) . ' s/d ' . date('d-m-Y', strtotime($row['periode_akhir']));
?>
    <tr>
        <td class="text-center"><?php echo $no++; ?></td>
        <td><?php echo htmlspecialchars($row['nama'] ?? '') . " (" . htmlspecialchars($row['nim'] ?? '') . ")"; ?></td>
        <td><?php echo htmlspecialchars($row['nama_pembimbing'] ?? '-'); ?></td>
        <td><?php echo isset($row['tanggal_penilaian']) ? date('d-m-Y', strtotime($row['tanggal_penilaian'])) : '-'; ?></td>
        <td><?php echo $periode; ?></td>
        <td class="text-center">
            <?php
            $status = $row['status_penilaian'] ?? '';
            if ($status == 'Draft') {
                echo '<span class="label label-warning">Draft</span>';
            } elseif ($status == 'Selesai') {
                echo '<span class="label label-info">Selesai</span>';
            } else {
                echo '<span class="label label-success">Disetujui</span>';
            }
            ?>
        </td>
    </tr>
<?php 
    endwhile; 
} else {
    // Tampilkan pesan jika data kosong ATAU jika query gagal
    echo '<tr><td colspan="6" class="text-center">Belum ada data penilaian</td></tr>';
}
?>
                                </td>
                                <td>
                                    <a href="index.php?page=penilaian_kinerja&aksi=lihat&id=<?php echo $row['id_penilaian']; ?>" 
                                       class="btn btn-info btn-xs" title="Lihat Detail">
                                        <em class="fa fa-eye"></em> Lihat
                                    </a>
                                    <?php if ($status == 'Draft'): ?>
                                    <a href="index.php?page=penilaian_kinerja&aksi=edit&id=<?php echo $row['id_penilaian']; ?>" 
                                       class="btn btn-warning btn-xs" title="Edit">
                                        <em class="fa fa-edit"></em> Edit
                                    </a>
                                    <a href="index.php?page=penilaian_kinerja&aksi=hapus&id=<?php echo $row['id_penilaian']; ?>" 
                                       class="btn btn-danger btn-xs" 
                                       onclick="return confirm('Yakin ingin menghapus?')" title="Hapus">
                                        <em class="fa fa-trash"></em> Hapus
                                    </a>
                                    <?php endif; ?>
                                    <a href="index.php?page=penilaian_kinerja&aksi=cetak&id=<?php echo $row['id_penilaian']; ?>" 
                                       class="btn btn-primary btn-xs" title="Cetak">
                                        <em class="fa fa-print"></em> Cetak
                                    </a>
                                </td>
                            </tr>
                            <?php 
                                endwhile;
                            } else {
                                echo '<tr><td colspan="7" class="text-center"><em>Belum ada data penilaian</em></td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    if ($.fn.DataTable.isDataTable('#tabelPenilaian')) {
        $('#tabelPenilaian').DataTable().destroy();
    }
    
    $('#tabelPenilaian').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Indonesian.json"
        }
    });
});
</script>