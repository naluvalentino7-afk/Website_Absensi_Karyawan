<?php
// apps/penilaian_kinerja/lihat_penilaian.php
// Versi lengkap yang menggunakan path URL dinamis sehingga logo di
// C:\xampp\htdocs\AbsenMagang\apps\pengaturan\logo akan tampil pada saat cetak.

// Pastikan session
if (!isset($_SESSION)) session_start();

// Pastikan koneksi DB tersedia; jika tidak, include config/database.php
if (!isset($kon) || !$kon) {
    // Coba beberapa path relatif untuk menemukan config/database.php
    if (file_exists(__DIR__ . '/../../config/database.php')) {
        include __DIR__ . '/../../config/database.php';
    } elseif (file_exists(__DIR__ . '/../../../config/database.php')) {
        include __DIR__ . '/../../../config/database.php';
    } elseif (file_exists(__DIR__ . '/config/database.php')) {
        include __DIR__ . '/config/database.php';
    } else {
        echo "<div class='alert alert-danger'>Koneksi database tidak ditemukan. Pastikan file config/database.php ada.</div>";
        return;
    }
}

// Pastikan user login
if (empty($_SESSION['kode_pengguna'])) {
    echo "<div class='alert alert-danger'>Akses ditolak. Silakan login terlebih dahulu.</div>";
    return;
}

// Bantu bangun URL proyek secara dinamis (berguna jika folder proyek bukan selalu 'AbsenMagang')
$docRoot = realpath($_SERVER['DOCUMENT_ROOT']);
$projectRootFs = realpath(__DIR__ . '/../../..'); // naik 3 level menuju project root (C:\xampp\htdocs\AbsenMagang)
$projectUrl = '/';
if ($docRoot && $projectRootFs && strpos($projectRootFs, $docRoot) === 0) {
    // dapatkan path relatif terhadap document root, ubah backslash ke slash
    $projectUrl = str_replace('\\', '/', substr($projectRootFs, strlen($docRoot)));
    if ($projectUrl === '') $projectUrl = '/';
}
if ($projectUrl[0] !== '/') $projectUrl = '/' . $projectUrl;
$projectUrl = rtrim($projectUrl, '/'); // menghasilkan '/AbsenMagang' biasanya

$level = $_SESSION['level'] ?? '';
$aksi = $_GET['aksi'] ?? 'list';
$id_penilaian = isset($_GET['id']) ? intval($_GET['id']) : 0;

/**
 * Jika Admin dan aksi list: sertakan modul utama penilaian_kinerja (CRUD).
 */
if (in_array($level, ['Admin','admin']) && ($aksi === 'list' || $aksi === '')) {
    $mod = __DIR__ . '/index.php';
    if (file_exists($mod)) {
        include $mod;
    } else {
        echo "<div class='alert alert-danger'>Modul penilaian_kinerja (index.php) tidak ditemukan di folder apps/penilaian_kinerja/.</div>";
    }
    return;
}

/**
 * ACTION: LIHAT DETAIL
 */
if ($aksi === 'lihat' && $id_penilaian) {
    $id_penilaian_esc = mysqli_real_escape_string($kon, $id_penilaian);

    $query_penilaian = mysqli_query($kon, "
        SELECT 
            p.id_penilaian,
            p.id_mahasiswa,
            m.nama,
            m.nim,
            m.universitas,
            m.jurusan,
            m.foto AS foto_mahasiswa,
            pb.nama_pembimbing,
            pb.email,
            pb.no_telepon,
            p.tanggal_penilaian,
            p.periode_mulai,
            p.periode_akhir,
            p.catatan_umum,
            p.status_penilaian,
            p.created_at
        FROM tbl_penilaian_kinerja p
        INNER JOIN tbl_mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
        LEFT JOIN tbl_pembimbing pb ON p.id_pembimbing = pb.id_pembimbing
        WHERE p.id_penilaian = '$id_penilaian_esc'
    ");

    if (!$query_penilaian || mysqli_num_rows($query_penilaian) == 0) {
        echo '<div class="alert alert-danger">Error: Data Penilaian tidak ditemukan!</div>';
        return;
    }

    $data_penilaian = mysqli_fetch_assoc($query_penilaian);

    // Jika user mahasiswa, pastikan penilaian miliknya
    if (in_array($level, ['Mahasiswa','mahasiswa'])) {
        $id_mahasiswa_sess = $_SESSION['id_mahasiswa'] ?? null;
        if (!$id_mahasiswa_sess) {
            $kode = mysqli_real_escape_string($kon, $_SESSION['kode_pengguna'] ?? '');
            $qtmp = mysqli_query($kon, "SELECT id_mahasiswa FROM tbl_mahasiswa WHERE kode_pengguna = '$kode' LIMIT 1");
            if ($qtmp && mysqli_num_rows($qtmp) > 0) {
                $rr = mysqli_fetch_assoc($qtmp);
                $id_mahasiswa_sess = $rr['id_mahasiswa'];
            }
        }
        if ($id_mahasiswa_sess != $data_penilaian['id_mahasiswa']) {
            echo "<div class='alert alert-danger'>Anda tidak berhak melihat penilaian ini.</div>";
            return;
        }
    }

    // Ambil detail kriteria
    $query_detail = mysqli_query($kon, "
        SELECT 
            dp.id_detail,
            dp.skor,
            dp.catatan,
            kp.nama_kriteria,
            kp.deskripsi
        FROM tbl_detail_penilaian dp
        INNER JOIN tbl_kriteria_penilaian kp ON dp.id_kriteria = kp.id_kriteria
        WHERE dp.id_penilaian = '$id_penilaian_esc'
        ORDER BY kp.id_kriteria
    ");

    $total_skor = 0;
    $jumlah_kriteria = 0;
    $detail_data = [];
    if ($query_detail) {
        while ($row = mysqli_fetch_assoc($query_detail)) {
            $total_skor += $row['skor'];
            $jumlah_kriteria++;
            $detail_data[] = $row;
        }
    }
    $rata_rata = ($jumlah_kriteria > 0) ? round($total_skor / $jumlah_kriteria, 2) : 0;

    // Tampilkan detail
    ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title"><em class="fa fa-star"></em> Detail Laporan Penilaian Kinerja</h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h4>Data Mahasiswa</h4>
                            <table class="table table-condensed">
                                <tr><td><strong>Nama</strong></td><td>: <?php echo htmlspecialchars($data_penilaian['nama']); ?></td></tr>
                                <tr><td><strong>NIM</strong></td><td>: <?php echo htmlspecialchars($data_penilaian['nim']); ?></td></tr>
                                <tr><td><strong>Universitas</strong></td><td>: <?php echo htmlspecialchars($data_penilaian['universitas'] ?: '-'); ?></td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h4>Data Pembimbing</h4>
                            <table class="table table-condensed">
                                <tr><td><strong>Nama</strong></td><td>: <?php echo htmlspecialchars($data_penilaian['nama_pembimbing']); ?></td></tr>
                                <tr><td><strong>Email</strong></td><td>: <?php echo htmlspecialchars($data_penilaian['email'] ?: '-'); ?></td></tr>
                                <tr><td><strong>Telepon</strong></td><td>: <?php echo htmlspecialchars($data_penilaian['no_telepon'] ?: '-'); ?></td></tr>
                            </table>
                        </div>
                    </div>

                    <hr>
                    <p><strong>📅 Periode:</strong> 
                        <?php echo $data_penilaian['periode_mulai'] ? date('d-m-Y', strtotime($data_penilaian['periode_mulai'])) : '-'; ?> 
                        s/d 
                        <?php echo $data_penilaian['periode_akhir'] ? date('d-m-Y', strtotime($data_penilaian['periode_akhir'])) : '-'; ?>
                    </p>
                    <hr>

                    <h4>Hasil Penilaian</h4>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr><th>No</th><th>Kriteria</th><th>Deskripsi</th><th>Skor</th><th>Catatan</th></tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; foreach ($detail_data as $row): 
                                    $skor_label = '';
                                    switch ($row['skor']) {
                                        case 1: $skor_label = '1 - Sangat Kurang'; break;
                                        case 2: $skor_label = '2 - Kurang'; break;
                                        case 3: $skor_label = '3 - Cukup'; break;
                                        case 4: $skor_label = '4 - Baik'; break;
                                        case 5: $skor_label = '5 - Sangat Baik'; break;
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><strong><?php echo htmlspecialchars($row['nama_kriteria']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                                    <td><span class="label label-primary"><?php echo $skor_label; ?></span></td>
                                    <td><?php echo htmlspecialchars($row['catatan']) ?: '-'; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="alert alert-info">
                        <strong>Rata-rata Skor:</strong> <span style="font-size:18px;font-weight:bold;"><?php echo $rata_rata; ?></span> / 5.00
                        <?php
                        if ($rata_rata >= 4.5) echo ' ⭐⭐⭐⭐⭐ <strong>(Sangat Baik)</strong>';
                        elseif ($rata_rata >= 3.5) echo ' ⭐⭐⭐⭐ <strong>(Baik)</strong>';
                        elseif ($rata_rata >= 2.5) echo ' ⭐⭐⭐ <strong>(Cukup)</strong>';
                        elseif ($rata_rata >= 1.5) echo ' ⭐⭐ <strong>(Kurang)</strong>';
                        else echo ' ⭐ <strong>(Sangat Kurang)</strong>';
                        ?>
                    </div>

                    <hr>
                    <h4>Catatan Umum</h4>
                    <div class="well"><?php echo nl2br(htmlspecialchars($data_penilaian['catatan_umum'])) ?: '<em>Tidak ada catatan</em>'; ?></div>

                    <hr>
                    <div class="btn-group" role="group">
                        <a href="index.php?page=lihat_penilaian" class="btn btn-default"><em class="fa fa-arrow-left"></em> Kembali</a>
                        <a href="index.php?page=lihat_penilaian&aksi=cetak&id=<?php echo $id_penilaian; ?>" class="btn btn-primary" target="_blank"><em class="fa fa-print"></em> Cetak / Print</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    return;
}

/**
 * ACTION: CETAK
 * Menampilkan halaman cetak penuh dengan logo instansi (tbl_site.logo) dan foto mahasiswa (kolom foto atau berdasarkan NIM).
 * Pada header, teks nama instansi digantikan oleh gambar logo (jika ada).
 */
if ($aksi === 'cetak' && $id_penilaian) {
    $id_penilaian_esc = mysqli_real_escape_string($kon, $id_penilaian);
    $q = mysqli_query($kon, "
        SELECT 
            p.id_penilaian,
            p.id_mahasiswa,
            m.nama,
            m.nim,
            m.universitas,
            m.jurusan,
            m.foto AS foto_mahasiswa,
            pb.nama_pembimbing,
            pb.email,
            pb.no_telepon,
            p.tanggal_penilaian,
            p.periode_mulai,
            p.periode_akhir,
            p.catatan_umum,
            p.status_penilaian,
            p.created_at
        FROM tbl_penilaian_kinerja p
        INNER JOIN tbl_mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
        LEFT JOIN tbl_pembimbing pb ON p.id_pembimbing = pb.id_pembimbing
        WHERE p.id_penilaian = '$id_penilaian_esc'
    ");
    if (!$q || mysqli_num_rows($q) == 0) {
        echo "<div class='alert alert-danger'>Data penilaian tidak ditemukan.</div>";
        return;
    }
    $data_penilaian = mysqli_fetch_assoc($q);

    $qdet = mysqli_query($kon, "
        SELECT dp.skor, dp.catatan, kp.nama_kriteria, kp.deskripsi
        FROM tbl_detail_penilaian dp
        INNER JOIN tbl_kriteria_penilaian kp ON dp.id_kriteria = kp.id_kriteria
        WHERE dp.id_penilaian = '$id_penilaian_esc'
        ORDER BY kp.id_kriteria
    ");
    $detail_data = [];
    $total_skor = 0; $jumlah_kriteria = 0;
    while ($r = mysqli_fetch_assoc($qdet)) {
        $detail_data[] = $r;
        $total_skor += $r['skor'];
        $jumlah_kriteria++;
    }
    $rata_rata = ($jumlah_kriteria>0) ? round($total_skor / $jumlah_kriteria, 2) : 0;

    // Ambil data site (logo)
    $qsite = mysqli_query($kon, "SELECT nama_instansi, logo FROM tbl_site LIMIT 1");
    $site = $qsite ? mysqli_fetch_assoc($qsite) : [];
    $nama_instansi = $site['nama_instansi'] ?? 'INSTANSI';
    $site_logo_file = $site['logo'] ?? 'bandarmasih.png';

    // Tentukan filesystem path dan URL path untuk logo & foto mahasiswa
    $logo_fs = $projectRootFs . '/apps/pengaturan/logo/' . basename($site_logo_file);
    $logo_url = $projectUrl . '/apps/pengaturan/logo/' . basename($site_logo_file);
    if (!file_exists($logo_fs)) {
        // fallback default jika tidak ada
        $logo_fs = $projectRootFs . '/apps/pengaturan/logo/bandarmasih.png';
        $logo_url = $projectUrl . '/apps/pengaturan/logo/bandarmasih.png';
    }

    $photo_fs = '';
    $photo_url = '';
    if (!empty($data_penilaian['foto_mahasiswa'])) {
        $candidate_fs = $projectRootFs . '/apps/mahasiswa/foto/' . basename($data_penilaian['foto_mahasiswa']);
        $candidate_url = $projectUrl . '/apps/mahasiswa/foto/' . basename($data_penilaian['foto_mahasiswa']);
        if (file_exists($candidate_fs)) {
            $photo_fs = $candidate_fs;
            $photo_url = $candidate_url;
        }
    }
    if (!$photo_fs) {
        $nim = $data_penilaian['nim'];
        $candidate1_fs = $projectRootFs . "/apps/mahasiswa/foto/{$nim}.jpg";
        $candidate1_url = $projectUrl . "/apps/mahasiswa/foto/{$nim}.jpg";
        $candidate2_fs = $projectRootFs . "/apps/mahasiswa/foto/{$nim}.png";
        $candidate2_url = $projectUrl . "/apps/mahasiswa/foto/{$nim}.png";
        if (file_exists($candidate1_fs)) {
            $photo_fs = $candidate1_fs; $photo_url = $candidate1_url;
        } elseif (file_exists($candidate2_fs)) {
            $photo_fs = $candidate2_fs; $photo_url = $candidate2_url;
        }
    }

    // Output HTML halaman cetak
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Cetak Penilaian - <?php echo htmlspecialchars($data_penilaian['nama']); ?></title>
        <style>
            body{font-family:Arial,Helvetica,sans-serif;color:#333}
            .container{max-width:900px;margin:0 auto;padding:20px}
            .header{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px}
            .left, .center, .right{display:flex;align-items:center}
            .left img.logo{max-height:90px;margin-right:12px}
            .center{flex-direction:column;text-align:center}
            .center img.center-logo{max-height:120px;margin-bottom:6px}
            .center h2{margin:0;font-size:20px}
            .center p{margin:2px 0;font-size:13px;color:#555}
            .right img.photo{max-height:100px;border:1px solid #ddd;padding:3px;background:#fff}
            table{width:100%;border-collapse:collapse;margin-top:10px}
            th,td{border:1px solid #ddd;padding:8px}
            th{background:#f0f0f0}
            @media print{ .no-print{display:none} }
        </style>
    </head>
    <body>
    <div class="container">
        <div class="no-print" style="text-align:center;margin-bottom:10px">
            <button onclick="window.print()">Cetak</button>
            <a href="#" onclick="window.close();return false;">Tutup</a>
        </div>

        <div class="header">
            <div class="left">
                <?php if ($logo_url && file_exists($logo_fs)): ?>
                    <img src="<?php echo htmlspecialchars($logo_url); ?>" class="logo" alt="Logo">
                <?php endif; ?>
            </div>

            <div class="center">
                <?php if ($logo_url && file_exists($logo_fs)): ?>
                    <img src="<?php echo htmlspecialchars($logo_url); ?>" class="center-logo" alt="Logo Instansi">
                <?php else: ?>
                    <h2><?php echo htmlspecialchars($nama_instansi); ?></h2>
                <?php endif; ?>
                <p><?php echo date('d-m-Y', strtotime($data_penilaian['tanggal_penilaian'])); ?></p>
            </div>

            <div class="right">
                <?php if ($photo_url && $photo_fs && file_exists($photo_fs)): ?>
                    <img src="<?php echo htmlspecialchars($photo_url); ?>" class="photo" alt="Foto Mahasiswa">
                <?php endif; ?>
            </div>
        </div>

        <h4>Data Mahasiswa</h4>
        <table>
            <tr><th style="width:25%">Nama</th><td><?php echo htmlspecialchars($data_penilaian['nama']); ?></td></tr>
            <tr><th>NIM</th><td><?php echo htmlspecialchars($data_penilaian['nim']); ?></td></tr>
            <tr><th>Universitas</th><td><?php echo htmlspecialchars($data_penilaian['universitas'] ?: '-'); ?></td></tr>
            <tr><th>Jurusan</th><td><?php echo htmlspecialchars($data_penilaian['jurusan'] ?: '-'); ?></td></tr>
        </table>

        <h4 style="margin-top:15px">Hasil Penilaian</h4>
        <table>
            <thead><tr><th>No</th><th>Kriteria</th><th>Deskripsi</th><th>Skor</th><th>Catatan</th></tr></thead>
            <tbody>
                <?php $no=1; foreach($detail_data as $d): ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($d['nama_kriteria']); ?></td>
                    <td><?php echo htmlspecialchars($d['deskripsi']); ?></td>
                    <td style="text-align:center"><?php echo htmlspecialchars($d['skor']); ?></td>
                    <td><?php echo htmlspecialchars($d['catatan']) ?: '-'; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div style="margin-top:15px">
            <strong>Rata-rata Skor:</strong> <?php echo $rata_rata; ?> / 5.00
        </div>

    </div>
    </body>
    </html>
    <?php
    return;
}

/**
 * Default: jika mahasiswa -> tampilkan daftar penilaian miliknya.
 */
if (in_array($level, ['Mahasiswa','mahasiswa'])) {
    // cari id_mahasiswa
    $id_mahasiswa = $_SESSION['id_mahasiswa'] ?? null;
    if (!$id_mahasiswa) {
        $kode = mysqli_real_escape_string($kon, $_SESSION['kode_pengguna'] ?? '');
        if ($kode) {
            $q = mysqli_query($kon, "SELECT id_mahasiswa FROM tbl_mahasiswa WHERE kode_pengguna = '$kode' LIMIT 1");
            if ($q && mysqli_num_rows($q) > 0) {
                $tmp = mysqli_fetch_assoc($q);
                $id_mahasiswa = $tmp['id_mahasiswa'];
            }
        }
    }
    if (!$id_mahasiswa) {
        echo "<div class='alert alert-warning'>Data mahasiswa tidak ditemukan. Hubungi admin.</div>";
        return;
    }

    $idm = mysqli_real_escape_string($kon, $id_mahasiswa);
    $q = mysqli_query($kon, "
        SELECT p.id_penilaian, p.tanggal_penilaian, p.periode_mulai, p.periode_akhir, p.status_penilaian, pb.nama_pembimbing
        FROM tbl_penilaian_kinerja p
        LEFT JOIN tbl_pembimbing pb ON p.id_pembimbing = pb.id_pembimbing
        WHERE p.id_mahasiswa = '$idm'
        ORDER BY p.created_at DESC
    ");
    ?>
    <div class="panel panel-default">
        <div class="panel-heading"><strong>Penilaian Kinerja Anda</strong></div>
        <div class="panel-body">
            <p>Daftar penilaian untuk Anda.</p>
            <div class="table-responsive">
                <table class="table table-striped table-bordered" id="tabelPenilaianSaya">
                    <thead><tr><th>No</th><th>Tanggal</th><th>Periode</th><th>Pembimbing</th><th>Status</th><th>Aksi</th></tr></thead>
                    <tbody>
                        <?php if ($q && mysqli_num_rows($q)>0): $no=1; while($r = mysqli_fetch_assoc($q)):
                            $periode = ($r['periode_mulai'] ? date('d-m-Y', strtotime($r['periode_mulai'])) : '-') . ' s/d ' . ($r['periode_akhir'] ? date('d-m-Y', strtotime($r['periode_akhir'])) : '-');
                            $status = $r['status_penilaian'];
                            if ($status == 'Draft') $status_label = '<span class="label label-warning">Draft</span>';
                            elseif ($status == 'Selesai') $status_label = '<span class="label label-info">Selesai</span>';
                            else $status_label = '<span class="label label-success">Disetujui</span>';
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $r['tanggal_penilaian'] ? date('d-m-Y', strtotime($r['tanggal_penilaian'])) : '-'; ?></td>
                            <td><?php echo $periode; ?></td>
                            <td><?php echo htmlspecialchars($r['nama_pembimbing'] ?? '-'); ?></td>
                            <td><?php echo $status_label; ?></td>
                            <td>
                                <a href="index.php?page=lihat_penilaian&aksi=lihat&id=<?php echo $r['id_penilaian']; ?>" class="btn btn-info btn-xs"><em class="fa fa-eye"></em> Lihat</a>
                                <a href="index.php?page=lihat_penilaian&aksi=cetak&id=<?php echo $r['id_penilaian']; ?>" target="_blank" class="btn btn-primary btn-xs"><em class="fa fa-print"></em> Cetak</a>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr><td colspan="6" class="text-center"><em>Belum ada data penilaian</em></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
    (function(){
        if (typeof $ === 'function' && $.fn.DataTable) {
            if ($.fn.DataTable.isDataTable('#tabelPenilaianSaya')) {
                $('#tabelPenilaianSaya').DataTable().destroy();
            }
            $('#tabelPenilaianSaya').DataTable({
                "language": { "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Indonesian.json" }
            });
        }
    })();
    </script>
    <?php
    return;
}

// Jika bukan mahasiswa dan bukan admin -> akses ditolak
echo "<div class='alert alert-danger'>Anda tidak memiliki hak untuk mengakses halaman ini.</div>";