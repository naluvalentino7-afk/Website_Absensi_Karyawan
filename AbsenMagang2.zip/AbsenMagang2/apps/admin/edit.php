<?php
session_start();
if (isset($_POST['edit_admin'])) {
    
    //Include file koneksi, untuk koneksikan ke database
    include '../../config/database.php';
    
    //Fungsi untuk mencegah inputan karakter yang tidak sesuai
    function input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    //Cek apakah ada kiriman form dari method post
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //Memulai transaksi
        mysqli_query($kon,"START TRANSACTION");
        
        // Validasi dan input data dengan aman
        $id_admin = input($_POST["id_admin"] ?? '');
        $nama = input($_POST["nama"] ?? '');
        $nip = input($_POST["nip"] ?? '');
        $email = input($_POST["email"] ?? '');
        
        // Validasi data tidak kosong
        if (empty($id_admin) || empty($nama) || empty($nip) || empty($email)) {
            mysqli_query($kon,"ROLLBACK");
            header("Location:../../index.php?page=admin&edit=gagal&pesan=data_kosong");
            exit;
        }

        //Query untuk update tbl_admin (Gunakan prepared statement untuk keamanan)
        $sql = "UPDATE tbl_admin SET 
                nama=?, 
                nip=?, 
                email=?
                WHERE id_admin=?";
        
        $stmt = mysqli_prepare($kon, $sql);
        mysqli_stmt_bind_param($stmt, "sssi", $nama, $nip, $email, $id_admin);
        
        //Mengeksekusi query 
        $edit_admin = mysqli_stmt_execute($stmt);

        //Validasi jika data admin berhasil di update
        if ($edit_admin) {
            mysqli_query($kon,"COMMIT");
            header("Location:../../index.php?page=admin&edit=berhasil");
        }
        else {
            //Validasi jika data admin gagal di update
            mysqli_query($kon,"ROLLBACK");
            header("Location:../../index.php?page=admin&edit=gagal");
        }
        mysqli_stmt_close($stmt);
        exit;
    }
}
?>

<?php 
    include '../../config/database.php';
    
    // Validasi id_admin ada
    if (!isset($_POST["id_admin"]) || empty($_POST["id_admin"])) {
        echo "Error: ID Admin tidak ditemukan";
        exit;
    }
    
    $id_admin = intval($_POST["id_admin"]); // Konversi ke integer untuk keamanan
    $sql = "SELECT * FROM tbl_admin WHERE id_admin=$id_admin LIMIT 1";
    $hasil = mysqli_query($kon, $sql);
    
    // Validasi query berhasil
    if (!$hasil) {
        echo "Error: " . mysqli_error($kon);
        exit;
    }
    
    $data = mysqli_fetch_array($hasil);
    
    // Validasi data ditemukan
    if (!$data) {
        echo "Error: Data admin tidak ditemukan";
        exit;
    }
?>

<form action="apps/admin/edit.php" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="col-sm-7">
            <input type="hidden" name="id_admin" class="form-control" value="<?php echo htmlspecialchars($data['id_admin']); ?>">
            <div class="form-group">
                <label>Nama Lengkap :</label>
                <input type="text" name="nama" class="form-control" value="<?php echo htmlspecialchars($data['nama']); ?>" placeholder="Masukan Nama Lengkap" required>
            </div>
        </div>
        <div class="col-sm-5">
            <div class="form-group">
                <label>Nomor Induk Pegawai (NIP) :</label>
                <input type="text" name="nip" class="form-control" value="<?php echo htmlspecialchars($data['nip']); ?>" placeholder="Masukan Nomor Induk Pegawai" required>
            </div>
        </div>
        <div class="col-sm-7">
            <div class="form-group">
                <label>Email :</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($data['email']); ?>" placeholder="Masukan Email" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <br>
                <button type="submit" name="edit_admin" id="Submit" class="btn btn-warning"><i class="fa fa-edit"></i> Update</button>
            </div>
        </div>
    </div>
</form>

<style>
    .file {
        visibility: hidden;
        position: absolute;
    }
</style>