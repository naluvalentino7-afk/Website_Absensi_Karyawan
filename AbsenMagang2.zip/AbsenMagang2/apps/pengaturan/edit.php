<?php
session_start();
if (isset($_POST['ubah_aplikasi'])) {
    include '../../config/database.php';
    
    function input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        mysqli_query($kon,"START TRANSACTION");
        
        $id_site = $_POST["id"] ?? null;
        
        // Validasi $id_site
        if (!isset($id_site) || !is_numeric($id_site)) {
            die("Error: ID tidak valid. Pastikan form mengirim 'id' yang numerik.");
        }
        $id_site = (int) $id_site;
        
        $nama_instansi = input($_POST["nama_instansi"] ?? '');
        $pimpinan = input($_POST["pimpinan"] ?? '');
        $pembimbing = input($_POST["pembimbing"] ?? '');
        $no_telp = input($_POST["no_telp"] ?? '');
        $alamat = input($_POST["alamat"] ?? '');
        $website = input($_POST["website"] ?? '');
        $logo_sebelumnya = input($_POST["logo_sebelumnya"] ?? '');
        
        $logo = $_FILES['logo']['name'] ?? '';
        $ekstensi_diperbolehkan = array('png','jpg','jpeg');
        
        // PERBAIKAN: Gunakan path absolut dengan __DIR__
        $logo_dir = __DIR__ . '/../../logo/';
        
        // Cek apakah folder logo ada, jika tidak buat otomatis
        if (!is_dir($logo_dir)) {
            if (!mkdir($logo_dir, 0755, true)) {
                die("Error: Folder logo tidak bisa dibuat. Periksa permission.");
            }
        }
        
        $update_profil_aplikasi = false;

        if (!empty($logo)){
            $x = explode('.', $logo);
            $ekstensi = strtolower(end($x));
            $file_tmp = $_FILES['logo']['tmp_name'];
            
            if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
                // Buat nama file unik untuk mencegah duplikat
                $logo_baru = time() . '_' . basename($logo);
                $logo_path = $logo_dir . $logo_baru;
                
                if (move_uploaded_file($file_tmp, $logo_path)) {
                    // Hapus logo sebelumnya jika ada
                    $logo_path_sebelumnya = $logo_dir . $logo_sebelumnya;
                    if (!empty($logo_sebelumnya) && file_exists($logo_path_sebelumnya)) {
                        unlink($logo_path_sebelumnya);
                    }
                    
                    // MENGGUNAKAN PREPARED STATEMENT (LEBIH AMAN)
                    $stmt = $kon->prepare("UPDATE tbl_site SET nama_instansi=?, pimpinan=?, pembimbing=?, no_telp=?, alamat=?, website=?, logo=? WHERE id_site=?");
                    $stmt->bind_param("sssssssi", $nama_instansi, $pimpinan, $pembimbing, $no_telp, $alamat, $website, $logo_baru, $id_site);
                    $update_profil_aplikasi = $stmt->execute();
                } else {
                    die("Error: Gagal mengupload logo baru. Path: " . $logo_path . " | Tmp: " . $file_tmp);
                }
            } else {
                die("Error: Ekstensi file logo tidak diperbolehkan. Hanya png, jpg, jpeg.");
            }
        } else {
            // MENGGUNAKAN PREPARED STATEMENT (LEBIH AMAN) - TANPA LOGO
            $stmt = $kon->prepare("UPDATE tbl_site SET nama_instansi=?, pimpinan=?, pembimbing=?, no_telp=?, alamat=?, website=? WHERE id_site=?");
            $stmt->bind_param("ssssssi", $nama_instansi, $pimpinan, $pembimbing, $no_telp, $alamat, $website, $id_site);
            $update_profil_aplikasi = $stmt->execute();
        }
        
        // Cek hasil eksekusi query
        if ($update_profil_aplikasi) {
            mysqli_query($kon,"COMMIT");
            header("Location:../../index.php?page=pengaturan&edit=berhasil");
            exit();
        } else {
            mysqli_query($kon,"ROLLBACK");
            header("Location:../../index.php?page=pengaturan&edit=gagal");
            exit();
        }
    }
}
?>