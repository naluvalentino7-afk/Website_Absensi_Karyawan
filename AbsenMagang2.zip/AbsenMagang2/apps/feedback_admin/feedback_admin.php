<?php
// feedback_admin.php
// Pastikan session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Pastikan hanya admin
if (!isset($_SESSION['level']) || strtolower($_SESSION['level']) !== 'admin') {
    die("Akses Ditolak - Hanya Admin");
}

// Include DB
if (!file_exists('config/database.php')) {
    die("File config/database.php tidak ditemukan.");
}
include 'config/database.php';
if (!isset($kon) || !($kon instanceof mysqli)) {
    die("Koneksi database tidak tersedia.");
}

// Proses hapus (disarankan via POST, tapi kita dukung GET dengan sanitasi minimal)
if (isset($_GET['action']) && $_GET['action'] === 'hapus' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    if ($id > 0) {
        // Gunakan prepared statement; menangani bila kolom id_feedback atau id
        // Query menghapus baris yang cocok di salah satu kolom
        $stmt = mysqli_prepare($kon, "DELETE FROM tbl_feedback WHERE id_feedback = ? OR id = ?");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ii", $id, $id);
            $ok = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            if ($ok) {
                echo "<script>alert('Feedback berhasil dihapus!'); window.location.href='index.php?page=feedback_admin';</script>";
                exit;
            } else {
                $err = htmlspecialchars(mysqli_error($kon));
                echo "<script>alert('Gagal menghapus feedback: {$err}'); window.location.href='index.php?page=feedback_admin';</script>";
                exit;
            }
        } else {
            $err = htmlspecialchars(mysqli_error($kon));
            echo "<script>alert('Gagal mempersiapkan query: {$err}'); window.location.href='index.php?page=feedback_admin';</script>";
            exit;
        }
    } else {
        echo "<script>alert('ID tidak valid.'); window.location.href='index.php?page=feedback_admin';</script>";
        exit;
    }
}

// Ambil data feedback, bergabung dengan tbl_mahasiswa jika memungkinkan
$query_sql = "SELECT f.*, m.nama 
              FROM tbl_feedback f
              LEFT JOIN tbl_mahasiswa m ON (f.kode_pengguna = m.kode_mahasiswa OR f.kode_pengguna = m.id_mahasiswa)
              ORDER BY COALESCE(f.tanggal_feedback, f.tanggal) DESC, COALESCE(f.id_feedback, f.id) DESC";

$hasil = mysqli_query($kon, $query_sql);
if (!$hasil) {
    // fallback to simple select
    $hasil = mysqli_query($kon, "SELECT * FROM tbl_feedback ORDER BY id_feedback DESC, id DESC");
}
?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Feedback Mahasiswa</h1>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <span class="pull-left" style="padding-top: 5px;">Daftar Feedback dari Mahasiswa</span>
                <a href="apps/feedback_admin/cetak_feedback.php" target="_blank" class="btn btn-success btn-sm pull-right">
                    <i class="fa fa-print"></i> Cetak Laporan
                </a>
            </div>
            <div class="panel-body">
                <p class="text-muted"><strong>Catatan:</strong> Admin hanya dapat melihat dan menghapus feedback mahasiswa. Tidak ada fitur untuk mengisi feedback.</p>
                <br>
                
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th width="5%" class="text-center">No</th>
                                <th width="20%">Nama Mahasiswa</th>
                                <th>Isi Feedback</th>
                                <th width="20%">Tanggal</th>
                                <th width="10%" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($hasil && mysqli_num_rows($hasil) > 0) {
                                $no = 1;
                                while ($row = mysqli_fetch_assoc($hasil)) {
                                    $isi = $row['pesan'] ?? $row['isi_feedback'] ?? $row['pesan_feedback'] ?? '-';
                                    $tgl = $row['tanggal'] ?? $row['tanggal_feedback'] ?? '-';
                                    $nama_mahasiswa = $row['nama'] ?? $row['nama_mahasiswa'] ?? $row['kode_pengguna'] ?? '-';
                                    $id = $row['id'] ?? $row['id_feedback'] ?? 0;
                                    ?>
                                    <tr>
                                        <td class="text-center"><?php echo $no++; ?></td>
                                        <td><?php echo htmlspecialchars($nama_mahasiswa); ?></td>
                                        <td><?php echo nl2br(htmlspecialchars($isi)); ?></td>
                                        <td><?php echo htmlspecialchars($tgl); ?></td>
                                        <td class="text-center">
                                            <a href="index.php?page=feedback_admin&action=hapus&id=<?php echo (int)$id; ?>" 
                                               class="btn btn-danger btn-xs" 
                                               onclick="return confirm('Apakah Anda yakin ingin menghapus feedback ini?');">
                                                <i class="fa fa-trash"></i> Hapus
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                echo "<tr><td colspan='5' class='text-center'>Belum ada feedback dari mahasiswa.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>