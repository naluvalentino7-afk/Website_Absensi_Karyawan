<?php
// Memastikan hanya admin yang bisa mengakses halaman ini
if ($_SESSION['level'] != 'Admin' && $_SESSION['level'] != 'admin') {
    header("Location: index.php?page=beranda");
    exit();
}

// Menghubungkan database
include 'config/database.php';

// Query untuk mengambil data feedback dari mahasiswa
$query_feedback = mysqli_query($kon, "SELECT * FROM tbl_feedback ORDER BY tanggal_feedback DESC");

// Jika ada error dalam query, tampilkan pesan
if (!$query_feedback) {
    echo "<div class='alert alert-danger'>Error: " . mysqli_error($kon) . "</div>";
    exit();
}
?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Feedback Mahasiswa</h1>
    </div>
</div><!--/.row-->

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">Daftar Feedback dari Mahasiswa
                <div class="pull-right">
                    <button type="button" onclick="window.print()" class="btn btn-success btn-sm"><i class="fa fa-print"></i> Cetak Laporan</button>
                </div>
            </div>
            <div class="panel-body">
                <p><strong>Catatan:</strong> Admin hanya dapat melihat dan menghapus feedback mahasiswa. Tidak ada fitur untuk mengisi feedback.</p>
                <?php if (mysqli_num_rows($query_feedback) > 0): ?>
                    <table class="table table-striped table-bordered" id="dataTable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Mahasiswa</th>
                                <th>Isi Feedback</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            while ($row = mysqli_fetch_array($query_feedback)) {
                                echo "<tr>";
                                echo "<td>" . $no++ . "</td>";
                                echo "<td>" . htmlspecialchars($row['nama_mahasiswa']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['isi_feedback']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['tanggal_feedback']) . "</td>";
                                echo "<td>
                                        <a href='apps/feedback_admin/hapus_feedback.php?id=" . $row['id_feedback'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Apakah Anda yakin ingin menghapus feedback ini?\")'>Hapus</a>
                                      </td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="alert alert-info">Belum ada feedback dari mahasiswa.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><!--/.row-->

<!-- Script untuk DataTables -->
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('#dataTable').DataTable();
    });
</script>