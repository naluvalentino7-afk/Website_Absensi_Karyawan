<?php
    session_start();
    
    // Validasi akses hanya admin
    if (!isset($_SESSION['level']) || ($_SESSION['level'] != 'Admin' && $_SESSION['level'] != 'admin')) {
        die('Akses Ditolak - Hanya Admin');
    }

    require('../../source/plugin/fpdf/fpdf.php');
    $pdf = new FPDF('P', 'mm', 'Letter');

    include '../../config/database.php';
    include '../../config/function.php';
    
    // Ambil data instansi
    $query = mysqli_query($kon, "SELECT * FROM tbl_site LIMIT 1");    
    $row = mysqli_fetch_array($query);
    $pembimbing = isset($row['pembimbing']) ? $row['pembimbing'] : '';
    $logo = isset($row['logo']) ? $row['logo'] : '';

    $pdf->AddPage();

    // === LOGO & HEADER ===
    if (!empty($logo) && file_exists('pengaturan/logo/'.$logo)) {
        $pdf->Image('pengaturan/logo/'.$logo, 15, 5, 20, 20);
    }
    
    $nama_instansi = isset($row['nama_instansi']) ? $row['nama_instansi'] : 'INSTANSI MAGANG';
    $alamat        = isset($row['alamat']) ? $row['alamat'] : '';
    $no_telp       = isset($row['no_telp']) ? $row['no_telp'] : '';
    $website       = isset($row['website']) ? $row['website'] : '';

    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(0,7,strtoupper($nama_instansi),0,1,'C');
    $pdf->SetFont('Arial','',9);
    $pdf->Cell(0,5,$alamat . (!empty($no_telp) ? ', Telp: '.$no_telp : ''),0,1,'C');
    $pdf->Cell(0,5,$website,0,1,'C');

    // === GARIS PEMBATAS ===
    $pdf->SetLineWidth(0.8);
    $pdf->Line(10,31,206,31);
    $pdf->SetLineWidth(0.2);
    $pdf->Line(10,32,206,32);

    // === JUDUL LAPORAN ===
    $pdf->SetFont('Arial','B',13);
    $pdf->Cell(0,6,'',0,1,'C');
    $pdf->Cell(0,7,'LAPORAN FEEDBACK MAHASISWA',0,1,'C');
    $pdf->SetFont('Arial','',9);
    $pdf->Cell(0,5,'Tanggal Cetak: '.date('d-m-Y H:i:s'),0,1,'C');
    $pdf->Ln(4);

    // === TABLE HEADER ===
    $pdf->SetFont('Arial','B',9);
    $pdf->Cell(10,7,'No',1,0,'C');
    $pdf->Cell(45,7,'Kode / Nama Pengguna',1,0,'C');
    $pdf->Cell(105,7,'Isi Feedback',1,0,'C');
    $pdf->Cell(36,7,'Tanggal',1,1,'C');
    $pdf->SetFont('Arial','',9);

    // === QUERY DATA FEEDBACK (Menggunakan Nama Kolom Sesuai phpMyAdmin) ===
    $sql = "SELECT tbl_feedback.*, tbl_mahasiswa.nama 
            FROM tbl_feedback 
            LEFT JOIN tbl_mahasiswa ON tbl_feedback.kode_pengguna = tbl_mahasiswa.kode_mahasiswa 
            ORDER BY tbl_feedback.id DESC";
    $hasil = mysqli_query($kon, $sql);

    // Fallback jika query JOIN error
    if (!$hasil) {
        $sql = "SELECT * FROM tbl_feedback ORDER BY id DESC";
        $hasil = mysqli_query($kon, $sql);
    }

    $no = 1;
    $total_feedback = 0;

    if ($hasil && mysqli_num_rows($hasil) > 0) {
        while ($data = mysqli_fetch_array($hasil)) {
            // Ambil nama mahasiswa atau fallback ke kode_pengguna
            $pengguna = !empty($data['nama']) ? $data['nama'] : (isset($data['kode_pengguna']) ? $data['kode_pengguna'] : '-');
            
            // PERBAIKAN UTAMA: Mengambil dari 'isi_feedback' dan 'tanggal_feedback'
            $isi_feedback = isset($data['isi_feedback']) ? $data['isi_feedback'] : (isset($data['pesan']) ? $data['pesan'] : '-');
            $tgl_feedback = isset($data['tanggal_feedback']) ? $data['tanggal_feedback'] : (isset($data['tanggal']) ? $data['tanggal'] : '-');

            $pdf->Cell(10,6,$no,1,0,'C');
            $pdf->Cell(45,6,substr($pengguna, 0, 24),1,0,'L');
            $pdf->Cell(105,6,substr($isi_feedback, 0, 65),1,0,'L');
            $pdf->Cell(36,6,$tgl_feedback,1,1,'C');
            
            $no++;
            $total_feedback++;
        }
    } else {
        $pdf->Cell(196,6,'Belum ada data feedback',1,1,'C');
    }

    // === TOTAL FEEDBACK ===
    $pdf->SetFont('Arial','B',9);
    $pdf->Cell(160,6,'TOTAL FEEDBACK: ',1,0,'R');
    $pdf->Cell(36,6,$total_feedback.' Item',1,1,'C');

    // === TTD PEMBIMBING ===
    $pdf->Ln(10);
    $pdf->SetFont('Arial','',10);
    
    // Menempatkan blok TTD di sebelah kanan
    $pdf->Cell(120,5,'',0,0);
    $pdf->Cell(76,5,'Banjarmasin, '.date('d F Y'),0,1,'C');
    
    $pdf->Cell(120,5,'',0,0);
    $pdf->Cell(76,5,'Pembimbing Magang,',0,1,'C');
    
    $pdf->Ln(18); // Jarak untuk tanda tangan
    
    $pdf->Cell(120,5,'',0,0);
    $pdf->SetFont('Arial','B',10);
    $pdf->Cell(76,5,(!empty($pembimbing) ? $pembimbing : '(___________________)'),0,1,'C');
    
    // === OUTPUT PDF ===
    $namafile = 'Laporan-Feedback-'.date('YmdHis').'.pdf';
    $pdf->Output('I', $namafile); // Gunakan 'I' agar preview terbuka di browser (opsional, ganti 'D' jika ingin langsung download)
?>