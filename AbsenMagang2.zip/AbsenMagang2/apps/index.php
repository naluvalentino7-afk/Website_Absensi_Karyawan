<?php
// apps/beranda/index.php
// Asumsi: $kon (koneksi DB) dan session sudah tersedia dari index.php utama

// Debug marker (sementara) - hapus bila sudah ok
// echo "<!-- BERANDA_CUSTOM_LOADED -->";

// Statistik sederhana
$total_mahasiswa = 0;
$total_kegiatan = 0;
$absen_today = 0;
$late_today = 0;

$q = mysqli_query($kon, "SELECT COUNT(*) as cnt FROM tbl_mahasiswa");
if ($q) { $r = mysqli_fetch_assoc($q); $total_mahasiswa = $r['cnt']; }

$q = mysqli_query($kon, "SELECT COUNT(*) as cnt FROM tbl_kegiatan");
if ($q) { $r = mysqli_fetch_assoc($q); $total_kegiatan = $r['cnt']; }

$q = mysqli_query($kon, "SELECT COUNT(*) as cnt FROM tbl_absensi WHERE tanggal = CURDATE()");
if ($q) { $r = mysqli_fetch_assoc($q); $absen_today = $r['cnt']; }

$q = mysqli_query($kon, "SELECT COUNT(*) as cnt FROM tbl_absensi WHERE tanggal = CURDATE() AND waktu > '09:00:00'");
if ($q) { $r = mysqli_fetch_assoc($q); $late_today = $r['cnt']; }

// Data chart: 6 bulan terakhir (format YYYY-MM)
$chart_labels = [];
$chart_data = [];
$q = mysqli_query($kon, "SELECT DATE_FORMAT(tanggal, '%Y-%m') AS ym, COUNT(*) AS cnt
                         FROM tbl_absensi
                         WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
                         GROUP BY ym
                         ORDER BY ym ASC");
if ($q && mysqli_num_rows($q) > 0) {
    while ($row = mysqli_fetch_assoc($q)) {
        $chart_labels[] = $row['ym'];
        $chart_data[] = (int)$row['cnt'];
    }
} else {
    for ($i = 5; $i >= 0; $i--) {
        $m = date('Y-m', strtotime("-$i month"));
        $chart_labels[] = $m;
        $chart_data[] = 0;
    }
}

// Recent 10 absensi
$recent = [];
$q = mysqli_query($kon, "SELECT a.*, m.nama_mahasiswa FROM tbl_absensi a LEFT JOIN tbl_mahasiswa m ON a.id_mahasiswa = m.id_mahasiswa ORDER BY a.tanggal DESC, a.waktu DESC LIMIT 10");
if ($q) {
    while ($r = mysqli_fetch_assoc($q)) {
        $recent[] = $r;
    }
}
?>

<!-- pastikan path ini benar untuk project Anda -->
<link rel="stylesheet" href="/AbsenMagang2/apps/beranda/style.css">

<div class="row beranda-header">
    <div class="col-md-8">
        <h2>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</h2>
        <p class="muted">Ringkasan absen magang Anda — cepat, rapi, dan informatif.</p>
    </div>
    <div class="col-md-4 text-right hidden-xs">
        <img src="apps/pengaturan/logo/<?php echo htmlspecialchars($logo ?? ''); ?>" alt="Logo" class="beranda-logo">
    </div>
</div>

<div class="row stats-row">
    <div class="col-sm-6 col-md-3">
        <div class="stat-card stat-blue">
            <div class="stat-icon"><i class="fa fa-users"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?php echo number_format($total_mahasiswa); ?></div>
                <div class="stat-label">Total Mahasiswa</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="stat-card stat-green">
            <div class="stat-icon"><i class="fa fa-book"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?php echo number_format($total_kegiatan); ?></div>
                <div class="stat-label">Total Kegiatan</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="stat-card stat-orange">
            <div class="stat-icon"><i class="fa fa-calendar-check-o"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?php echo number_format($absen_today); ?></div>
                <div class="stat-label">Absen Hari Ini</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="stat-card stat-red">
            <div class="stat-icon"><i class="fa fa-clock-o"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?php echo number_format($late_today); ?></div>
                <div class="stat-label">Terlambat Hari Ini</div>
            </div>
        </div>
    </div>
</div>

<div class="row dashboard-main">
    <div class="col-md-6">
        <div class="panel panel-default">
            <div class="panel-heading"><strong>Grafik Kehadiran (6 bulan terakhir)</strong></div>
            <div class="panel-body">
                <canvas id="attendanceChart" height="200"></canvas>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="panel panel-default">
            <div class="panel-heading"><strong>10 Riwayat Absensi Terakhir</strong></div>
            <div class="panel-body">
                <table id="recentAbsence" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr><th>No</th><th>Nama</th><th>Tanggal</th><th>Waktu</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                    <?php $no = 1; foreach ($recent as $r): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($r['nama_mahasiswa'] ?? '—'); ?></td>
                            <td><?php echo htmlspecialchars($r['tanggal']); ?></td>
                            <td><?php echo htmlspecialchars($r['waktu']); ?></td>
                            <td>
                                <?php
                                    $st = $r['status'] ?? '';
                                    if ($st === '1' || $st === 'Hadir' || $st === 1) {
                                        if (!empty($r['waktu']) && $r['waktu'] > '09:00:00') {
                                            echo "<span class='label label-warning'>Hadir (Terlambat)</span>";
                                        } else {
                                            echo "<span class='label label-success'>Hadir</span>";
                                        }
                                    } else {
                                        echo "<span class='label label-default'>Tidak Hadir</span>";
                                    }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <a href="index.php?page=riwayat" class="btn btn-primary btn-sm">Lihat Semua Riwayat</a>
            </div>
        </div>
    </div>
</div>

<!-- CDN: Chart.js dan DataTables (hapus jika sudah dimuat di layout utama) -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<script>
    const labels = <?php echo json_encode(array_values($chart_labels)); ?>;
    const dataValues = <?php echo json_encode(array_values($chart_data)); ?>;

    const ctx = document.getElementById('attendanceChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Jumlah Absen',
                data: dataValues,
                borderColor: 'rgba(54,162,235,1)',
                backgroundColor: 'rgba(54,162,235,0.15)',
                fill: true,
                tension: 0.3,
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });

    $(document).ready(function(){
        $('#recentAbsence').DataTable({
            paging: true,
            searching: false,
            info: false,
            lengthChange: false,
            pageLength: 5,
            order: [[2, 'desc'], [3, 'desc']]
        });
    });
</script>