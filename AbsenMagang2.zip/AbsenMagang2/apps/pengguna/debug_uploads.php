<?php
    session_start();
    
    echo "<h2>DEBUG UPLOAD & DATABASE</h2>";
    echo "<pre>";
    
    // 1. Test Session
    echo "=== SESSION INFO ===\n";
    echo "Session Status: " . (session_status() === PHP_SESSION_ACTIVE ? "ACTIVE" : "INACTIVE") . "\n";
    echo "ID Mahasiswa: " . ($_SESSION["id_mahasiswa"] ?? "NOT SET") . "\n";
    echo "Level: " . ($_SESSION["level"] ?? "NOT SET") . "\n\n";
    
    // 2. Test Database
    echo "=== DATABASE CONNECTION ===\n";
    include 'config/database.php';
    
    if ($kon) {
        echo "✅ Connected\n";
        echo "Server: " . $kon->server_info . "\n\n";
        
        // 3. Check tbl_absensi
        echo "=== TABLE tbl_absensi ===\n";
        $result = $kon->query("DESCRIBE tbl_absensi");
        
        if ($result) {
            echo "Columns:\n";
            while ($row = $result->fetch_assoc()) {
                echo "  - " . $row['Field'] . " (" . $row['Type'] . ")\n";
            }
        } else {
            echo "❌ Table error: " . $kon->error . "\n";
        }
        echo "\n";
        
        // 4. Check data
        echo "=== DATA IN tbl_absensi (TODAY) ===\n";
        $today = date('Y-m-d');
        $sql = "SELECT * FROM tbl_absensi WHERE tanggal = '$today' LIMIT 5";
        $result = $kon->query($sql);
        
        if ($result && $result->num_rows > 0) {
            echo "Found records:\n";
            while ($row = $result->fetch_assoc()) {
                echo json_encode($row) . "\n";
            }
        } else {
            echo "❌ No records found for today\n";
        }
        echo "\n";
        
        // 5. Check uploads folder
        echo "=== UPLOADS FOLDER ===\n";
        $upload_dir = '../uploads/selfie/';
        if (is_dir($upload_dir)) {
            echo "✅ Folder exists\n";
            echo "Writable: " . (is_writable($upload_dir) ? "YES" : "NO") . "\n";
            
            $files = scandir($upload_dir);
            echo "Files: " . (count($files) - 2) . "\n";
            foreach ($files as $file) {
                if ($file !== '.' && $file !== '..') {
                    echo "  - " . $file . "\n";
                }
            }
        } else {
            echo "❌ Folder not found: " . realpath($upload_dir) . "\n";
        }
        
    } else {
        echo "❌ Connection failed: " . mysqli_connect_error() . "\n";
    }
    
    echo "</pre>";
    
    // 6. Test upload form
    echo "<hr>";
    echo "<h3>Test Upload Form</h3>";
    echo "<form method='POST' enctype='multipart/form-data'>";
    echo "<input type='file' name='test_file' accept='image/*'>";
    echo "<button type='submit'>Upload Test</button>";
    echo "</form>";
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['test_file'])) {
        echo "<h3>Upload Result:</h3>";
        echo "<pre>";
        $file = $_FILES['test_file'];
        echo "Name: " . $file['name'] . "\n";
        echo "Size: " . $file['size'] . "\n";
        echo "Type: " . $file['type'] . "\n";
        echo "Error: " . $file['error'] . "\n";
        echo "Tmp: " . $file['tmp_name'] . "\n";
        
        if ($file['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../uploads/selfie/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
                echo "Created folder\n";
            }
            
            $new_name = 'test_' . time() . '.jpg';
            $file_path = $upload_dir . $new_name;
            
            if (move_uploaded_file($file['tmp_name'], $file_path)) {
                echo "✅ File uploaded to: " . $file_path . "\n";
            } else {
                echo "❌ Move failed\n";
            }
        }
        echo "</pre>";
    }
?>