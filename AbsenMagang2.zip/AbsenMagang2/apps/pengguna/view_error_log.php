<?php
    echo "<h2>Error Log Viewer</h2>";
    echo "<pre>";
    
    $log_files = array(
        'Local Log' => 'simpan_selfie_error.log',
        'PHP Error Log' => 'php_error.log',
        'Apache Error Log' => 'C:/xampp/apache/logs/error.log'
    );
    
    foreach ($log_files as $name => $path) {
        echo "\n=== " . $name . " ===\n";
        echo "Path: " . $path . "\n";
        
        if (file_exists($path)) {
            echo "✅ File exists\n";
            $content = file_get_contents($path);
            echo "Size: " . strlen($content) . " bytes\n";
            echo "Last 50 lines:\n";
            $lines = explode("\n", $content);
            $last_lines = array_slice($lines, -50);
            echo implode("\n", $last_lines);
        } else {
            echo "❌ File not found\n";
        }
        echo "\n";
    }
    
    echo "</pre>";
?>