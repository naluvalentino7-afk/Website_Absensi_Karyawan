<?php
// Memastikan hanya admin yang bisa mengakses halaman ini
if (!isset($_SESSION['level']) || ($_SESSION['level'] != 'Admin' && $_SESSION['level'] != 'admin')) {
    header("Location: index.php?page=beranda");
    exit();
}

// Menghubungkan database
include 'config/database.php';

// Query Ambil data feedback
$sql_feedback = "SELECT tbl_feedback.*, tbl_mahasiswa.nama 
                 FROM tbl_feedback 
                 LEFT JOIN tbl_mahasiswa ON tbl_feedback.kode_pengguna = tbl_mahasiswa.kode_mahasiswa 
                 ORDER BY tbl_feedback.id DESC";
$query_feedback = mysqli_query($kon, $sql_feedback);

// Fallback jika query JOIN error
if (!$query_feedback) {
    $query_feedback = mysqli_query($kon, "SELECT * FROM tbl_feedback ORDER BY id DESC");
}

// Ambil data instansi untuk header print
$query_site = mysqli_query($kon, "SELECT * FROM tbl_site LIMIT 1");
$site = $query_site ? mysqli_fetch_array($query_site) : [];
$logo          = isset($site['logo']) ? $site['logo'] : '';
$nama_instansi = isset($site['nama_instansi']) ? $site['nama_instansi'] : 'INSTANSI MAGANG';
$alamat        = isset($site['alamat']) ? $site['alamat'] : '';
$no_telp       = isset($site['no_telp']) ? $site['no_telp'] : '';
$website       = isset($site['website']) ? $site['website'] : '';
?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Feedback Mahasiswa</h1>
    </div>
</div><!--/.row-->

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Daftar Feedback Mahasiswa Magang
                <div class="pull-right">
                    <a href="apps/cetak_feedback.php" class="btn btn-success btn-sm" target="_blank">
                        <i class="fa fa-file-pdf-o"></i> Cetak PDF
                    </a>
                    <button type="button" onclick="window.print()" class="btn btn-info btn-sm">
                        <i class="fa fa-print"></i> Print
                    </button>
                </div>
            </div>
            <div class="panel-body">
                
                <!-- ============ PRINT HEADER DENGAN LOGO ============ -->
                <div id="print-header" class="print-only" style="display: none; text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 3px solid #1a3a6b;">
                    <?php if (!empty($logo)): ?>
                    <div style="margin-bottom: 15px;">
                        <img src="apps/pengaturan/logo/<?php echo $logo; ?>" alt="Logo" style="height: 100px; display: inline-block;">
                    </div>
                    <?php endif; ?>
                    <h2 style="margin: 10px 0 5px 0; font-size: 22px; color: #1a3a6b; font-weight: bold;">
                        <?php echo strtoupper($nama_instansi); ?>
                    </h2>
                    <p style="margin: 5px 0; font-size: 13px; color: #333;">
                        <?php echo $alamat; ?> | Telp: <?php echo $no_telp; ?>
                    </p>
                    <p style="margin: 5px 0; font-size: 13px; color: #333;">
                        Website: <?php echo $website; ?>
                    </p>
                    
                    <!-- Garis Pembatas -->
                    <div style="border-top: 2px solid #1a3a6b; border-bottom: 1px solid #1a3a6b; margin: 15px 0; padding: 10px 0;">
                        <h3 style="margin: 0; font-size: 18px; color: #1a3a6b; font-weight: bold; text-decoration: underline;">
                            LAPORAN FEEDBACK MAHASISWA
                        </h3>
                        <p style="margin: 5px 0; font-size: 12px; color: #666;">
                            Tanggal Cetak: <?php echo date('d-m-Y H:i:s'); ?>
                        </p>
                    </div>
                </div>

                <p class="no-print"><strong>Catatan:</strong> Daftar kritik, saran, dan masukan yang dikirimkan oleh mahasiswa magang.</p>
                
                <?php if ($query_feedback && mysqli_num_rows($query_feedback) > 0): ?>
                    <table class="table table-striped table-bordered table-hover" id="feedbackTable">
                        <thead style="background-color: #1a3a6b; color: white;">
                            <tr>
                                <th style="width: 5%; text-align: center;">No</th>
                                <th style="width: 25%;">Kode / Nama Mahasiswa</th>
                                <th style="width: 50%;">Isi Feedback</th>
                                <th style="width: 20%; text-align: center;">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            $total_feedback = 0;
                            while ($row = mysqli_fetch_array($query_feedback)) {
                                $pengguna     = !empty($row['nama']) ? $row['nama'] : (isset($row['kode_pengguna']) ? $row['kode_pengguna'] : '-');
                                $isi_feedback = isset($row['isi_feedback']) ? $row['isi_feedback'] : (isset($row['pesan']) ? $row['pesan'] : '-');
                                $tgl_feedback = isset($row['tanggal_feedback']) ? $row['tanggal_feedback'] : (isset($row['tanggal']) ? $row['tanggal'] : '-');

                                echo "<tr>";
                                echo "<td style='text-align: center;'>" . $no++ . "</td>";
                                echo "<td>" . htmlspecialchars($pengguna) . "</td>";
                                echo "<td>" . nl2br(htmlspecialchars($isi_feedback)) . "</td>";
                                echo "<td style='text-align: center;'>" . htmlspecialchars($tgl_feedback) . "</td>";
                                echo "</tr>";
                                $total_feedback++;
                            }
                            ?>
                        </tbody>
                    </table>

                    <!-- ============ PRINT SUMMARY & TTD ============ -->
                    <div id="print-footer" class="print-only" style="display: none; margin-top: 40px;">
                        <div style="text-align: right; margin-bottom: 30px;">
                            <table style="width: 100%; border-collapse: collapse;">
                                <tr>
                                    <td style="text-align: right; padding: 8px; border: 1px solid #000; font-weight: bold; background-color: #f5f5f5;">TOTAL FEEDBACK:</td>
                                    <td style="text-align: center; padding: 8px; border: 1px solid #000; font-weight: bold; background-color: #fff; color: #1a3a6b; font-size: 16px; width: 150px;">
                                        <?php echo $total_feedback; ?> Item
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <!-- Tanda Tangan -->
                        <div style="margin-top: 50px;">
                            <div style="float: right; text-align: center; width: 280px;">
                                <p style="margin: 0 0 80px 0; font-size: 13px;">
                                    Mengetahui,<br>
                                    <strong>Pembimbing Magang</strong>
                                </p>
                                <p style="border-top: 2px solid #000; padding-top: 10px; margin: 0; font-size: 12px;">
                                    <strong><?php echo !empty($site['pembimbing']) ? $site['pembimbing'] : ' Pembimbing Magang'; ?></strong><br>
                                    <span style="font-size: 11px;"><?php echo date('d-m-Y'); ?></span>
                                </p>
                            </div>
                            <div style="clear: both;"></div>
                        </div>
                    </div>

                <?php else: ?>
                    <div class="alert alert-info"><i class="fa fa-info-circle"></i> Belum ada data feedback dari mahasiswa.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><!--/.row-->

<!-- Script Event Print & DataTables -->
<script>
    $(document).ready(function() {
        if ($.fn.DataTable.isDataTable('#feedbackTable')) {
            $('#feedbackTable').DataTable().destroy();
        }
        $('#feedbackTable').DataTable({
            "order": [[3, "desc"]]
        });
    });

    window.addEventListener('beforeprint', function() {
        document.getElementById('print-header').style.display = 'block';
        document.getElementById('print-footer').style.display = 'block';
    });

    window.addEventListener('afterprint', function() {
        document.getElementById('print-header').style.display = 'none';
        document.getElementById('print-footer').style.display = 'none';
    });
</script>

<!-- Style Khusus Cetak/Print -->
<style>
    .print-only { display: none; }

    @media print {
        .print-only { display: block !important; }
        #print-header { display: block !important; text-align: center; margin-bottom: 30px; border-bottom: 3px solid #1a3a6b; }
        #print-header img { height: 80px; display: inline-block; }
        #print-footer { display: block !important; margin-top: 40px; page-break-inside: avoid; }
        
        .panel-heading .pull-right, .btn, .breadcrumb, nav, .sidebar, .alert, .no-print, .dataTables_filter, .dataTables_info, .dataTables_paginate, .dataTables_length, .page-header {
            display: none !important;
        }

        .table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 11px; }
        .table th, .table td { border: 1px solid #000 !important; padding: 8px !important; }
        body { background: white; color: #000; }
    }

    #feedbackTable thead { background-color: #1a3a6b; color: white; }
    #feedbackTable th { color: white; font-weight: bold; }
</style>