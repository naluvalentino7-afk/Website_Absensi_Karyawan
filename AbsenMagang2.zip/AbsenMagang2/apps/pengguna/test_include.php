<?php
    echo "Current dir: " . __DIR__ . "<br>";
    echo "Testing paths:<br><br>";
    
    $paths = array(
        "/../../config/database.php" => __DIR__ . "/../../config/database.php",
        "../../../config/database.php" => __DIR__ . "/../../../config/database.php",
        "C:/xampp/htdocs/AbsenMagang/config/database.php" => "C:/xampp/htdocs/AbsenMagang/config/database.php"
    );
    
    foreach ($paths as $name => $path) {
        $exists = file_exists($path) ? "✅" : "❌";
        echo $exists . " " . $name . "<br>";
        echo "&nbsp;&nbsp;= " . $path . "<br><br>";
    }
?>