<?php
    // ============ AUTENTIKASI ============
    if ($_SESSION["level"]!='Mahasiswa' and $_SESSION["level"]!='mahasiswa'){
        echo"<br><div class='alert alert-danger'>Tidak Memiliki Hak Akses</div>";
        exit;
    }

    // ============ HANDLE AJAX REQUEST UNTUK SIMPAN FOTO ============
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['photo_file']) && isset($_POST['id_mahasiswa'])) {
        
        header('Content-Type: application/json');
        
        $response = array();
        
        try {
            include 'config/database.php';
            
            // ===== VALIDASI AUTENTIKASI =====
            if (!isset($_SESSION["id_mahasiswa"])) {
                throw new Exception("Session tidak ditemukan. Silakan login ulang.");
            }

            if ($_SESSION["level"] != 'Mahasiswa' && $_SESSION["level"] != 'mahasiswa') {
                throw new Exception("Anda tidak memiliki hak akses untuk fitur ini.");
            }

            // ===== VALIDASI INPUT =====
            if (!isset($_FILES['photo_file'])) {
                throw new Exception("File foto tidak ditemukan");
            }

            if (!isset($_POST['type'])) {
                throw new Exception("Parameter type tidak ditemukan");
            }

            $id_mahasiswa = trim($_POST['id_mahasiswa']);
            $absen_type = trim($_POST['type']);
            $file = $_FILES['photo_file'];

            if (empty($id_mahasiswa) || !is_numeric($id_mahasiswa)) {
                throw new Exception("ID Mahasiswa tidak valid");
            }

            if ($absen_type !== 'masuk' && $absen_type !== 'keluar') {
                throw new Exception("Tipe absensi tidak valid");
            }

            // ===== VALIDASI FILE UPLOAD ERROR =====
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $error_messages = array(
                    UPLOAD_ERR_INI_SIZE => 'File terlalu besar (upload_max_filesize)',
                    UPLOAD_ERR_FORM_SIZE => 'File terlalu besar (MAX_FILE_SIZE)',
                    UPLOAD_ERR_PARTIAL => 'Upload file tidak lengkap',
                    UPLOAD_ERR_NO_FILE => 'Tidak ada file yang di-upload',
                    UPLOAD_ERR_NO_TMP_DIR => 'Folder temporary tidak ada',
                    UPLOAD_ERR_CANT_WRITE => 'Gagal menulis file ke disk',
                    UPLOAD_ERR_EXTENSION => 'Extension file tidak diizinkan'
                );
                $error_msg = isset($error_messages[$file['error']]) ? $error_messages[$file['error']] : 'Error upload tidak diketahui';
                throw new Exception($error_msg);
            }

            // ===== VALIDASI TIPE FILE =====
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $file_type = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);

            $allowed_types = array('image/jpeg', 'image/png', 'image/jpg');
            
            if (!in_array($file_type, $allowed_types)) {
                throw new Exception("Tipe file tidak diizinkan. Hanya JPG atau PNG");
            }

            // ===== VALIDASI UKURAN FILE =====
            $max_file_size = 5 * 1024 * 1024;
            if ($file['size'] > $max_file_size) {
                throw new Exception("Ukuran file terlalu besar. Maksimal 5MB");
            }

            if ($file['size'] === 0) {
                throw new Exception("File kosong");
            }

            // ===== BUAT DIREKTORI UPLOAD =====
            $base_upload_dir = '../uploads/';
            $upload_dir = $base_upload_dir . 'selfie/';
            
            if (!is_dir($base_upload_dir)) {
                mkdir($base_upload_dir, 0777, true);
            }

            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            if (!is_writable($upload_dir)) {
                throw new Exception("Folder uploads/selfie tidak memiliki permission write");
            }

            // ===== GENERATE NAMA FILE =====
            $timestamp = date('Y-m-d_H-i-s');
            $unique_id = uniqid();
            $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            
            if (!in_array($file_extension, array('jpg', 'jpeg', 'png'))) {
                throw new Exception("Extension file tidak valid");
            }

            $file_name = 'selfie_' . $id_mahasiswa . '_' . $timestamp . '_' . $unique_id . '.' . $file_extension;
            $file_path = $upload_dir . $file_name;

            // ===== PINDAHKAN FILE =====
            if (!move_uploaded_file($file['tmp_name'], $file_path)) {
                throw new Exception("Gagal memindahkan file ke folder upload");
            }

            if (!file_exists($file_path)) {
                throw new Exception("File tidak ditemukan setelah upload");
            }

            // ===== UPDATE DATABASE =====
            $tanggal_sekarang = date('Y-m-d');
            
            $sql = "UPDATE tbl_absensi SET foto_selfie = ? WHERE id_mahasiswa = ? AND tanggal = ? LIMIT 1";
            $stmt = $kon->prepare($sql);
            
            if (!$stmt) {
                @unlink($file_path);
                throw new Exception("Prepare statement gagal");
            }

            $stmt->bind_param("sis", $file_name, $id_mahasiswa, $tanggal_sekarang);
            
            if (!$stmt->execute()) {
                @unlink($file_path);
                throw new Exception("Database update gagal");
            }

            // ===== SIMPAN LOKASI JIKA ADA =====
            if (isset($_POST['location']) && !empty($_POST['location'])) {
                try {
                    $location_data = json_decode($_POST['location'], true);
                    if ($location_data && isset($location_data['latitude']) && isset($location_data['longitude'])) {
                        $latitude = floatval($location_data['latitude']);
                        $longitude = floatval($location_data['longitude']);
                        $accuracy = floatval($location_data['accuracy'] ?? 0);

                        $sql_lokasi = "UPDATE tbl_absensi SET latitude = ?, longitude = ?, accuracy = ? WHERE id_mahasiswa = ? AND tanggal = ? LIMIT 1";
                        $stmt_lokasi = $kon->prepare($sql_lokasi);
                        if ($stmt_lokasi) {
                            $stmt_lokasi->bind_param("dddis", $latitude, $longitude, $accuracy, $id_mahasiswa, $tanggal_sekarang);
                            $stmt_lokasi->execute();
                        }
                    }
                } catch (Exception $e) {
                    error_log("Location data error: " . $e->getMessage());
                }
            }

            // ===== RESPONSE SUCCESS =====
            http_response_code(200);
            $response['status'] = 'success';
            $response['message'] = 'Foto berhasil disimpan';
            $response['file_name'] = $file_name;

        } catch (Exception $e) {
            http_response_code(400);
            $response['status'] = 'error';
            $response['message'] = $e->getMessage();
            error_log("Simpan Selfie Error: " . $e->getMessage());
        }

        echo json_encode($response);
        exit;
    }
    // ============ END HANDLE AJAX REQUEST ============
?>

<?php
    // ============ LOAD DATA MAHASISWA ============
    include 'config/database.php';
    $id_mahasiswa=$_SESSION["id_mahasiswa"];
    $sql="select * from tbl_mahasiswa where id_mahasiswa=$id_mahasiswa limit 1";
    $hasil=mysqli_query($kon,$sql);
    $data = mysqli_fetch_array($hasil);
    $nama=$data['nama'];
    $universitas=$data['universitas'];
    $nim=$data['nim'];
    $mulai_magang=$data['mulai_magang'];
    $akhir_magang=$data['akhir_magang'];
    $foto=$data['foto'];

    // Mengubah format tanggal ke bahasa Indonesia
    setlocale(LC_TIME, 'id_ID');
    $tanggal_sekarang = new DateTime();
    $tanggal_masuk = strftime("%d %B %Y", strtotime($mulai_magang));
    $tanggal_keluar = strftime("%d %B %Y", strtotime($akhir_magang));
?>

<?php
    // ============ LOAD SETTING ABSENSI ============
    $sql="select * from tbl_setting_absensi limit 1";
    $query=mysqli_query($kon,$sql);
    $setting = mysqli_fetch_array($query);
    $mulai_absen=$setting['mulai_absen'];
    $akhir_absen=$setting['akhir_absen'];
?>

<!-- ============ BREADCRUMB ============ -->
<div class="row">
    <ol class="breadcrumb">
        <li><a href="index.php?page=absen">
                <em class="fa fa-home"></em>
            </a></li>
        <li class="active">Beranda</li>
    </ol>
</div>

<!-- ============ MAIN PANEL ============ -->
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">Absensi</div>
            <div class="panel-body">
            <div id="div_periode" class='alert alert-warning'><strong>Periode Absensi Selesai</strong></div>

            <?php
                // Validasi untuk menampilkan pesan pemberitahuan
                if (isset($_GET['mulai'])) {
                    if ($_GET['mulai']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Absensi Masuk</div>";
                    }  else if ($_GET['mulai']=='gagal'){
                        echo"<div class='alert alert-warning'><strong>Maaf!</strong> Rentang Waktu Absensi Anda Belum Atau Lewat</div>";
                    }
                }
                
                if (isset($_GET['keluar'])) {
                    if ($_GET['keluar']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Absensi Keluar</div>";
                    }  else if ($_GET['keluar']=='gagal'){
                        echo"<div class='alert alert-warning'><strong>Maaf!</strong> Rentang Waktu Absensi Keluar Anda Belum Atau Lewat</div>";
                    }
                }
            ?>

                <div class="row">
                    <table class="table">
                    <tbody>
                    <tr>
                        <td>Nama Mahasiswa</td>
                        <td width="80%">: <?php echo $nama; ?></td>
                    </tr>
                    <tr>
                        <td>Nomor Induk Mahasiswa</td>
                        <td width="80%">: <?php echo $nim; ?></td>
                    </tr>
                    <tr>
                        <td>Universitas</td>
                        <td width="80%">: <?php echo $universitas; ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td width="80%">: 
                        <?php 
                            include 'config/function.php';
                            $tanggal_sekarang = date("d-m-Y");
                            $tgl = date("d", strtotime($tanggal_sekarang));
                            $bulan = date("m", strtotime($tanggal_sekarang));
                            $tahun = date("Y", strtotime($tanggal_sekarang));
                            echo $tgl.' '.MendapatkanBulan($bulan).' '.$tahun
                        ?> 
                        </td>
                    </tr>
                    <tr>
                        <td>Waktu Masuk</td>
                        <td width="80%">: 
                        <?php 
                            $tanggal_sekarang = date("Y-m-d");
                            $hari_sekarang = date("l", strtotime($tanggal_sekarang));
                            if ($hari_sekarang == "Saturday" || $hari_sekarang == "Sunday") {
                                echo "Hari Libur";
                            } else {
                                $kueri = "SELECT waktu FROM tbl_absensi WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal_sekarang'";
                                $result = mysqli_query($kon, $kueri);
                                if (mysqli_num_rows($result) > 0) {
                                    $data = mysqli_fetch_assoc($result);
                                    echo $data['waktu'];
                                } else {
                                    echo "Belum Absensi";
                                }
                            }                         
                        ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Status Masuk</td>
                        <td width="80">: 
                        <?php
                            $tanggal_sekarang = date("Y-m-d");
                            $hari_sekarang = date("l", strtotime($tanggal_sekarang));
                            if ($hari_sekarang == "Saturday" || $hari_sekarang == "Sunday") {
                                echo "Hari Libur";
                            } else {
                                $kueri = "SELECT status FROM tbl_absensi WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal_sekarang'";
                                $result = mysqli_query($kon, $kueri);
                                if (mysqli_num_rows($result) > 0) {
                                    $data = mysqli_fetch_array($result);
                                    if ($data['status'] == 1) {
                                        echo "Hadir";
                                    } elseif ($data['status'] == 2) {
                                        echo "Izin";
                                    } elseif ($data['status'] == 3) {
                                        echo "Tidak hadir";
                                    }
                                } else {
                                    echo "Belum Absensi";
                                }
                            }
                        ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Waktu Keluar</td>
                        <td width="80%">: 
                        <?php 
                            $tanggal_sekarang = date("Y-m-d");
                            $hari_sekarang = date("l", strtotime($tanggal_sekarang));
                            if ($hari_sekarang == "Saturday" || $hari_sekarang == "Sunday") {
                                echo "Hari Libur";
                            } else {
                                $kueri = "SELECT waktu_keluar FROM tbl_absensi WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal_sekarang'";
                                $result = mysqli_query($kon, $kueri);
                                if (mysqli_num_rows($result) > 0) {
                                    $data = mysqli_fetch_assoc($result);
                                    echo $data['waktu_keluar'] ? $data['waktu_keluar'] : "Belum Absensi Keluar";
                                } else {
                                    echo "Belum Absensi Keluar";
                                }
                            }                         
                        ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Status Keluar</td>
                        <td width="80">: 
                        <?php
                            $tanggal_sekarang = date("Y-m-d");
                            $hari_sekarang = date("l", strtotime($tanggal_sekarang));
                            if ($hari_sekarang == "Saturday" || $hari_sekarang == "Sunday") {
                                echo "Hari Libur";
                            } else {
                                $kueri = "SELECT status_keluar FROM tbl_absensi WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal_sekarang'";
                                $result = mysqli_query($kon, $kueri);
                                if (mysqli_num_rows($result) > 0) {
                                    $data = mysqli_fetch_array($result);
                                    if ($data['status_keluar'] == 1) {
                                        echo "Hadir";
                                    } elseif ($data['status_keluar'] == 2) {
                                        echo "Izin";
                                    } elseif ($data['status_keluar'] == 3) {
                                        echo "Tidak hadir";
                                    } else {
                                        echo "Belum Absensi Keluar";
                                    }
                                } else {
                                    echo "Belum Absensi Keluar";
                                }
                            }
                        ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?php
                                $tanggal_sekarang = date("Y-m-d");
                                $kueri = "SELECT status, waktu_keluar FROM tbl_absensi WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal_sekarang'";
                                $result = mysqli_query($kon, $kueri);
                                $sudah_absen_masuk = false;
                                $sudah_absen_keluar = false;
                                if (mysqli_num_rows($result) > 0) {
                                    $data = mysqli_fetch_assoc($result);
                                    if ($data['status'] == 1) {
                                        $sudah_absen_masuk = true;
                                    }
                                    if ($data['waktu_keluar']) {
                                        $sudah_absen_keluar = true;
                                    }
                                }
                                $disabled_masuk = $sudah_absen_masuk ? "disabled" : "";
                                $disabled_keluar = (!$sudah_absen_masuk || $sudah_absen_keluar) ? "disabled" : "";
                            ?>
                            <button id_mahasiswa="<?php echo $id_mahasiswa; ?>" id="tombol_absensi_masuk" class="tombol_periode mulai_absensi btn btn-success btn-circle" <?php echo $disabled_masuk; ?>><i class="fa fa-clock-o"></i> Absensi Masuk</button>
                            <button id_mahasiswa="<?php echo $id_mahasiswa; ?>" id="tombol_absensi_keluar" class="tombol_periode absen_keluar btn btn-warning btn-circle" <?php echo $disabled_keluar; ?>><i class="fa fa-sign-out"></i> Absensi Keluar</button>
                        </td>
                    </tr>
                    </tbody>
                    </table>
            </div>
        </div>
    </div>
</div>

<?php
    $query = "SELECT mulai_absen, akhir_absen FROM tbl_setting_absensi";
    $result = mysqli_query($kon, $query);
    $data = mysqli_fetch_assoc($result);
    $mulai_absen = date("H:i:s", strtotime($data['mulai_absen']));
    $akhir_absen = date("H:i:s", strtotime($data['akhir_absen']));
?>

<!-- ============ MODAL ABSENSI BIASA ============ -->
<div class="modal fade" id="modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title" id="judul"></h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div id="tampil_data"></div>  
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        </div>
        </div>
    </div>
</div>

<!-- ============ MODAL SELFIE ============ -->
<div class="modal fade" id="modal_selfie">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title">Ambil Foto Selfie</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <video id="video_selfie" width="100%" height="auto" autoplay playsinline></video>
                    <canvas id="canvas_selfie" style="display: none;" width="640" height="480"></canvas>
                    
                    <div id="preview_container" style="display: none; margin-top: 15px;">
                        <img id="captured_image" width="100%" alt="Foto Selfie">
                    </div>

                    <div style="margin-top: 15px; padding: 10px; background-color: #f5f5f5; border-radius: 5px;">
                        <p><strong>Lokasi:</strong> <span id="location_info">Mendeteksi lokasi...</span></p>
                        <p><strong>Waktu Absensi:</strong> <span id="time_info">--:--:--</span></p>
                        <p><strong>Akurasi GPS:</strong> <span id="accuracy_info">--</span></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" id="btn_ambil_foto" class="btn btn-primary"><i class="fa fa-camera"></i> Ambil Foto</button>
            <button type="button" id="btn_ulang_foto" class="btn btn-warning" style="display: none;"><i class="fa fa-repeat"></i> Ambil Ulang</button>
            <button type="button" id="btn_submit_foto" class="btn btn-success" style="display: none;"><i class="fa fa-check"></i> Konfirmasi</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Batal</button>
        </div>
        </div>
    </div>
</div>

<!-- ============ JAVASCRIPT ============ -->
<script>
    // ============ VARIABEL GLOBAL ============
    var photoData = null;
    var photoBlob = null;
    var locationData = null;
    var currentAbsenType = null;
    var currentIdMahasiswa = null;
    var mediaStream = null;

    // ============ EVENT LISTENERS TOMBOL ABSEN ============
    $('.mulai_absensi').on('click', function(){
        var id_mahasiswa = $(this).attr("id_mahasiswa");
        currentIdMahasiswa = id_mahasiswa;
        currentAbsenType = 'masuk';
        console.log("Absen Masuk - ID: " + id_mahasiswa);
        initSelfieCamera();
        $('#modal_selfie').modal('show');
    });

    $('.absen_keluar').on('click', function(){
        var id_mahasiswa = $(this).attr("id_mahasiswa");
        currentIdMahasiswa = id_mahasiswa;
        currentAbsenType = 'keluar';
        console.log("Absen Keluar - ID: " + id_mahasiswa);
        initSelfieCamera();
        $('#modal_selfie').modal('show');
    });

    // ============ INISIALISASI KAMERA ============
    function initSelfieCamera() {
        const video = document.getElementById('video_selfie');
        const canvas = document.getElementById('canvas_selfie');
        const previewContainer = document.getElementById('preview_container');
        
        video.style.display = 'block';
        previewContainer.style.display = 'none';
        document.getElementById('btn_ambil_foto').style.display = 'block';
        document.getElementById('btn_ulang_foto').style.display = 'none';
        document.getElementById('btn_submit_foto').style.display = 'none';
        photoData = null;
        photoBlob = null;
        
        if (mediaStream) {
            mediaStream.getTracks().forEach(track => track.stop());
            mediaStream = null;
        }
        
        navigator.mediaDevices.getUserMedia({ 
            video: { 
                facingMode: 'user',
                width: { ideal: 640 },
                height: { ideal: 480 }
            },
            audio: false
        }).then(function(stream) {
            mediaStream = stream;
            video.srcObject = stream;
            video.onloadedmetadata = function() {
                video.play();
            };
            console.log("Kamera berhasil diakses");
        }).catch(function(error) {
            console.error("Error mengakses kamera: ", error);
            alert("Tidak dapat mengakses kamera:\n" + error.message);
        });

        getLocation();
        updateTime();
    }

    // ============ AMBIL FOTO ============
    document.getElementById('btn_ambil_foto').addEventListener('click', function() {
        const video = document.getElementById('video_selfie');
        const canvas = document.getElementById('canvas_selfie');
        const context = canvas.getContext('2d');
        
        try {
            canvas.width = 640;
            canvas.height = 480;
            context.drawImage(video, 0, 0, 640, 480);
            
            canvas.toBlob(function(blob) {
                if (!blob) {
                    alert("Gagal mengambil foto. Coba lagi.");
                    return;
                }

                photoBlob = blob;
                photoData = canvas.toDataURL('image/jpeg', 0.9);

                console.log("Foto berhasil diambil. Size: " + blob.size + " bytes");
                
                document.getElementById('captured_image').src = photoData;
                video.style.display = 'none';
                document.getElementById('preview_container').style.display = 'block';
                document.getElementById('btn_ambil_foto').style.display = 'none';
                document.getElementById('btn_ulang_foto').style.display = 'block';
                document.getElementById('btn_submit_foto').style.display = 'block';
            }, 'image/jpeg', 0.9);

        } catch(error) {
            console.error("Error mengambil foto: ", error);
            alert("Error mengambil foto: " + error.message);
        }
    });

    // ============ AMBIL ULANG FOTO ============
    document.getElementById('btn_ulang_foto').addEventListener('click', function() {
        photoData = null;
        photoBlob = null;
        initSelfieCamera();
    });

    // ============ SUBMIT FOTO ============
    document.getElementById('btn_submit_foto').addEventListener('click', function() {
        if (!photoBlob) {
            alert("Foto belum diambil");
            return;
        }

        if (!currentIdMahasiswa) {
            alert("ID Mahasiswa tidak ditemukan");
            return;
        }

        console.log("Menyimpan foto...");
        document.getElementById('btn_submit_foto').disabled = true;
        document.getElementById('btn_submit_foto').innerHTML = '<i class="fa fa-spinner fa-spin"></i> Menyimpan...';

        saveSelfiePhoto(currentIdMahasiswa, photoBlob, currentAbsenType);
    });

    // ============ SIMPAN FOTO SELFIE ============
    function saveSelfiePhoto(id_mahasiswa, photoBlob, absenType) {
        console.log("=== START UPLOAD FOTO ===");
        console.log("ID Mahasiswa:", id_mahasiswa);
        console.log("Absen Type:", absenType);
        console.log("Blob Size:", photoBlob.size, "bytes");
        
        if (!photoBlob || photoBlob.size === 0) {
            alert("Foto tidak valid. Coba ambil foto lagi.");
            resetSubmitButton();
            return;
        }
        
        var formData = new FormData();
        formData.append('id_mahasiswa', id_mahasiswa);
        formData.append('photo_file', photoBlob, 'selfie_' + id_mahasiswa + '_' + Date.now() + '.jpg');
        formData.append('type', absenType);
        if (locationData) {
            formData.append('location', JSON.stringify(locationData));
        }

        console.log("Sending to apps/pengguna/simpan_selfie.php...");

        $.ajax({
            url: 'apps/pengguna/simpan_selfie.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            timeout: 30000,
            
            success: function(response) {
                console.log("=== RESPONSE SUCCESS ===");
                console.log("Full response:", response);
                
                if (response.status === 'success') {
                    alert('Foto berhasil disimpan!');
                    $('#modal_selfie').modal('hide');
                    photoData = null;
                    photoBlob = null;
                    
                    setTimeout(function() {
                        if (absenType === 'masuk') {
                            continueAbsenMasuk(id_mahasiswa);
                        } else {
                            continueAbsenKeluar(id_mahasiswa);
                        }
                    }, 500);
                } else {
                    alert("Error: " + (response.message || "Unknown error"));
                    resetSubmitButton();
                }
            },
            
            error: function(xhr, status, error) {
                console.log("=== AJAX ERROR ===");
                console.log("Status:", status);
                console.log("HTTP Status Code:", xhr.status);
                console.log("Response Text:", xhr.responseText);
                
                var errorMsg = "Gagal menyimpan foto";
                
                if (xhr.responseText) {
                    try {
                        var response = JSON.parse(xhr.responseText);
                        errorMsg = response.message || errorMsg;
                    } catch(e) {
                        errorMsg = xhr.responseText || errorMsg;
                    }
                }
                
                if (status === 'timeout') {
                    errorMsg = "Timeout: Server tidak merespons dalam 30 detik";
                } else if (xhr.status === 400) {
                    errorMsg = "Bad Request: " + errorMsg;
                } else if (xhr.status === 404) {
                    errorMsg = "File simpan_selfie.php tidak ditemukan (404)";
                }
                
                alert("Error: " + errorMsg);
                resetSubmitButton();
            }
        });
    }

    // ============ RESET SUBMIT BUTTON ============
    function resetSubmitButton() {
        document.getElementById('btn_submit_foto').disabled = false;
        document.getElementById('btn_submit_foto').innerHTML = '<i class="fa fa-check"></i> Konfirmasi';
    }

    // ============ LANJUT ABSENSI MASUK ============
    function continueAbsenMasuk(id_mahasiswa) {
        console.log("Loading form absensi masuk...");
        $.ajax({
            url: 'apps/pengguna/mulai_absensi.php',
            method: 'post',
            data: {id_mahasiswa: id_mahasiswa},
            success: function(data) {
                console.log("Form absensi masuk berhasil dimuat");
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML = 'Mulai Absensi Masuk';
                $('#modal').modal('show');
            },
            error: function(xhr, status, error) {
                console.error("Error loading absensi masuk:", error);
                console.log("Status:", status);
                console.log("Response:", xhr.responseText);
                console.log("URL yang dipanggil:", 'apps/pengguna/mulai_absensi.php');
                alert("Gagal memuat form absensi masuk.\nError: " + error);
            }
        });
    }

    // ============ LANJUT ABSENSI KELUAR ============
    function continueAbsenKeluar(id_mahasiswa) {
        console.log("Loading form absensi keluar...");
        $.ajax({
            url: 'apps/pengguna/absen_keluar.php',
            method: 'post',
            data: {id_mahasiswa: id_mahasiswa},
            success: function(data) {
                console.log("Form absensi keluar berhasil dimuat");
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML = 'Absensi Keluar';
                $('#modal').modal('show');
            },
            error: function(xhr, status, error) {
                console.error("Error loading absensi keluar:", error);
                console.log("Status:", status);
                console.log("Response:", xhr.responseText);
                console.log("URL yang dipanggil:", 'apps/pengguna/absen_keluar.php');
                alert("Gagal memuat form absensi keluar.\nError: " + error);
            }
        });
    }

    // ============ DAPATKAN LOKASI GPS ============
    function getLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    locationData = {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                        accuracy: position.coords.accuracy
                    };
                    document.getElementById('location_info').textContent = 
                        'Lat: ' + position.coords.latitude.toFixed(6) + 
                        ', Long: ' + position.coords.longitude.toFixed(6);
                    document.getElementById('accuracy_info').textContent = 
                        '±' + position.coords.accuracy.toFixed(0) + ' m';
                },
                function(error) {
                    document.getElementById('location_info').textContent = 'GPS tidak tersedia';
                    locationData = null;
                }
            );
        }
    }

    // ============ UPDATE WAKTU REAL-TIME ============
    function updateTime() {
        setInterval(function() {
            if ($('#modal_selfie').is(':visible')) {
                var now = new Date();
                var hours = String(now.getHours()).padStart(2, '0');
                var minutes = String(now.getMinutes()).padStart(2, '0');
                var seconds = String(now.getSeconds()).padStart(2, '0');
                document.getElementById('time_info').textContent = hours + ':' + minutes + ':' + seconds;
            }
        }, 1000);
    }

    // ============ HENTIKAN KAMERA SAAT MODAL DITUTUP ============
    $('#modal_selfie').on('hidden.bs.modal', function() {
        if (mediaStream) {
            mediaStream.getTracks().forEach(track => track.stop());
            mediaStream = null;
        }
        resetSubmitButton();
    });

    // ============ CEK PERIODE ABSENSI ============
    $(document).ready(function() {
        var tanggal_sekarang = new Date();
        var tanggal_keluar = new Date("<?php echo $akhir_magang; ?>");
        if (tanggal_sekarang > tanggal_keluar) {
            $(".tombol_periode").show();
            $("#div_periode").show();
        } else {
            $("#div_periode").hide();
        }
    });
</script>