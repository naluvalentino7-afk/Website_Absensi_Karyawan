<?php
    session_start();
    if (isset($_POST['submit'])) {
        include '../../config/database.php';
        function input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        $id_mahasiswa = $_SESSION["id_mahasiswa"];
        $status = input($_POST["status"]);
        date_default_timezone_set("Asia/Jakarta");
        $tanggal = date("Y-m-d");
        $waktu = date("H:i:s");
        $alasan = input($_POST["alasan"]);

        // ============ DETEKSI KETERLAMBATAN OTOMATIS ============
        $jam_terlambat = "09:00:00"; // Jam batas keterlambatan
        $status_terlambat = 0; // 0 = tepat waktu, 1 = terlambat

        $waktu_obj = new DateTime($waktu);
        $batas_waktu_obj = new DateTime($jam_terlambat);

        if ($waktu_obj > $batas_waktu_obj) {
            $status_terlambat = 1; // Terlambat
            // Ubah status menjadi "4" untuk menandai terlambat (jika ada kolom khusus)
        }

        // Handle foto selfi
        $foto = null;
        if (!empty($_POST['foto'])) {
            $foto_base64 = $_POST['foto'];
            $foto_data = str_replace('data:image/png;base64,', '', $foto_base64);
            $foto = base64_decode($foto_data);
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Cek apakah sudah absen masuk hari ini
            $cek_absen = "SELECT id_absensi FROM tbl_absensi WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal'";
            $result = mysqli_query($kon, $cek_absen);
            if (mysqli_num_rows($result) > 0) {
                // Sudah absen, tidak bisa absen lagi
                header("Location:../../index.php?page=absen&mulai=gagal");
            } else {
                // ============ INSERT DENGAN DETEKSI KETERLAMBATAN ============
                $sql = "INSERT INTO tbl_absensi (id_mahasiswa, tanggal, waktu, status, foto, terlambat) VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = mysqli_prepare($kon, $sql);
                mysqli_stmt_bind_param($stmt, 'issibi', $id_mahasiswa, $tanggal, $waktu, $status, $foto, $status_terlambat);
                mysqli_stmt_send_long_data($stmt, 4, $foto);  // Kirim data BLOB
                $simpan_absensi = mysqli_stmt_execute($stmt);

                if ($status == "2") {
                    $sql = "INSERT INTO tbl_alasan (id_mahasiswa, alasan, tanggal) VALUES ('$id_mahasiswa', '$alasan', '$tanggal')";
                    $simpan_izin = mysqli_query($kon, $sql);
                }

                if ($simpan_absensi) {
                    header("Location:../../index.php?page=absen&mulai=berhasil");
                } else {
                    header("Location:../../index.php?page=absen&mulai=gagal");
                }
            }
        }
    }
?>

<?php
    $id_mahasiswa = $_SESSION["id_mahasiswa"];
    $tanggal = date("Y-m-d");
    include '../../config/database.php';
    $query = mysqli_query($kon, "SELECT mulai_magang, akhir_magang FROM tbl_mahasiswa WHERE id_mahasiswa=$id_mahasiswa;");
    $periode = mysqli_fetch_array($query);
    $tanggal_masuk = $periode["mulai_magang"];
    $tanggal_keluar = $periode["akhir_magang"];

    // Cek apakah sudah absen masuk hari ini
    $query = "SELECT COUNT(*) FROM tbl_absensi WHERE tanggal = '$tanggal' AND id_mahasiswa = '$id_mahasiswa'";
    $result = mysqli_query($kon, $query);
    $data = mysqli_fetch_assoc($result);
    $absensi_sudah = ($data['COUNT(*)'] > 0) ? "disabled" : "";

    // ============ DETEKSI STATUS KETERLAMBATAN REAL-TIME ============
    date_default_timezone_set("Asia/Jakarta");
    $waktu_sekarang = new DateTime(date("H:i:s"));
    $batas_keterlambatan = new DateTime("09:00:00");
    $status_keterlambatan = ($waktu_sekarang > $batas_keterlambatan) ? "⚠️ TERLAMBAT" : "✓ TEPAT WAKTU";
    $warna_status = ($waktu_sekarang > $batas_keterlambatan) ? "danger" : "success";
?>

<form action="apps/pengguna/mulai_absensi.php" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <label>Status Masuk :</label>
                <select class="form-control" id="status" name="status" required>
                    <option>Pilih</option>
                    <option value="1">Hadir</option>
                    <option value="2">Izin</option>
                    <option value="3">Tidak Hadir</option>
                </select>
            </div>
        </div>
        <div class="col-sm-6" id="text_alasan" style="display:none;">
            <div class="form-group">
                <label>Alasan :</label>
                <input type="text" name="alasan" id="alasan" class="form-control" value="" placeholder="Masukkan Alasan">
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <label>Info Absensi:</label>
                <div class="alert alert-info">
                    <p><strong>Waktu Sistem:</strong> <span id="system_time">--:--:--</span></p>
                    <p><strong>Tanggal:</strong> <span id="system_date">--</span></p>
                    <p><strong>Batas Keterlambatan:</strong> 09:00 WIB</p>
                </div>

                <!-- ============ STATUS KETERLAMBATAN ============ -->
                <div class="alert alert-<?php echo $warna_status; ?>">
                    <h4><strong>Status: <?php echo $status_keterlambatan; ?></strong></h4>
                    <?php 
                        if ($waktu_sekarang > $batas_keterlambatan) {
                            echo "<p>⏰ Anda absen setelah pukul 09:00. Status akan dicatat sebagai <strong>TERLAMBAT</strong></p>";
                        } else {
                            echo "<p>✓ Anda absen sebelum pukul 09:00. Status akan dicatat sebagai <strong>TEPAT WAKTU</strong></p>";
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <br>
                <button type="submit" name="submit" id="tombol_masuk" class="simpan_absensi btn btn-success" <?php echo $absensi_sudah; ?>><i class="fa fa-clock-o"></i> Absen Masuk</button>
            </div>
        </div>
    </div>
</form>

<script>
  $(document).ready(function() {
    // ============ UPDATE WAKTU SISTEM REAL-TIME ============
    function updateSystemTime() {
      var now = new Date();
      var hours = String(now.getHours()).padStart(2, '0');
      var minutes = String(now.getMinutes()).padStart(2, '0');
      var seconds = String(now.getSeconds()).padStart(2, '0');
      var date = now.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      
      document.getElementById('system_time').textContent = hours + ':' + minutes + ':' + seconds;
      document.getElementById('system_date').textContent = date;

      // ============ DETEKSI KETERLAMBATAN REAL-TIME ============
      var jam_sekarang = hours + ':' + minutes;
      var batas_jam = '09:00';

      if (jam_sekarang > batas_jam) {
        // Terlambat
        document.querySelector('.alert-danger').style.display = 'block';
        document.querySelector('.alert-success') ? document.querySelector('.alert-success').style.display = 'none' : '';
      } else {
        // Tepat waktu
        document.querySelector('.alert-success').style.display = 'block';
        document.querySelector('.alert-danger') ? document.querySelector('.alert-danger').style.display = 'none' : '';
      }
    }

    updateSystemTime();
    setInterval(updateSystemTime, 1000);

    $("#status").change(function() {
      // Menampilkan input teks jika opsi "izin" dipilih
      if ($(this).val() == "2") {
        $("#text_alasan").show();
        $("#alasan").attr("required", true);
      } else {
        $("#text_alasan").hide();
        $("#alasan").attr("required", false);
      }
    });
  });
</script>