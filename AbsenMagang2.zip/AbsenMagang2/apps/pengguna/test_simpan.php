<?php
    session_start();
    
    // Set dummy session
    $_SESSION["id_mahasiswa"] = 1;
    $_SESSION["level"] = "mahasiswa";
    
    echo "<h2>Test Simpan Selfie</h2>";
    echo "<pre>";
    
    // Test include database
    $db_path = __DIR__ . '/../../config/database.php';
    echo "Database path: " . $db_path . "\n";
    echo "Exists: " . (file_exists($db_path) ? "YES" : "NO") . "\n\n";
    
    if (file_exists($db_path)) {
        include $db_path;
        
        if (isset($kon)) {
            echo "✅ Database included\n";
            echo "Connection: " . ($kon ? "OK" : "FAILED") . "\n\n";
            
            // Test query
            echo "=== TEST QUERY ===\n";
            $id_mahasiswa = 1;
            $tanggal = date('Y-m-d');
            $foto = 'test_foto.jpg';
            
            $sql = "UPDATE tbl_absensi SET foto_selfie = ? WHERE id_mahasiswa = ? AND tanggal = ? LIMIT 1";
            $stmt = $kon->prepare($sql);
            
            if ($stmt) {
                echo "✅ Prepare OK\n";
                $stmt->bind_param("sis", $foto, $id_mahasiswa, $tanggal);
                
                if ($stmt->execute()) {
                    echo "✅ Execute OK\n";
                    echo "Affected rows: " . $stmt->affected_rows . "\n";
                } else {
                    echo "❌ Execute Error: " . $stmt->error . "\n";
                }
            } else {
                echo "❌ Prepare Error: " . $kon->error . "\n";
            }
        } else {
            echo "❌ Database NOT included\n";
        }
    } else {
        echo "❌ Database file NOT found\n";
    }
    
    echo "</pre>";
?>