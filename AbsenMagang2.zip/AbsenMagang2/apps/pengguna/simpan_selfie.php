<?php
header('Content-Type: application/json');
session_start();

$response = array('status' => 'error', 'message' => 'Unknown');

try {
    if (!isset($_SESSION["id_mahasiswa"])) {
        throw new Exception("No session");
    }

    // Fix path untuk Windows dan Linux
    $db_path = realpath(__DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'database.php');
    
    if (!$db_path || !file_exists($db_path)) {
        throw new Exception("DB not found");
    }
    
    include $db_path;

    if (!isset($_FILES['photo_file'])) {
        throw new Exception("No file");
    }

    if (!isset($_POST['id_mahasiswa'])) {
        throw new Exception("No ID");
    }

    $id_mahasiswa = trim($_POST['id_mahasiswa']);
    $file = $_FILES['photo_file'];

    if (!is_numeric($id_mahasiswa)) {
        throw new Exception("Invalid ID");
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("Upload error: " . $file['error']);
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $file_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowed = array('image/jpeg', 'image/png', 'image/jpg');
    if (!in_array($file_type, $allowed)) {
        throw new Exception("Invalid type: " . $file_type);
    }

    if ($file['size'] === 0 || $file['size'] > 5*1024*1024) {
        throw new Exception("Invalid size");
    }

    $upload_dir = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'selfie' . DIRECTORY_SEPARATOR;
    
    if (!is_dir(__DIR__ . DIRECTORY_SEPARATOR . 'uploads')) {
        @mkdir(__DIR__ . DIRECTORY_SEPARATOR . 'uploads', 0777, true);
    }
    
    if (!is_dir($upload_dir)) {
        @mkdir($upload_dir, 0777, true);
    }

    $file_name = 'selfie_' . $id_mahasiswa . '_' . time() . '.jpg';
    $file_path = $upload_dir . $file_name;

    if (!move_uploaded_file($file['tmp_name'], $file_path)) {
        throw new Exception("Move failed");
    }

    $tanggal = date('Y-m-d');
    $sql = "UPDATE tbl_absensi SET foto_selfie = ? WHERE id_mahasiswa = ? AND tanggal = ? LIMIT 1";
    $stmt = $kon->prepare($sql);

    if (!$stmt) {
        @unlink($file_path);
        throw new Exception($kon->error);
    }

    $stmt->bind_param("sis", $file_name, $id_mahasiswa, $tanggal);

    if (!$stmt->execute()) {
        @unlink($file_path);
        throw new Exception($stmt->error);
    }

    if (isset($_POST['location']) && !empty($_POST['location'])) {
        try {
            $location_data = json_decode($_POST['location'], true);
            if (is_array($location_data)) {
                $lat = floatval($location_data['latitude'] ?? 0);
                $lng = floatval($location_data['longitude'] ?? 0);
                $acc = floatval($location_data['accuracy'] ?? 0);

                if ($lat && $lng) {
                    $sql_loc = "UPDATE tbl_absensi SET latitude = ?, longitude = ?, accuracy = ? WHERE id_mahasiswa = ? AND tanggal = ? LIMIT 1";
                    $stmt_loc = $kon->prepare($sql_loc);
                    if ($stmt_loc) {
                        $stmt_loc->bind_param("dddis", $lat, $lng, $acc, $id_mahasiswa, $tanggal);
                        $stmt_loc->execute();
                        $stmt_loc->close();
                    }
                }
            }
        } catch (Exception $e) {
            // Ignore
        }
    }

    http_response_code(200);
    $response = array(
        'status' => 'success',
        'message' => 'Foto berhasil disimpan',
        'file_name' => $file_name
    );

} catch (Exception $e) {
    http_response_code(400);
    $response = array(
        'status' => 'error',
        'message' => $e->getMessage()
    );
}

echo json_encode($response);
?>