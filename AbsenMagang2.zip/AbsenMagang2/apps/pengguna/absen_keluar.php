<?php
    session_start();
    if (isset($_POST['submit'])) {
        include '../../config/database.php';
        function input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        $id_mahasiswa = $_SESSION["id_mahasiswa"];
        $status_keluar = input($_POST["status_keluar"]);
        date_default_timezone_set("Asia/Jakarta");
        $tanggal = date("Y-m-d");
        $waktu_keluar = date("H:i:s");
        $alasan = input($_POST["alasan"]);

        // ✅ VALIDASI WAKTU DIHAPUS - BISA ABSEN KELUAR KAPAN SAJA

        // Handle foto selfi
        $foto_keluar = null;
        if (!empty($_POST['foto_keluar'])) {
            $foto_base64 = $_POST['foto_keluar'];
            $foto_data = str_replace('data:image/png;base64,', '', $foto_base64);
            $foto_keluar = base64_decode($foto_data);
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Cek apakah sudah absen masuk hari ini
            $cek_absen = "SELECT id_absensi FROM tbl_absensi WHERE id_mahasiswa = '$id_mahasiswa' AND tanggal = '$tanggal' AND status = 1";
            $result = mysqli_query($kon, $cek_absen);
            if (mysqli_num_rows($result) > 0) {
                // Update untuk absen keluar
                $sql = "UPDATE tbl_absensi SET waktu_keluar = ?, status_keluar = ?, foto_keluar = ? WHERE id_mahasiswa = ? AND tanggal = ?";
                $stmt = mysqli_prepare($kon, $sql);
                mysqli_stmt_bind_param($stmt, 'sisss', $waktu_keluar, $status_keluar, $foto_keluar, $id_mahasiswa, $tanggal);
                mysqli_stmt_send_long_data($stmt, 2, $foto_keluar);  // Kirim data BLOB
                $simpan_absensi = mysqli_stmt_execute($stmt);

                if ($status_keluar == "2") {
                    $sql = "INSERT INTO tbl_alasan (id_mahasiswa, alasan, tanggal) VALUES ('$id_mahasiswa', '$alasan', '$tanggal')";
                    $simpan_izin = mysqli_query($kon, $sql);
                }

                if ($simpan_absensi) {
                    header("Location:../../index.php?page=absen&keluar=berhasil");
                } else {
                    header("Location:../../index.php?page=absen&keluar=gagal");
                }
            } else {
                header("Location:../../index.php?page=absen&keluar=gagal");  // Belum absen masuk
            }
        }
    }
?>

<?php
    $id_mahasiswa = $_SESSION["id_mahasiswa"];
    $tanggal = date("Y-m-d");
    include '../../config/database.php';
    $query = mysqli_query($kon, "SELECT mulai_magang, akhir_magang FROM tbl_mahasiswa WHERE id_mahasiswa=$id_mahasiswa;");
    $periode = mysqli_fetch_array($query);
    $tanggal_masuk = $periode["mulai_magang"];
    $tanggal_keluar = $periode["akhir_magang"];

    // Cek apakah sudah absen keluar hari ini
    $query = "SELECT COUNT(*) FROM tbl_absensi WHERE tanggal = '$tanggal' AND id_mahasiswa = '$id_mahasiswa' AND waktu_keluar IS NOT NULL";
    $result = mysqli_query($kon, $query);
    $data = mysqli_fetch_assoc($result);
    $absensi_keluar_sudah = ($data['COUNT(*)'] > 0) ? "disabled" : "";
?>

<form action="apps/pengguna/absen_keluar.php" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <label>Status Keluar :</label>
                <select class="form-control" id="status_keluar" name="status_keluar" required>
                    <option>Pilih</option>
                    <option value="1">Hadir</option>
                    <option value="2">Izin</option>
                    <option value="3">Tidak Hadir</option>
                </select>
            </div>
        </div>
        <div class="col-sm-6" id="text_alasan" style="display:none;">
            <div class="form-group">
                <label>Alasan :</label>
                <input type="text" name="alasan" id="alasan" class="form-control" value="" placeholder="Masukkan Alasan">
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <label>Info Absensi:</label>
                <div class="alert alert-info">
                    <p><strong>Waktu Sistem:</strong> <span id="system_time">--:--:--</span></p>
                    <p><strong>Tanggal:</strong> <span id="system_date">--</span></p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <br>
                <button type="submit" name="submit" id="tombol_keluar" class="simpan_absensi_keluar btn btn-warning" <?php echo $absensi_keluar_sudah; ?>><i class="fa fa-sign-out"></i> Absen Keluar</button>
            </div>
        </div>
    </div>
</form>

<script>
  $(document).ready(function() {
    // Update waktu sistem real-time
    function updateSystemTime() {
      var now = new Date();
      var hours = String(now.getHours()).padStart(2, '0');
      var minutes = String(now.getMinutes()).padStart(2, '0');
      var seconds = String(now.getSeconds()).padStart(2, '0');
      var date = now.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      
      document.getElementById('system_time').textContent = hours + ':' + minutes + ':' + seconds;
      document.getElementById('system_date').textContent = date;
    }

    updateSystemTime();
    setInterval(updateSystemTime, 1000);

    $("#status_keluar").change(function() {
      // Menampilkan input teks jika opsi "izin" dipilih
      if ($(this).val() == "2") {
        $("#text_alasan").show();
        $("#alasan").attr("required", true);
      } else {
        $("#text_alasan").hide();
        $("#alasan").attr("required", false);
      }
    });
  });
</script>