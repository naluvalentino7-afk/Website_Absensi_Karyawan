<?php
// apps/feedback_admin/index.php
// Pastikan session sudah berjalan
if (session_status() === PHP_SESSION_NONE) session_start();

// Akses hanya Admin
if (!isset($_SESSION['level']) || ($_SESSION['level'] != 'Admin' && $_SESSION['level'] != 'admin')) {
    header("Location: index.php?page=beranda");
    exit();
}

// Pastikan koneksi $kon tersedia
if (!isset($kon) || !($kon instanceof mysqli)) {
    $possible = [
        __DIR__ . '/../../config/database.php',
        __DIR__ . '/../config/database.php',
        __DIR__ . '/config/database.php'
    ];
    foreach ($possible as $p) {
        if (file_exists($p)) {
            include $p;
            break;
        }
    }
}

// Ambil daftar kolom untuk deteksi fleksibel
$feedbackCols = [];
$mahasiswaCols = [];
$chk = mysqli_query($kon, "SHOW COLUMNS FROM tbl_feedback");
if ($chk) {
    while ($c = mysqli_fetch_assoc($chk)) $feedbackCols[] = $c['Field'];
}
$chk2 = mysqli_query($kon, "SHOW COLUMNS FROM tbl_mahasiswa");
if ($chk2) {
    while ($c = mysqli_fetch_assoc($chk2)) $mahasiswaCols[] = $c['Field'];
}

// Helper
$has = function($arr, $name) { return in_array($name, $arr); };

// Tentukan kolom urut (ORDER BY) — prefer id-like, fallback ke tanggal/created_at else use first available
$orderCandidates = ['id','id_feedback','feedback_id','no','created_at','tanggal_feedback','tanggal','date_created'];
$orderBy = null;
foreach ($orderCandidates as $c) {
    if ($has($feedbackCols, $c)) { $orderBy = $c; break; }
}
if (!$orderBy && count($feedbackCols) > 0) $orderBy = $feedbackCols[0]; // fallback

// Tentukan kolom tanggal untuk ditampilkan (opsional)
$dateCandidates = ['tanggal_feedback','tanggal','created_at','date_created','waktu'];
$dateField = null;
foreach ($dateCandidates as $c) {
    if ($has($feedbackCols, $c)) { $dateField = $c; break; }
}

// Tentukan kolom isi feedback
$msgCandidates = ['isi_feedback','pesan','message','feedback','content'];
$msgField = null;
foreach ($msgCandidates as $c) {
    if ($has($feedbackCols, $c)) { $msgField = $c; break; }
}
if (!$msgField) $msgField = $feedbackCols[0] ?? null;

// Tentukan join key ke tbl_mahasiswa
$joinCondition = null;
$joinCandidates = [
    ['tbl_feedback'=>'kode_pengguna','tbl_mahasiswa'=>'kode_mahasiswa'],
    ['tbl_feedback'=>'id_mahasiswa','tbl_mahasiswa'=>'id_mahasiswa'],
    ['tbl_feedback'=>'kode_mahasiswa','tbl_mahasiswa'=>'kode_mahasiswa'],
    ['tbl_feedback'=>'user_id','tbl_mahasiswa'=>'id_mahasiswa']
];
foreach ($joinCandidates as $jc) {
    if ($has($feedbackCols, $jc['tbl_feedback']) && $has($mahasiswaCols, $jc['tbl_mahasiswa'])) {
        $joinCondition = "tbl_feedback.{$jc['tbl_feedback']} = tbl_mahasiswa.{$jc['tbl_mahasiswa']}";
        break;
    }
}
if (!$joinCondition) {
    // fallback: don't join if no reliable key detected
    $joinCondition = null;
}

// Build SQL safely
$select = "SELECT tbl_feedback.*";
if ($joinCondition) $select .= ", tbl_mahasiswa.*";

$orderSql = $orderBy ? "ORDER BY tbl_feedback.`$orderBy` DESC" : "";

// Try main JOIN query if joinCondition available
$query_feedback = false;
if ($joinCondition) {
    $sql = "$select FROM tbl_feedback LEFT JOIN tbl_mahasiswa ON $joinCondition $orderSql";
    $query_feedback = @mysqli_query($kon, $sql);
}

// If join failed or no join, try simple select without ORDER BY id that may not exist
if (!$query_feedback) {
    // Try to order by discovered orderBy if it exists
    if ($orderBy && $has($feedbackCols, $orderBy)) {
        $sql2 = "SELECT * FROM tbl_feedback ORDER BY `$orderBy` DESC";
    } else {
        $sql2 = "SELECT * FROM tbl_feedback";
    }
    $query_feedback = @mysqli_query($kon, $sql2);
    // if still false, as last resort fetch without ordering
    if (!$query_feedback) {
        $query_feedback = mysqli_query($kon, "SELECT * FROM tbl_feedback");
    }
}

// Ambil data site untuk header print (optional)
$query_site = mysqli_query($kon, "SELECT * FROM tbl_site LIMIT 1");
$site = $query_site ? mysqli_fetch_array($query_site) : [];
$logo = $site['logo'] ?? '';
$nama_instansi = $site['nama_instansi'] ?? 'INSTANSI MAGANG';
$alamat = $site['alamat'] ?? '';
$no_telp = $site['no_telp'] ?? '';
$website = $site['website'] ?? '';

?>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Feedback Mahasiswa</h1>
    </div>
</div>

<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
      <div class="panel-heading">
        Daftar Feedback dari Mahasiswa
        <div class="pull-right">
          <a href="apps/cetak_feedback.php" class="btn btn-success btn-sm" target="_blank"><i class="fa fa-file-pdf-o"></i> Cetak PDF</a>
          <button type="button" onclick="window.print()" class="btn btn-info btn-sm"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>
      <div class="panel-body">
        <div id="print-header" class="print-only" style="display:none; text-align:center; margin-bottom:30px; padding-bottom:20px; border-bottom:3px solid #1a3a6b;">
          <?php if (!empty($logo)): ?>
            <div style="margin-bottom:15px;"><img src="apps/pengaturan/logo/<?php echo htmlspecialchars($logo); ?>" alt="Logo" style="height:100px;"></div>
          <?php endif; ?>
          <h2 style="margin:10px 0; font-size:22px; color:#1a3a6b;"><?php echo strtoupper(htmlspecialchars($nama_instansi)); ?></h2>
          <p style="margin:5px 0;"><?php echo htmlspecialchars($alamat); ?> | Telp: <?php echo htmlspecialchars($no_telp); ?></p>
        </div>

        <p class="no-print"><strong>Catatan:</strong> Admin hanya dapat melihat dan menghapus feedback mahasiswa.</p>

        <?php if ($query_feedback && mysqli_num_rows($query_feedback) > 0): ?>
          <table class="table table-striped table-bordered table-hover" id="feedbackTable">
            <thead style="background-color:#1a3a6b;color:#fff;">
              <tr>
                <th style="width:5%; text-align:center;">No</th>
                <th style="width:25%;">Kode / Nama</th>
                <th style="width:50%;">Isi Feedback</th>
                <th style="width:15%; text-align:center;">Tanggal</th>
                <th class="no-print" style="width:5%; text-align:center;">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $no=1; $total=0;
                while($row = mysqli_fetch_assoc($query_feedback)) {
                    // Resolve name field
                    $name = '-';
                    foreach (['nama','nama_mahasiswa','full_name','name'] as $nf) {
                        if (isset($row[$nf]) && trim($row[$nf])!=='') { $name = $row[$nf]; break; }
                    }
                    if ($name === '-' && isset($row['kode_pengguna'])) $name = $row['kode_pengguna'];

                    // Resolve message
                    $message = $row[$msgField] ?? ($row['pesan'] ?? ($row['message'] ?? '-'));

                    // Resolve date display
                    $dateDisplay = $row[$dateField] ?? ($row['tanggal'] ?? ($row['created_at'] ?? '-'));

                    // Resolve id for delete link
                    $idField = null;
                    foreach (['id','id_feedback','feedback_id','no'] as $idf) {
                        if (isset($row[$idf])) { $idField = $idf; break; }
                    }
                    $idVal = $idField ? $row[$idField] : '';

                    echo "<tr>";
                    echo "<td style='text-align:center;'>".($no++)."</td>";
                    echo "<td>".htmlspecialchars($name)."</td>";
                    echo "<td>".nl2br(htmlspecialchars($message))."</td>";
                    echo "<td style='text-align:center;'>".htmlspecialchars($dateDisplay)."</td>";
                    echo "<td class='no-print' style='text-align:center;'>";
                    if ($idVal !== '') {
                        echo "<a href='apps/feedback_admin/hapus.php?id=".urlencode($idVal)."' class='btn btn-danger btn-xs' onclick=\"return confirm('Yakin hapus feedback?');\"><i class='fa fa-trash'></i></a>";
                    } else {
                        echo "-";
                    }
                    echo "</td>";
                    echo "</tr>";
                    $total++;
                }
              ?>
            </tbody>
          </table>
        <?php else: ?>
          <div class="alert alert-info">Belum ada data feedback dari mahasiswa.</div>
        <?php endif; ?>

      </div>
    </div>
  </div>
</div>

<!-- DataTables init & print handlers -->
<script>
  $(document).ready(function(){
    if ($('#feedbackTable').length && $.fn.DataTable) {
      $('#feedbackTable').DataTable({ "order": [[3,'desc']] });
    }
  });
  window.addEventListener('beforeprint', function(){
    var ph = document.getElementById('print-header'); if (ph) ph.style.display='block';
  });
  window.addEventListener('afterprint', function(){
    var ph = document.getElementById('print-header'); if (ph) ph.style.display='none';
  });
</script>

<style>
.print-only{display:none;}
@media print { .print-only{display:block!important;} .no-print{display:none!important;} }
#feedbackTable thead { background:#1a3a6b; color:#fff; }
</style>