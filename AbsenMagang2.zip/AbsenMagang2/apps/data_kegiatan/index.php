<?php 
    $base_path = dirname(__FILE__);
    include $base_path . '/../../config/database.php';
    include $base_path . '/../../config/function.php';
    
    // Definisikan variabel action
    $action = isset($_GET['action']) ? $_GET['action'] : '';
    
    if ($_SESSION["level"] != 'Admin' && $_SESSION["level"] != 'admin' && $_SESSION["level"] != 'Mahasiswa' && $_SESSION["level"] != 'mahasiswa'){
    echo"<br><div class='alert alert-danger'>Tidak Memiliki Hak Akses</div>";
    exit;
}

    $post_action = isset($_POST['action']) ? $_POST['action'] : '';
?>

<div class="row">
    <ol class="breadcrumb">
        <li><a href="index.php?page=beranda">
                <em class="fa fa-home"></em>
            </a></li>
        <li class="active">Data Kegiatan</li>
    </ol>
</div>

<?php
// ============= FORM TAMBAH =============
if ($action == 'form_tambah') {
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Tambah Kegiatan Harian</div>
                <div class="panel-body">
                    <form method="POST" action="index.php?page=data_kegiatan&action=simpan_tambah" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Nama Mahasiswa :</label>
                            <select name="id_mahasiswa" id="id_mahasiswa" class="form-control" required>
                                <option value="">-- Pilih Mahasiswa --</option>
                                <?php
                                    $sql_mhs = "SELECT id_mahasiswa, nama FROM tbl_mahasiswa ORDER BY nama ASC";
                                    $hasil_mhs = mysqli_query($kon, $sql_mhs);
                                    while ($row_mhs = mysqli_fetch_array($hasil_mhs)) {
                                        echo '<option value="'.$row_mhs['id_mahasiswa'].'">'.$row_mhs['nama'].'</option>';
                                    }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Tanggal :</label>
                            <input type="date" name="tanggal" id="tanggal" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Jam Awal :</label>
                            <input type="time" name="waktu_awal" id="waktu_awal" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Jam Akhir :</label>
                            <input type="time" name="waktu_akhir" id="waktu_akhir" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Kegiatan :</label>
                            <textarea name="kegiatan" id="kegiatan" class="form-control" rows="4" required></textarea>
                        </div>

                        <div class="form-group">
                            <label>Foto Kegiatan :</label>
                            <div class="input-group">
                                <input type="file" name="foto" id="foto" class="form-control" accept="image/*" required>
                                <span class="input-group-addon"><i class="fa fa-image"></i></span>
                            </div>
                            <small class="form-text text-muted">Format: JPG, PNG, GIF. Ukuran maksimal 2MB</small>
                            <div id="preview-foto" style="margin-top: 10px;"></div>
                        </div>

                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                        <a href="index.php?page=data_kegiatan" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $('#foto').on('change', function() {
            var file = this.files[0];
            if (file) {
                if (file.size > 2097152) {
                    alert('Ukuran file terlalu besar! Maksimal 2MB');
                    $(this).val('');
                    $('#preview-foto').html('');
                    return;
                }

                var tipe_valid = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (tipe_valid.indexOf(file.type) === -1) {
                    alert('Tipe file tidak didukung! Gunakan JPG, PNG, atau GIF');
                    $(this).val('');
                    $('#preview-foto').html('');
                    return;
                }

                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#preview-foto').html('<img src="' + e.target.result + '" style="width: 150px; height: 150px; object-fit: cover; border-radius: 5px;">');
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
    <?php
    exit;
}

// ============= SIMPAN TAMBAH =============
if ($action == 'simpan_tambah' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_mahasiswa = $_POST['id_mahasiswa'];
    $tanggal = $_POST['tanggal'];
    $waktu_awal = $_POST['waktu_awal'];
    $waktu_akhir = $_POST['waktu_akhir'];
    $kegiatan = $_POST['kegiatan'];

    $foto = "";
    $nama_foto = "";
    
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $allowed = array("jpg" => "image/jpeg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
        $filename = $_FILES['foto']['name'];
        $filetype = $_FILES['foto']['type'];
        $filesize = $_FILES['foto']['size'];
        
        if ($filesize > 2097152) {
            header("Location: index.php?page=data_kegiatan&tambah=gagal");
            exit;
        }
        
        if (!in_array($filetype, $allowed)) {
            header("Location: index.php?page=data_kegiatan&tambah=gagal");
            exit;
        }
        
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $nama_foto = "kegiatan_" . $id_mahasiswa . "_" . time() . "." . $ext;
        $upload_dir = "apps/uploads/kegiatan/";
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $upload_dir . $nama_foto)) {
            $foto = $nama_foto;
        } else {
            header("Location: index.php?page=data_kegiatan&tambah=gagal");
            exit;
        }
    }

    $sql = "INSERT INTO tbl_kegiatan (id_mahasiswa, tanggal, waktu_awal, waktu_akhir, kegiatan, foto) 
            VALUES ('$id_mahasiswa', '$tanggal', '$waktu_awal', '$waktu_akhir', '$kegiatan', '$foto')";
    
    if (mysqli_query($kon, $sql)) {
        header("Location: index.php?page=data_kegiatan&tambah=berhasil");
    } else {
        if ($foto != "") {
            unlink($upload_dir . $nama_foto);
        }
        header("Location: index.php?page=data_kegiatan&tambah=gagal");
    }
    exit;
}

// ============= FORM EDIT =============
if ($action == 'form_edit') {
    $id_kegiatan = $_POST['id_kegiatan'];

    $sql = "SELECT * FROM tbl_kegiatan WHERE id_kegiatan = '$id_kegiatan'";
    $hasil = mysqli_query($kon, $sql);
    $data = mysqli_fetch_array($hasil);
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Edit Kegiatan Harian</div>
                <div class="panel-body">
                    <form method="POST" action="index.php?page=data_kegiatan&action=simpan_edit" enctype="multipart/form-data">
                        <input type="hidden" name="id_kegiatan" value="<?php echo $data['id_kegiatan']; ?>">
                        <input type="hidden" name="id_mahasiswa" value="<?php echo $data['id_mahasiswa']; ?>">
                        <input type="hidden" name="foto_lama" value="<?php echo $data['foto']; ?>">

                        <div class="form-group">
                            <label>Tanggal :</label>
                            <input type="date" name="tanggal" class="form-control" value="<?php echo $data['tanggal']; ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Jam Awal :</label>
                            <input type="time" name="waktu_awal" class="form-control" value="<?php echo $data['waktu_awal']; ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Jam Akhir :</label>
                            <input type="time" name="waktu_akhir" class="form-control" value="<?php echo $data['waktu_akhir']; ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Kegiatan :</label>
                            <textarea name="kegiatan" class="form-control" rows="4" required><?php echo $data['kegiatan']; ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>Foto Kegiatan :</label>
                            <?php if ($data['foto'] != '' && file_exists('apps/uploads/kegiatan/' . $data['foto'])) { ?>
                                <div style="margin-bottom: 10px;">
                                    <p><strong>Foto Saat Ini:</strong></p>
                                    <img src="apps/uploads/kegiatan/<?php echo $data['foto']; ?>" style="width: 150px; height: 150px; object-fit: cover; border-radius: 5px;">
                                </div>
                            <?php } ?>
                            <input type="file" name="foto" class="form-control" accept="image/*">
                            <small class="form-text text-muted">Biarkan kosong jika tidak ingin mengubah foto. Format: JPG, PNG, GIF. Ukuran maksimal 2MB</small>
                            <div id="preview-foto" style="margin-top: 10px;"></div>
                        </div>

                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Update</button>
                        <a href="index.php?page=data_kegiatan" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $('#foto').on('change', function() {
            var file = this.files[0];
            if (file) {
                if (file.size > 2097152) {
                    alert('Ukuran file terlalu besar! Maksimal 2MB');
                    $(this).val('');
                    $('#preview-foto').html('');
                    return;
                }

                var tipe_valid = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (tipe_valid.indexOf(file.type) === -1) {
                    alert('Tipe file tidak didukung! Gunakan JPG, PNG, atau GIF');
                    $(this).val('');
                    $('#preview-foto').html('');
                    return;
                }

                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#preview-foto').html('<img src="' + e.target.result + '" style="width: 150px; height: 150px; object-fit: cover; border-radius: 5px;">');
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
    <?php
    exit;
}

// ============= SIMPAN EDIT =============
if ($action == 'simpan_edit' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_kegiatan = $_POST['id_kegiatan'];
    $tanggal = $_POST['tanggal'];
    $waktu_awal = $_POST['waktu_awal'];
    $waktu_akhir = $_POST['waktu_akhir'];
    $kegiatan = $_POST['kegiatan'];
    $foto_lama = $_POST['foto_lama'];

    $nama_foto = $foto_lama;
    
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $allowed = array("jpg" => "image/jpeg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
        $filename = $_FILES['foto']['name'];
        $filetype = $_FILES['foto']['type'];
        $filesize = $_FILES['foto']['size'];
        
        if ($filesize > 2097152) {
            header("Location: index.php?page=data_kegiatan&edit=gagal");
            exit;
        }
        
        if (!in_array($filetype, $allowed)) {
            header("Location: index.php?page=data_kegiatan&edit=gagal");
            exit;
        }
        
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $nama_foto = "kegiatan_" . $_POST['id_mahasiswa'] . "_" . time() . "." . $ext;
        $upload_dir = "apps/uploads/kegiatan/";
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $upload_dir . $nama_foto)) {
            if ($foto_lama != '' && file_exists($upload_dir . $foto_lama)) {
                unlink($upload_dir . $foto_lama);
            }
        } else {
            header("Location: index.php?page=data_kegiatan&edit=gagal");
            exit;
        }
    }

    $sql = "UPDATE tbl_kegiatan SET tanggal='$tanggal', waktu_awal='$waktu_awal', 
            waktu_akhir='$waktu_akhir', kegiatan='$kegiatan', foto='$nama_foto'
            WHERE id_kegiatan='$id_kegiatan'";
    
    if (mysqli_query($kon, $sql)) {
        header("Location: index.php?page=data_kegiatan&edit=berhasil");
    } else {
        header("Location: index.php?page=data_kegiatan&edit=gagal");
    }
    exit;
}

// ============= CETAK =============
if ($action == 'cetak') {
    $id_mahasiswa = $_POST['id_mahasiswa'];
    
    $sql = "SELECT tbl_mahasiswa.nama, tbl_kegiatan.* FROM tbl_kegiatan 
            JOIN tbl_mahasiswa ON tbl_mahasiswa.id_mahasiswa = tbl_kegiatan.id_mahasiswa 
            WHERE tbl_kegiatan.id_mahasiswa = '$id_mahasiswa' 
            ORDER BY tbl_kegiatan.tanggal DESC";
    $hasil = mysqli_query($kon, $sql);
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Cetak Data Kegiatan</div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th colspan="6" style="text-align: center; font-size: 16px; font-weight: bold;">
                                        DATA KEGIATAN HARIAN<br>
                                        <?php 
                                            $row = mysqli_fetch_array($hasil);
                                            echo $row['nama'];
                                            mysqli_data_seek($hasil, 0);
                                        ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Jam</th>
                                    <th>Kegiatan</th>
                                    <th>Foto</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $no = 1;
                                    while ($data = mysqli_fetch_array($hasil)) {
                                ?>
                                <tr>
                                    <td><?php echo $no; ?></td>
                                    <td><?php echo date("d-m-Y", strtotime($data['tanggal'])); ?></td>
                                    <td>
                                        <?php 
                                            echo substr($data['waktu_awal'], 0, 5) . " - " . substr($data['waktu_akhir'], 0, 5);
                                        ?>
                                    </td>
                                    <td><?php echo $data['kegiatan']; ?></td>
                                    <td>
                                        <?php 
                                            if($data['foto'] != '' && file_exists('apps/uploads/kegiatan/'.$data['foto'])) {
                                                echo '<img src="apps/uploads/kegiatan/'.$data['foto'].'" alt="Foto Kegiatan" style="width: 100px; height: 100px; object-fit: cover; border-radius: 5px;">';
                                            } else {
                                                echo '<span class="label label-warning">Tidak ada foto</span>';
                                            }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                                    $no++;
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div style="margin-top: 20px;">
                        <button class="btn btn-info" onclick="window.print()"><i class="fa fa-print"></i> Cetak/Print</button>
                        <a href="index.php?page=data_kegiatan" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> Kembali</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    exit;
}

// ============= HAPUS =============
if ($action == 'hapus') {
    $id_kegiatan = $_GET['id_kegiatan'];

    $sql_select = "SELECT foto FROM tbl_kegiatan WHERE id_kegiatan = '$id_kegiatan'";
    $result = mysqli_query($kon, $sql_select);
    $data = mysqli_fetch_array($result);

    $sql = "DELETE FROM tbl_kegiatan WHERE id_kegiatan = '$id_kegiatan'";
    
    if (mysqli_query($kon, $sql)) {
        if ($data['foto'] != '' && file_exists('apps/uploads/kegiatan/' . $data['foto'])) {
            unlink('apps/uploads/kegiatan/' . $data['foto']);
        }
        header("Location: index.php?page=data_kegiatan&hapus=berhasil");
    } else {
        header("Location: index.php?page=data_kegiatan&hapus=gagal");
    }
    exit;
}
?>

<!-- ============= HALAMAN UTAMA ============= -->
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
            Data Kegiatan
                <span class="pull-right clickable panel-toggle panel-button-tab-left"><em class="fa fa-toggle-up"></em></span></div>
            <div class="panel-body">
                <div class="row">
                <form action="#" method="GET">
                    <input type="hidden" name="page" value="data_kegiatan"/>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Nama Mahasiswa :</label>
                            <input type="text" name="nama" id="nama" class="form-control"  value="" placeholder="Cari Mahasiswa" required>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Tanggal Awal :</label>
                            <input type="date" name="tanggal_awal" id="tanggal_awal" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Tanggal Akhir :</label>
                            <input type="date" name="tanggal_akhir" id="tanggal_akhir" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            </br>
                            <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> Cari</button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-body">
            
            <?php
            
                if (isset($_GET['tambah'])) {
                    if ($_GET['tambah']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Menambahkan Kegiatan Harian</div>";
                    }else if ($_GET['tambah']=='gagal'){
                        echo"<div class='alert alert-danger'><strong>Gagal!</strong> Menambahkan Kegiatan Harian</div>";
                    }
                }

                if (isset($_GET['edit'])) {
                    if ($_GET['edit']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Mengubah Kegiatan Harian</div>";
                    }else if ($_GET['edit']=='gagal'){
                        echo"<div class='alert alert-danger'><strong>Gagal!</strong> Mengubah Kegiatan Harian</div>";
                    }    
                }

                if (isset($_GET['hapus'])) {
                    if ($_GET['hapus']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Menghapus Kegiatan Harian</div>";
                    }else if ($_GET['hapus']=='gagal'){
                        echo"<div class='alert alert-danger'><strong>Gagal!</strong> Menghapus Kegiatan Harian</div>";
                    }    
                }
            ?>

                <div class="form-group">
                    <a href="index.php?page=data_kegiatan&action=form_tambah" class="btn btn-success"><i class="fa fa-plus"></i> Tambah Kegiatan</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Hari</th>
                                <th>Tanggal</th>
                                <th>Jam</th>
                                <th>Kegiatan</th>
                                <th>Foto</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
        
                        <tbody>
                        <?php
                            if (isset($_GET['nama']) AND $_GET['nama']!="") {
                                $nama=trim($_GET["nama"]);
                                $tanggal_awal=$_GET["tanggal_awal"];
                                $tanggal_akhir=$_GET["tanggal_akhir"];
                                $sql= CariKegiatan($nama, $tanggal_awal, $tanggal_akhir);
                            } 
                            else { 
                                $sql= DataKegiatan("");
                            }                             
                            $hasil=mysqli_query($kon,$sql);
                            $no=0;
                            while ($data = mysqli_fetch_array($hasil)):
                            $no++;
                        ?>
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo $data['nama']; ?></td>
                            <td>
                                <?php
                                    $hari = $data["hari"];
                                    echo MendapatkanHari($hari);
                                ?>
                            </td>
                            <td>
                                <?php 
                                $tgl = date("d", strtotime($data['tanggal']));
                                $bulan = date("m", strtotime($data['tanggal']));
                                $tahun = date("Y", strtotime($data['tanggal']));
                                echo $tgl.' '.MendapatkanBulan($bulan).' '.$tahun
                                ?>
                            </td>
                            <td><?php echo $data['waktu']; ?></td>
                            <td><?php echo $data['kegiatan']; ?></td>
                            <td>
                                <?php 
                                    if(isset($data['foto']) && $data['foto'] != '' && file_exists('apps/uploads/kegiatan/'.$data['foto'])) {
                                        echo '<img src="apps/uploads/kegiatan/'.$data['foto'].'" alt="Foto Kegiatan" style="width: 80px; height: 80px; object-fit: cover; border-radius: 5px;" class="img-thumbnail">';
                                    } else {
                                        echo '<span class="label label-warning">Tidak ada foto</span>';
                                    }
                                ?>
                            </td>
                            <td>
                                <form method="POST" action="index.php?page=data_kegiatan&action=form_edit" style="display: inline;">
                                    <input type="hidden" name="id_kegiatan" value="<?php echo $data['id_kegiatan']; ?>">
                                    <button type="submit" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></button>
                                </form>
                                <a href="index.php?page=data_kegiatan&action=hapus&id_kegiatan=<?php echo $data['id_kegiatan']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?');"><i class="fa fa-trash"></i></a>
                                <form method="POST" action="index.php?page=data_kegiatan&action=cetak" style="display: inline;">
                                    <input type="hidden" name="id_mahasiswa" value="<?php echo $data['id_mahasiswa']; ?>">
                                    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-print"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>