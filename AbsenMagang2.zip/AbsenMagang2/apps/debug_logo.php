<?php
    include '../../config/database.php';
    
    $query = mysqli_query($kon, "SELECT logo FROM tbl_site LIMIT 1");
    $row = mysqli_fetch_array($query);
    
    $logo_file = $row['logo'];
    
    echo "Logo filename: " . $logo_file . "<br>";
    echo "Server root: " . $_SERVER['DOCUMENT_ROOT'] . "<br><br>";
    
    // Path 1: Absolute
    $path1 = $_SERVER['DOCUMENT_ROOT'] . '/AbsenMagang/apps/pengaturan/logo/' . $logo_file;
    echo "Path 1 (Absolute): " . $path1 . "<br>";
    echo "Exists: " . (file_exists($path1) ? 'YES ✓' : 'NO ✗') . "<br><br>";
    
    // Path 2: Relative dari cetak_feedback.php
    $path2 = '../../apps/pengaturan/logo/' . $logo_file;
    echo "Path 2 (Relative): " . $path2 . "<br>";
    echo "Exists: " . (file_exists($path2) ? 'YES ✓' : 'NO ✗') . "<br><br>";
    
    // Path 3: Direktori logo
    $logo_dir = $_SERVER['DOCUMENT_ROOT'] . '/AbsenMagang/apps/pengaturan/logo/';
    echo "Logo Directory: " . $logo_dir . "<br>";
    echo "Directory Exists: " . (is_dir($logo_dir) ? 'YES ✓' : 'NO ✗') . "<br><br>";
    
    // List semua file di logo directory
    if (is_dir($logo_dir)) {
        echo "Files in logo directory:<br>";
        $files = scandir($logo_dir);
        foreach ($files as $file) {
            if ($file != '.' && $file != '..') {
                echo "- " . $file . "<br>";
            }
        }
    }
?>