<h3>Laporan Daftar Instansi/Universitas Pengirim</h3>
<button onclick="window.print()" class="btn btn-primary" style="margin-bottom:15px;">
    <i class="fa fa-print"></i> Cetak / Print
</button>

<div id="area-laporan">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Instansi/Universitas</th>
                <th>Jumlah Mahasiswa</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no=1;
            $sql = "SELECT universitas, COUNT(*) AS jumlah 
                    FROM tbl_mahasiswa 
                    GROUP BY universitas
                    ORDER BY jumlah DESC";
            $result = mysqli_query($kon, $sql);
            while($data = mysqli_fetch_array($result)){
                echo "<tr>
                        <td>".$no++."</td>
                        <td>".htmlspecialchars($data['universitas'])."</td>
                        <td>".$data['jumlah']."</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
</div>