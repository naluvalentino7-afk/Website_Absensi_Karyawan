<?php
session_start();

// Validasi akses hanya admin
if (!isset($_SESSION['level']) || ($_SESSION['level'] != 'Admin' && $_SESSION['level'] != 'admin')) {
    die('Akses Ditolak - Hanya Admin');
}

$base_path = dirname(__FILE__);

// Panggil FPDF dan koneksi database
require_once($base_path . '/../source/plugin/fpdf/fpdf.php');
include_once($base_path . '/../config/database.php');
include_once($base_path . '/../config/function.php');

if (!isset($kon)) {
    die('Database connection error');
}

$pdf = new FPDF('P', 'mm', 'Letter');

// Ambil data instansi
$query = mysqli_query($kon, "SELECT * FROM tbl_site LIMIT 1");
$row   = $query ? mysqli_fetch_array($query) : [];

$pembimbing    = isset($row['pembimbing']) ? $row['pembimbing'] : '';
$nama_instansi = isset($row['nama_instansi']) ? $row['nama_instansi'] : 'INSTANSI MAGANG';
$alamat        = isset($row['alamat']) ? $row['alamat'] : '';
$no_telp       = isset($row['no_telp']) ? $row['no_telp'] : '';
$website       = isset($row['website']) ? $row['website'] : '';
$logo          = isset($row['logo']) ? $row['logo'] : '';

$pdf->AddPage();

// === LOGO & HEADER ===
$logo_path = $base_path . '/pengaturan/logo/' . $logo;
if (!empty($logo) && file_exists($logo_path)) {
    $pdf->Image($logo_path, 15, 5, 20, 20);
}

$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,7,strtoupper($nama_instansi),0,1,'C');
$pdf->SetFont('Arial','',9);
$pdf->Cell(0,5,$alamat . (!empty($no_telp) ? ', Telp: '.$no_telp : ''),0,1,'C');
$pdf->Cell(0,5,$website,0,1,'C');

// === GARIS PEMBATAS ===
$pdf->SetLineWidth(0.8);
$pdf->Line(10,31,206,31);
$pdf->SetLineWidth(0.2);
$pdf->Line(10,32,206,32);

// === JUDUL LAPORAN ===
$pdf->SetFont('Arial','B',13);
$pdf->Cell(0,6,'',0,1,'C');
$pdf->Cell(0,7,'LAPORAN FEEDBACK MAHASISWA',0,1,'C');
$pdf->SetFont('Arial','',9);
$pdf->Cell(0,5,'Tanggal Cetak: '.date('d-m-Y H:i:s'),0,1,'C');
$pdf->Ln(4);

// === TABLE HEADER ===
$pdf->SetFont('Arial','B',9);
$pdf->Cell(10,7,'No',1,0,'C');
$pdf->Cell(50,7,'Nama / Kode Mahasiswa',1,0,'C');
$pdf->Cell(101,7,'Isi Feedback',1,0,'C');
$pdf->Cell(35,7,'Tanggal',1,1,'C');
$pdf->SetFont('Arial','',9);

// === QUERY DATA FEEDBACK ===
$sql = "SELECT f.*, m.nama 
        FROM tbl_feedback f 
        LEFT JOIN tbl_mahasiswa m ON f.kode_pengguna = m.kode_mahasiswa 
        ORDER BY f.id DESC";
$hasil = mysqli_query($kon, $sql);

if (!$hasil) {
    $hasil = mysqli_query($kon, "SELECT * FROM tbl_feedback ORDER BY id DESC");
}

$no = 1;
$total_feedback = 0;

if ($hasil && mysqli_num_rows($hasil) > 0) {
    while ($data = mysqli_fetch_array($hasil)) {
        $nama_mhs = !empty($data['nama']) ? $data['nama'] : (isset($data['kode_pengguna']) ? $data['kode_pengguna'] : '-');
        $isi      = isset($data['isi_feedback']) ? $data['isi_feedback'] : (isset($data['pesan']) ? $data['pesan'] : '-');
        $tanggal  = isset($data['tanggal_feedback']) ? $data['tanggal_feedback'] : (isset($data['tanggal']) ? $data['tanggal'] : '-');

        // Bersihkan newline agar baris tabel rapi
        $isi_clean = str_replace(array("\r", "\n"), ' ', $isi);

        $pdf->Cell(10,6,$no,1,0,'C');
        $pdf->Cell(50,6,substr($nama_mhs, 0, 26),1,0,'L');
        $pdf->Cell(101,6,substr($isi_clean, 0, 58),1,0,'L');
        $pdf->Cell(35,6,$tanggal,1,1,'C');
        
        $no++;
        $total_feedback++;
    }
} else {
    $pdf->Cell(196,6,'Belum ada data feedback',1,1,'C');
}

// === TOTAL FEEDBACK ===
$pdf->SetFont('Arial','B',9);
$pdf->Cell(161,6,'TOTAL FEEDBACK: ',1,0,'R');
$pdf->Cell(35,6,$total_feedback.' Item',1,1,'C');

// === TTD PEMBIMBING ===
$pdf->Ln(10);
$pdf->SetFont('Arial','',10);

$pdf->Cell(120,5,'',0,0);
$pdf->Cell(76,5,'Banjarmasin, '.date('d F Y'),0,1,'C');

$pdf->Cell(120,5,'',0,0);
$pdf->Cell(76,5,'Pembimbing Magang,',0,1,'C');

$pdf->Ln(18);

$pdf->Cell(120,5,'',0,0);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(76,5,(!empty($pembimbing) ? $pembimbing : '(___________________)'),0,1,'C');

// Output PDF
$namafile = 'Laporan-Feedback-'.date('YmdHis').'.pdf';
$pdf->Output('I', $namafile);
?>